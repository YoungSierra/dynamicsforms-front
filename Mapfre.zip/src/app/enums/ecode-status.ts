export enum ECodeStatus {
    Ok = 200, //success
    Created = 201, // Registro creado
    NoContent = 204,//info
    Unauthorized = 401,// cuando el usuario no esta logueado
    BadRequest = 400,// Campo faltante
    Forbidden = 403, // el usuario no tiene permiso
    InternalServerError = 500//danger
}
