export interface File {
    name: string,
    base64: string,
    base64Sort: string,
    size?: number,
    ext?: string
}
