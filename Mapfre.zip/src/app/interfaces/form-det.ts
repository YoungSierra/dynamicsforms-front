export interface FormDet {
    id: string,
    formsId: string,
    segmentsId: string,
    keysId: string,
    ordernum: string,
    status: string,
    usersId: string,
    created: string,
    updated: string
}
