import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appNoNegative]'
})
export class NoNegativeDirective {

  constructor(private el: ElementRef) { }


  @HostListener('input', ['$event.target.value'])
  onInputChange(value: string) {
    const initialValue = this.el.nativeElement.value;

    // Elimina caracteres no numéricos y verifica si es negativo
    const numericValue = parseFloat(initialValue.replace(/[^0-9.-]/g, ''));
    if (numericValue < 0) {
      this.el.nativeElement.value = ''; // Si es negativo, borra el valor
    }
  }


}
