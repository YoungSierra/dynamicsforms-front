import { Injectable } from '@angular/core';
import { jsPDF } from "jspdf";
import { MethodsService } from '../services/methods.service';
import { font } from './font';
import { fontBold } from './fontBold'

@Injectable({
  providedIn: 'root'
})
export class PdfService {

  constructor(
    private methods: MethodsService
  ) { }

  generateDoc(data: any, html: any, title: string, type: 'datauri' | 'datauristring'): Promise<any> {

    return new Promise((resolve, reject) => {
      const doc = new jsPDF({
        format: 'a4',
        unit: 'px',
        precision: 1
      });

      let positionVertical = 55;
      let sizeRow = 6;
      let sizeColum = 33;
      let column = 1;
      let sizeBody = 376;

      doc.addFileToVFS("DIN-Medium.ttf", font);
      doc.addFont("DIN-Medium.ttf", "DIN", "normal");

      doc.addFileToVFS("DIN-Bold.ttf", fontBold)
      doc.addFont("DIN-Bold.ttf", "DIN-B", "normal");

      doc.setFont("DIN");


      doc.setFillColor(216, 30, 5);
      doc.roundedRect(-5, -5, 420, 50, 3, 3, "F");
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(23);
      doc.text(title.toLocaleUpperCase(), 400, 25, { align: 'right' });
      doc.setFontSize(14);
      doc.setTextColor(0, 0, 0);

      doc.setFontSize(7);
      data.forEach(element => {
        if (element.type == 'key') {
          doc.setFontSize(10);
          doc.text(element.k_question, sizeColum, positionVertical);
          if (element.k_subtitle) {
            positionVertical += sizeRow + 2;
            let rows = doc.splitTextToSize(element.s_subtitle, sizeBody);
            let dimentions = doc.getTextDimensions(rows);
            doc.text(rows, sizeColum, positionVertical);
            positionVertical += (sizeRow * rows.length)
          }
          doc.setDrawColor(216, 30, 5);
          doc.setFillColor(216, 30, 5);
          doc.line(sizeColum, ((positionVertical + 2)), (sizeColum * 12), ((positionVertical + 2)), "S")
          if (element.k_subtitle) positionVertical += (sizeRow * 2);
          doc.setFontSize(7);
          doc.setTextColor(0, 0, 0);

          if (element.kt_name == 'OPC_UNICA') {
            let positionCheck = sizeColum;
            element.keys_opt.forEach((key, index) => {

              let label = doc.splitTextToSize(key.ko_value, sizeBody);
              let dimentions = doc.getTextDimensions(`0 ${key.ko_value}`);
              doc.circle((positionCheck + 2), ((positionVertical + 6)), 2, ((element.value == key.ko_id) ? 'FD' : 'S'));
              doc.text(label, positionCheck + 5, (positionVertical + 8))

              if (
                (dimentions.w >= (sizeBody - 10) ||
                  (sizeBody - dimentions.w) < sizeColum) ||
                (positionCheck >= (sizeBody - 10) ||
                  (sizeBody - dimentions.w) < sizeColum)) {
                positionCheck = sizeColum;
                positionVertical += sizeRow;
              } else {
                positionCheck += dimentions.w + 5
              }

            });
          }

          if (element.kt_name == 'NUM_ENTERO') {
            if (element.sd_colsize == 12) { column = 1; positionVertical += sizeRow }
            if (column >= 12) { column = 1; positionVertical += (sizeRow * 2 + (sizeRow / 2)) }
            doc.text(new String(element.value).toString(), (sizeColum * column), (positionVertical + sizeRow));
          }

          positionVertical += sizeRow;

        }

        if (element.type == 'segment') {

          doc.setFontSize(10);
          positionVertical += sizeRow;
          doc.text(element.s_title, sizeColum, positionVertical);
          if (element.s_subtitle) {
            positionVertical += sizeRow + 2;
            let rows = doc.splitTextToSize(element.s_subtitle, sizeBody);
            let dimentions = doc.getTextDimensions(rows);
            doc.text(rows, sizeColum, positionVertical);
            if(rows.length >= 2) { positionVertical += (rows.length * sizeRow) };
          }

          doc.line(sizeColum, ((positionVertical + 2)), (sizeColum * 12), ((positionVertical + 2)), "S")
          positionVertical += (sizeRow);
          doc.setFontSize(7);
          doc.setTextColor(0, 0, 0);
          let addLine = 0;

          // Campos con data
          element.segments_det.forEach(seg_det => {

            if (column == 12 && addLine != 0) { positionVertical += (sizeRow * (addLine - 1)); addLine = 0; }

            if (seg_det.qt_name == 'TEXTO_CORTO' || seg_det.qt_name == 'FECHA' || seg_det.qt_name == 'TELEFONO' || seg_det.qt_name == 'EMAIL' || seg_det.qt_name == 'LISTA' || seg_det.qt_name == 'NUM_DECIMAL' || seg_det.qt_name == 'NUM_ENTERO' || seg_det.qt_name == 'IDENTIFICACION') {

              if (seg_det.sd_colsize == 12) { column = 1; positionVertical += sizeRow }
              if (column >= 12) { column = 1; positionVertical += (sizeRow * 2 + (sizeRow / 2)) }
              let labe = doc.splitTextToSize(seg_det.sd_question, (seg_det.sd_colsize * sizeColum))
              // Buscar posicion horizonal
              doc.text(labe, (sizeColum * column), positionVertical);
              doc.text(new String(seg_det.value).toString(), (sizeColum * column), (positionVertical + (sizeRow * labe.length)));
              doc.line(sizeColum * column, (positionVertical + sizeRow + 1), (sizeColum * 12), (positionVertical + sizeRow + 1))

              column += parseInt(seg_det.sd_colsize);
            }

            if (seg_det.qt_name == 'TEXTO_LARGO') {
              if (seg_det.sd_colsize == 12 || column >= 12) { column = 1; positionVertical += (sizeRow * 2) }
              let splitText = doc.splitTextToSize(seg_det.sd_question, (sizeBody - 20));
              if(splitText.length <= 2) { splitText = doc.splitTextToSize(seg_det.sd_question, (seg_det.sd_colsize * sizeColum)) }
              doc.text(splitText, (sizeColum * column), positionVertical);
              let splitResponse = doc.splitTextToSize(seg_det.value, (sizeColum * seg_det.sd_colsize))
              let dimentionsLonText = doc.getTextDimensions(splitText)
              doc.text(splitResponse, (sizeColum * column), positionVertical + dimentionsLonText.h);
              if (splitResponse.length >= 2 && seg_det.sd_colsize < 12) { positionVertical += sizeRow }
              doc.line(sizeColum, (positionVertical + sizeRow + 1), ((sizeColum * splitResponse.length) * 12), (positionVertical + sizeRow + 1));
              column += parseInt(seg_det.sd_colsize);
            }

            if (seg_det.qt_name == 'OPC_UNICA') {

              if (seg_det.sd_colsize == 12 || column >= 12) { column = 1; positionVertical += (sizeRow * 2) + 1 }
              let label = doc.splitTextToSize(seg_det.sd_question, sizeBody);
              if (label.length == 1) { label = doc.splitTextToSize(seg_det.sd_question, (seg_det.sd_colsize * sizeColum)) };
              doc.text(label, (sizeColum * column), (positionVertical));
              if (label.length >= 2) { positionVertical += ((label.length - 1) * sizeRow) }
              let jump = seg_det.segments_det_opt.filter(e => e.qt_name == "TABLA").length

              let positionCheck = sizeColum;
              if (column > 1) positionCheck = (sizeColum * column);
              let sumOptionsSize = 0;
              seg_det.segments_det_opt.forEach((seg_det_opt, index) => {
                let label = new String(seg_det_opt.sdo_caption).toString();
                if (seg_det_opt.qt_name == 'CHECKBOX') {

                  if (seg_det_opt.sd_colsize == 12) { column = 1; positionVertical += (sizeRow * 2) + 1 }

                  let label = doc.splitTextToSize(seg_det_opt.sdo_caption, sizeBody);
                  let dimentions = doc.getTextDimensions(`0 ${seg_det_opt.sdo_caption}`);
                  sumOptionsSize += dimentions.w;
                  doc.setDrawColor(216, 30, 5);
                  doc.setFillColor(216, 30, 5);
                  if (sumOptionsSize >= sizeBody) {
                    positionCheck = sizeColum;
                    positionVertical += sizeRow;
                  }
                  doc.circle((positionCheck + 2), ((positionVertical + 4)), 2, ((seg_det.value == seg_det_opt.sdo_caption) ? 'FD' : 'S'));
                  doc.text(label, positionCheck + 5, (positionVertical + 6))

                  if (
                    (dimentions.w >= (sizeBody - 10) ||
                      (sizeBody - dimentions.w) < sizeColum) ||
                    (positionCheck >= (sizeBody - 10) ||
                      (sizeBody - dimentions.w) < sizeColum) || jump) {
                    positionCheck = sizeColum;
                    positionVertical += sizeRow;
                  } else {
                    positionCheck += dimentions.w + 5;
                  }
                  
                  if (label.length > 1) {
                    positionVertical += 6 * label.length;
                  }

                }

                if (seg_det_opt.qt_name == 'TABLA') {
                  if (column >= 12) { column = 1; positionVertical += (sizeRow * 2 + (sizeRow / 2)) }
                  doc.circle((positionCheck + 2), ((positionVertical + 4)), 2, ((seg_det.value == seg_det_opt.sdo_caption) ? 'FD' : 'S'));
                  doc.text(label, (sizeColum * column + 5), (positionVertical + sizeRow));
                  positionVertical += (sizeRow * 3);
                  // Colocar cabeceras
                  let everyHead = sizeBody / seg_det_opt.sdo_tabnumcol;
                  let positionCol = sizeColum;
                  seg_det_opt.segments_det_opt_tbl.forEach(element => {
                    doc.text(element.sdot_colname, positionCol, positionVertical);
                    positionCol += everyHead;
                  });

                  positionVertical += sizeRow;
                  positionCol = sizeColum;
                  if (seg_det.value == seg_det_opt.sdo_caption) {
                    seg_det_opt.table.forEach((row, indexRow) => {
                      row.forEach((col, indexCol) => {
                        doc.text(new String(col['value_' + indexCol]).toString(), positionCol, (positionVertical));
                        positionCol += everyHead;
                      });
                      positionCol = sizeColum;
                      positionVertical += sizeRow;
                    });
                  }
                  positionVertical += (sizeRow) + 1
                }
              });
              // positionVertical += sizeRow;
              column += parseInt(seg_det.sd_colsize);
            }

            if (seg_det.qt_name == 'SINO_JUST_SI') {
              if (seg_det.sd_colsize == 12) { column = 1; positionVertical += (sizeRow * 2) + 1 }
              if (column >= 12) { column = 1; positionVertical += (sizeRow * 2) }
              let label = doc.splitTextToSize(seg_det.sd_question, sizeBody);
              doc.text(label, (sizeColum * column), (positionVertical));
              if (label.length > 1) { positionVertical += (sizeRow * (label.length - 1)) }
              doc.setDrawColor(216, 30, 5);
              doc.setFillColor(216, 30, 5);
              doc.circle((sizeColum * (column) + 2), ((positionVertical + 4)), 2, ((seg_det.value == 'SI') ? 'FD' : 'S'));
              doc.text('SI', (sizeColum * (column) + 5), (positionVertical + 6))
              doc.setDrawColor(216, 30, 5);
              doc.setFillColor(216, 30, 5);
              doc.circle((sizeColum * (column) + 15), ((positionVertical + 4)), 2, ((seg_det.value == 'NO') ? 'FD' : 'S'));
              doc.text('NO', (sizeColum * (column) + 18), (positionVertical + 6))
              doc.line(sizeColum, (positionVertical + sizeRow + 2), (sizeColum * seg_det.sd_colsize), (positionVertical + sizeRow + 2))
              column = 1; positionVertical += (sizeRow + 2);
              if (seg_det.value == "SI") {
                column = 1; positionVertical += (sizeRow + 2);
                seg_det.segments_det_opt.forEach(element => {
                  doc.text(element.sdo_caption, (sizeColum * column), positionVertical);
                  positionVertical += (sizeRow);
                  doc.text(element.value, (sizeColum * column), positionVertical)
                  positionVertical += sizeRow;
                });
              }
              column += parseInt(seg_det.sd_colsize);
            }

            if (seg_det.qt_name == 'SINO') {

              if (seg_det.sd_colsize == 12 || column >= 12) { column = 1; positionVertical += (sizeRow * 2) + 1 }
              let label = doc.splitTextToSize(seg_det.sd_question, sizeBody);
              doc.text(label, (sizeColum * column), (positionVertical));
              if (label.length > 1) { positionVertical += (sizeRow * (label.length - 1)) }
              doc.setDrawColor(216, 30, 5);
              doc.setFillColor(216, 30, 5);
              doc.circle((sizeColum * (column) + 2), ((positionVertical + 4)), 2, ((seg_det.value == 'SI') ? 'FD' : 'S'));
              doc.text('SI', (sizeColum * (column) + 5), (positionVertical + 6))
              doc.setDrawColor(216, 30, 5);
              doc.setFillColor(216, 30, 5);
              doc.circle((sizeColum * (column) + 15), ((positionVertical + 4)), 2, ((seg_det.value == 'NO') ? 'FD' : 'S'));
              doc.text('NO', (sizeColum * (column) + 18), (positionVertical + 6))
              doc.line(sizeColum, (positionVertical + sizeRow + 2), (sizeColum * seg_det.sd_colsize), (positionVertical + sizeRow + 2))

              positionVertical += sizeRow + 3;

              column += parseInt(seg_det.sd_colsize);
            }

            if (seg_det.qt_name == 'CHECKBOX') {
              if (seg_det.sd_colsize == 12) { column = 1; positionVertical += (sizeRow * 2) + 1 }
              let positionCheck = sizeColum;
              if (column > 1) positionCheck = sizeColum * column

              let label = doc.splitTextToSize(seg_det.sd_question, sizeBody);
              let dimentions = doc.getTextDimensions(`0 ${seg_det.sd_question}`, { maxWidth: sizeBody });
              doc.setDrawColor(216, 30, 5);
              doc.setFillColor(216, 30, 5);
              doc.rect((positionCheck), ((positionVertical + 2)), 3, 3, ((seg_det.value) ? 'FD' : 'S'));
              doc.text(label, positionCheck + 5, (positionVertical + 6))

              // if (
              //   (dimentions.w >= (sizeBody - 5) ||
              //     (sizeBody - dimentions.w) < sizeColum) ||
              //   (positionCheck >= (sizeBody - 10) ||
              //     (sizeBody - dimentions.w) < sizeColum)) {
              //   positionCheck = sizeColum;
              // } else {
              //   positionCheck += dimentions.w + 5
              // }

              column += parseInt(seg_det.sd_colsize);
              if (column >= 12) { positionVertical += sizeRow + 3; }
            }

            if (seg_det.qt_name == 'TABLE') {
              if (column >= 12) { column = 1; positionVertical += (sizeRow * 2 + (sizeRow / 2)) }
              let label = doc.splitTextToSize(seg_det.sd_caption, sizeBody);
              doc.text(label, (sizeColum * column), (positionVertical + sizeRow));
              positionVertical += (sizeRow * 3);
              // Colocar cabeceras
              let everyHead = sizeBody / seg_det.sd_tabnumcol;
              let positionCol = sizeColum;
              seg_det.segments_det_opt_tbl.forEach(element => {
                doc.text(element.sdot_colname, positionCol, positionVertical);
                positionCol += everyHead;
              });

              positionVertical += sizeRow;
              positionCol = sizeColum;
              seg_det.table.forEach((row, indexRow) => {
                row.forEach((col, indexCol) => {
                  doc.text(new String(col['value_' + indexCol]).toString(), positionCol, (positionVertical));
                  positionCol += everyHead;
                });
                positionCol = sizeColum;
                positionVertical += sizeRow;
              });

              positionVertical += (sizeRow) + 3
            }

            if (seg_det.qt_name == 'OPC_MULTI') {
              if (seg_det.sd_colsize == 12) { column = 1; positionVertical += sizeRow }
              if (column >= 12) { column = 1; positionVertical += (sizeRow * 2 + (sizeRow / 2)) }
              doc.setDrawColor(216, 30, 5);
              doc.setFillColor(216, 30, 5);
              let positionCheck = sizeColum;
              if (column > 1) positionCheck = sizeColum * column
              let jump = seg_det.segments_det_opt.filter(e => e.qt_name == "TABLA").length
              let label = doc.splitTextToSize(seg_det.sd_question, sizeBody);

              doc.text(label, (sizeColum * column), (positionVertical));
              seg_det.segments_det_opt.forEach((seg_det_opt, index) => {

                if (seg_det_opt.sd_colsize == 12) { column = 1; positionVertical += (sizeRow * 2) + 1 }

                let label = doc.splitTextToSize(seg_det_opt.sdo_caption, sizeBody);
                let dimentions = doc.getTextDimensions(`0 ${seg_det_opt.sdo_caption}`);
                doc.setDrawColor(216, 30, 5);
                doc.setFillColor(216, 30, 5);
                doc.roundedRect((positionCheck), ((positionVertical + 3)), 3, 3, 0.5, 0.5, ((seg_det_opt.value) ? 'FD' : 'S'));
                doc.text(label, positionCheck + 5, (positionVertical + 6))

                if (
                  (dimentions.w >= (sizeBody - 10) ||
                    (sizeBody - dimentions.w) < sizeColum) ||
                  (positionCheck >= (sizeBody - 10) ||
                    (sizeBody - dimentions.w) < sizeColum) || jump) {
                  positionCheck = sizeColum;
                  positionVertical += sizeRow;
                } else {
                  positionCheck += dimentions.w + 5
                }

              });

              column += parseInt(seg_det.sd_colsize);
            }

            if (seg_det.qt_name == 'INFORMATIVA' || seg_det.qt_name == 'INFORMATIVA_N') {
              if (seg_det.sd_colsize == 12 || column >= 12) { column = 1; positionVertical += sizeRow }

              let splitText = doc.splitTextToSize(seg_det.sd_question, sizeBody);
              if (splitText.length == 1) { splitText = doc.splitTextToSize(seg_det.sd_question, (seg_det.sd_colsize * sizeColum)) }
              let sizeHeight = doc.getTextDimensions(splitText);

              doc.text(splitText, (sizeColum * column), positionVertical);
              if (splitText.length >= 2 && seg_det.sd_colsize == 12) {
                positionVertical += (sizeHeight.h + 2);
              }
              if (splitText.length >= 2 && seg_det.sd_colsize != 12 && splitText.length > addLine) {
                addLine = splitText.length;
              }

              column += parseInt(seg_det.sd_colsize);
              doc.setFont("DIN", "normal");
            }

            //581
            if (positionVertical >= 530) {
              doc.addPage();
              positionVertical = 10;
            }

          });

        }

        positionVertical = positionVertical + (sizeRow * 3)

      });



      if (type == 'datauri') {
        let base64Pdf: any = doc.output("datauri");
        resolve(base64Pdf)
      }
      if (type == 'datauristring') {
        let base64Pdf: any = doc.output("datauristring");
        resolve(base64Pdf)
      }

    })

  }

  sendBase64(base64Pdf): void {
    let params = {
      token: localStorage.getItem('token'),
      pdfb64: base64Pdf
    }

    this.methods.POST(`links/finishform`, params).subscribe(response => {
      let { status } = response;
    });
  }

}
