import { Injectable } from '@angular/core';
import { jsPDF } from "jspdf";
import { MethodsService } from '../services/methods.service';
import { font } from './font';
import { fontBold } from './fontBold'

@Injectable({
  providedIn: 'root'
})
export class PdfService {

  constructor(
    private methods: MethodsService
  ) { }

  generateDoc(data: any, html: any, title: string, type: 'datauri' | 'datauristring'): Promise<any> {

    return new Promise((resolve, reject) => {
      const doc = new jsPDF({
        format: 'a4',
        unit: 'px',
        precision: 1
      });

      let positionVertical = 55;
      let sizeRow = 6;
      let sizeColum = 33;
      let column = 1;
      let sizeBody = 376;

      doc.addFileToVFS("DIN-Medium.ttf", font);
      doc.addFont("DIN-Medium.ttf", "DIN", "normal");

      doc.addFileToVFS("DIN-Bold.ttf", fontBold)
      doc.addFont("DIN-Bold.ttf", "DIN-B", "normal");

      doc.setFont("DIN");
      doc.setDrawColor(216, 30, 5);
      doc.setFillColor(216, 30, 5);

      doc.roundedRect(-5, -5, 420, 50, 3, 3, "F");
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(23);
      doc.text(title.toLocaleUpperCase(), 400, 25, { align: 'right' });
      doc.setFontSize(14);
      doc.setTextColor(0, 0, 0);

      doc.setFontSize(7);
      data.forEach(element => {
        if (element.type == 'key') {
          doc.setFontSize(10);
          let labelKey = doc.splitTextToSize(element.k_question, (12 * sizeColum))
          doc.text(labelKey, sizeColum, positionVertical);
          if (labelKey.length >= 2) { positionVertical += (labelKey.length * sizeRow) }
          if (element.k_subtitle) {
            positionVertical += sizeRow + 2;
            let rows = doc.splitTextToSize(element.s_subtitle, sizeBody);
            doc.text(rows, sizeColum, positionVertical);
            positionVertical += (sizeRow * rows.length)
          }
          doc.setDrawColor(216, 30, 5);
          doc.setFillColor(216, 30, 5);
          doc.line(sizeColum, ((positionVertical + 2)), (sizeBody + sizeColum), ((positionVertical + 2)), "S")
          if (element.k_subtitle) positionVertical += (sizeRow * 2);
          doc.setFontSize(7);
          doc.setTextColor(0, 0, 0);
          positionVertical += 3
          if (element.kt_name == 'OPC_UNICA') {
            let positionCheck = sizeColum;
            element.keys_opt.forEach((key, index) => {

              let label = doc.splitTextToSize(key.ko_value, sizeBody);
              let dimentions = doc.getTextDimensions(`0 ${key.ko_value}`);
              doc.circle((positionCheck + 2), ((positionVertical + 6)), 2, ((element.value == key.ko_id) ? 'FD' : 'S'));
              doc.text(label, positionCheck + 5, (positionVertical + 8))

              if (
                (dimentions.w >= (sizeBody - 10) ||
                  (sizeBody - dimentions.w) < sizeColum) ||
                (positionCheck >= (sizeBody - 10) ||
                  (sizeBody - dimentions.w) < sizeColum)) {
                positionCheck = sizeColum;
                positionVertical += sizeRow;
              } else {
                positionCheck += dimentions.w + 5
              }

            });
          }

          if (element.kt_name == 'NUM_ENTERO') {
            if (element.sd_colsize == 12) { column = 1; positionVertical += sizeRow }
            if (column >= 12) { column = 1; positionVertical += (sizeRow * 2 + (sizeRow / 2)) }
            doc.text(new String(element.value).toString(), (sizeColum * column), (positionVertical + sizeRow));
          }

          positionVertical += sizeRow;

        }

        if (element.type == 'segment') {

          let x, y, width, height = 0;
          let borderRadius = 3;
          doc.setFontSize(10);
          x = sizeColum - 3; y = positionVertical - 3;
          height = y;
          width = (sizeBody + 9);
          positionVertical += sizeRow;
          doc.text(element.s_title, sizeColum, positionVertical);
          if (element.s_subtitle) {
            positionVertical += sizeRow + 2;
            let rows = doc.splitTextToSize(element.s_subtitle, sizeBody);
            let dimentions = doc.getTextDimensions(rows);
            doc.text(rows, sizeColum, positionVertical);
            if (rows.length >= 2) { positionVertical += (rows.length * sizeRow) };
          }

          doc.line(sizeColum, ((positionVertical + 2)), (sizeBody + sizeColum), ((positionVertical + 2)), "S")
          positionVertical += (sizeRow);
          doc.setFontSize(7);
          doc.setTextColor(0, 0, 0);
          let addLine = 0;


          // Campos con data
          element.segments_det.forEach(seg_det => {

            if (column >= 12 && addLine != 0) { positionVertical += (sizeRow * (addLine - 1)); addLine = 0; }

            if (seg_det.qt_name == 'TEXTO_CORTO' || seg_det.qt_name == 'FECHA' || seg_det.qt_name == 'TELEFONO' || seg_det.qt_name == 'EMAIL' || seg_det.qt_name == 'LISTA' || seg_det.qt_name == 'NUM_DECIMAL' || seg_det.qt_name == 'NUM_ENTERO' || seg_det.qt_name == 'IDENTIFICACION') {

              if (seg_det.sd_colsize == 12) { column = 1; positionVertical += sizeRow }
              if (column >= 12) { column = 1; positionVertical += (sizeRow * 2 + (sizeRow / 2)) }
              let labe = doc.splitTextToSize(seg_det.sd_question, (seg_det.sd_colsize * sizeColum))
              // Buscar posicion horizonal
              doc.text(labe, (sizeColum * column), positionVertical);
              doc.text(new String((seg_det.value) ? seg_det.value : '').toString(), (sizeColum * column), (positionVertical + (sizeRow * labe.length)));
              doc.line(sizeColum * column, (positionVertical + sizeRow + 1), (sizeBody + sizeColum), (positionVertical + sizeRow + 1))

              column += parseInt(seg_det.sd_colsize);
            }

            if (seg_det.qt_name == 'TEXTO_LARGO') {
              if (seg_det.sd_colsize == 12 || column >= 12) { column = 1; positionVertical += (sizeRow * 2) }
              let splitTextQuestion = doc.splitTextToSize(seg_det.sd_question, (seg_det.sd_colsize * sizeColum));
              doc.text(splitTextQuestion, (sizeColum * column), positionVertical);
              let splitResponse = doc.splitTextToSize((seg_det.value) ? seg_det.value : '', (sizeColum * seg_det.sd_colsize))
              let positionRes = (splitTextQuestion.length > 1) ? positionVertical + (sizeRow * (splitTextQuestion.length)) : positionVertical + sizeRow;
              doc.text(splitResponse, (sizeColum * column), positionRes);
              if (splitResponse.length >= 2 && seg_det.sd_colsize <= 12) { positionVertical += (sizeRow * (splitResponse.length - 1)) }
              doc.line(sizeColum, (positionVertical + sizeRow + 1), ((sizeBody + sizeColum)), (positionVertical + sizeRow + 1));
              column += parseInt(seg_det.sd_colsize);
            }

            if (seg_det.qt_name == 'OPC_UNICA') {

              if (seg_det.sd_colsize == 12 || column >= 12) { column = 1; positionVertical += (sizeRow * 2) + 1 }
              let label = doc.splitTextToSize(seg_det.sd_question, sizeBody);
              if (label.length == 1) { label = doc.splitTextToSize(seg_det.sd_question, (seg_det.sd_colsize * sizeColum)) };
              doc.text(label, (sizeColum * column), (positionVertical));
              if (label.length >= 2) { positionVertical += ((label.length - 1) * sizeRow) }
              let jump = seg_det.segments_det_opt.filter(e => e.qt_name == "TABLA").length

              let positionCheck = sizeColum;
              if (column > 1) positionCheck = (sizeColum * column);
              let sumOptionsSize = 0;
              seg_det.segments_det_opt.forEach((seg_det_opt, index) => {

                if (seg_det_opt.qt_name == 'CHECKBOX') {

                  if (seg_det_opt.sd_colsize == 12) { column = 1; positionVertical += (sizeRow * 2) + 1 }

                  let label = doc.splitTextToSize(seg_det_opt.sdo_caption, seg_det.sd_colsize * sizeColum);
                  let dimentions = doc.getTextDimensions(`0 ${seg_det_opt.sdo_caption}`);
                  sumOptionsSize += dimentions.w;
                  doc.setDrawColor(216, 30, 5);
                  doc.setFillColor(216, 30, 5);

                  if (sumOptionsSize >= (seg_det.sd_colsize * sizeColum)) {
                    positionCheck = sizeColum;
                    positionVertical += sizeRow;
                    sumOptionsSize = 0;
                  }
                  doc.circle((positionCheck + 2), ((positionVertical + 4)), 2, ((seg_det.value == seg_det_opt.sdo_caption) ? 'FD' : 'S'));
                  doc.text(label, positionCheck + 5, (positionVertical + 6))

                  positionCheck += dimentions.w + 5;

                  if (label.length > 1) {
                    positionVertical += 6 * label.length;
                  }

                }

                if (seg_det_opt.qt_name == 'TABLA') {
                  // Verificar si trae datos
                  let show = false;
                  seg_det_opt.table.forEach((row, indexRow) => {
                    row.forEach((col, indexCol) => {
                      if (col['value_' + indexCol]) {
                        show = true;
                        return
                      }
                    });
                  });

                  if (show) {
                    if (column >= 12) { column = 1; positionVertical += (sizeRow * 2 + (sizeRow / 2)) }
                    doc.circle((positionCheck + 2), ((positionVertical + 4)), 2, ((seg_det.value == seg_det_opt.sdo_caption) ? 'FD' : 'S'));
                    doc.text(label, (sizeColum * column + 5), (positionVertical + sizeRow));
                    positionVertical += (sizeRow * 3);
                    // Colocar cabeceras
                    let everyHead = sizeBody / seg_det_opt.sdo_tabnumcol;
                    let positionCol = sizeColum;
                    let down = 0;
                    seg_det_opt.segments_det_opt_tbl.forEach(element => {
                      let labelCol = doc.splitTextToSize(element.sdot_colname, everyHead);
                      doc.text(labelCol, positionCol, positionVertical);
                      positionCol += everyHead;
                      if (labelCol.length > down) { down = labelCol.length }
                    });

                    positionVertical += sizeRow;
                    positionCol = sizeColum;
                    if (down) { positionVertical += (sizeRow * (down - 1)) }
                    if (seg_det.value == seg_det_opt.sdo_caption) {
                      seg_det_opt.table.forEach((row, indexRow) => {
                        row.forEach((col, indexCol) => {
                          let labelRes = doc.splitTextToSize(col['value_' + indexCol], everyHead);
                          doc.text(labelRes.toString(), positionCol, (positionVertical));
                          positionCol += everyHead;
                          if (labelRes.length > down) { down = labelRes.length }
                        });
                        positionCol = sizeColum;
                        positionVertical += sizeRow;
                      });
                    }
                    positionVertical += (sizeRow) + 1
                  }

                }
              });
              // positionVertical += sizeRow;
              column += parseInt(seg_det.sd_colsize);
            }

            if (seg_det.qt_name == 'SINO_JUST_SI') {
              if (seg_det.sd_colsize == 12) { column = 1; positionVertical += (sizeRow * 2) + 1 }
              if (column >= 12) { column = 1; positionVertical += (sizeRow * 2) }
              let label = doc.splitTextToSize(seg_det.sd_question, sizeBody);
              doc.text(label, (sizeColum * column), (positionVertical));
              if (label.length > 1) { positionVertical += (sizeRow * (label.length - 1)) }
              doc.setDrawColor(216, 30, 5);
              doc.setFillColor(216, 30, 5);
              doc.circle((sizeColum * (column) + 2), ((positionVertical + 4)), 2, ((seg_det.value == 'SI') ? 'FD' : 'S'));
              doc.text('SI', (sizeColum * (column) + 5), (positionVertical + 6))
              doc.setDrawColor(216, 30, 5);
              doc.setFillColor(216, 30, 5);
              doc.circle((sizeColum * (column) + 15), ((positionVertical + 4)), 2, ((seg_det.value == 'NO') ? 'FD' : 'S'));
              doc.text('NO', (sizeColum * (column) + 18), (positionVertical + 6))
              doc.line(sizeColum, (positionVertical + sizeRow + 2), (sizeBody + sizeColum), (positionVertical + sizeRow + 2))
              column = 1; positionVertical += (sizeRow + 2);
              if (seg_det.value == "SI") {
                column = 1; positionVertical += (sizeRow + 2);
                seg_det.segments_det_opt.forEach(element => {
                  doc.text(element.sdo_caption, (sizeColum * column), positionVertical);
                  positionVertical += (sizeRow);
                  doc.text((element.value) ? element.value : '', (sizeColum * column), positionVertical)
                  positionVertical += sizeRow;
                });
              }
              column += parseInt(seg_det.sd_colsize);
            }

            if (seg_det.qt_name == 'SINO') {

              if (seg_det.sd_colsize == 12 || column >= 12) { column = 1; positionVertical += (sizeRow * 2) + 1 }
              let label = doc.splitTextToSize(seg_det.sd_question, sizeBody);
              doc.text(label, (sizeColum * column), (positionVertical));
              if (label.length > 1) { positionVertical += (sizeRow * (label.length - 1)) }
              doc.setDrawColor(216, 30, 5);
              doc.setFillColor(216, 30, 5);
              doc.circle((sizeColum * (column) + 2), ((positionVertical + 4)), 2, ((seg_det.value == 'SI') ? 'FD' : 'S'));
              doc.text('SI', (sizeColum * (column) + 5), (positionVertical + 6))
              doc.setDrawColor(216, 30, 5);
              doc.setFillColor(216, 30, 5);
              doc.circle((sizeColum * (column) + 15), ((positionVertical + 4)), 2, ((seg_det.value == 'NO') ? 'FD' : 'S'));
              doc.text('NO', (sizeColum * (column) + 18), (positionVertical + 6))
              doc.line(sizeColum, (positionVertical + sizeRow + 2), (sizeBody + sizeColum), (positionVertical + sizeRow + 2))

              column += parseInt(seg_det.sd_colsize);

              if (column >= 12 || seg_det.sd_colsize == 12) { positionVertical += sizeRow }
            }

            if (seg_det.qt_name == 'CHECKBOX') {
              if (seg_det.sd_colsize == 12) { column = 1; positionVertical += (sizeRow * 2) + 1 }
              let positionCheck = sizeColum;
              if (column > 1) positionCheck = sizeColum * column

              let label = doc.splitTextToSize(seg_det.sd_question, sizeBody);
              let dimentions = doc.getTextDimensions(`0 ${seg_det.sd_question}`, { maxWidth: sizeBody });
              doc.setDrawColor(216, 30, 5);
              doc.setFillColor(216, 30, 5);
              doc.rect((positionCheck), ((positionVertical + 2)), 3, 3, ((seg_det.value) ? 'FD' : 'S'));
              doc.text(label, positionCheck + 5, (positionVertical + 6))

              // if (
              //   (dimentions.w >= (sizeBody - 5) ||
              //     (sizeBody - dimentions.w) < sizeColum) ||
              //   (positionCheck >= (sizeBody - 10) ||
              //     (sizeBody - dimentions.w) < sizeColum)) {
              //   positionCheck = sizeColum;
              // } else {
              //   positionCheck += dimentions.w + 5
              // }

              column += parseInt(seg_det.sd_colsize);
              if (column >= 12) { positionVertical += sizeRow + 3; }
            }

            if (seg_det.qt_name == 'TABLA') {

              let showTable = false;
              seg_det.table.forEach((row, indexRow) => {
                row.forEach((col, indexCol) => {
                  if (col['value_' + indexCol]) {
                    showTable = true;
                    return;
                  }
                });

              });

              if (showTable) {
                if (column >= 12) { column = 1; positionVertical += (sizeRow * 2 + (sizeRow / 2)) }
                let label = doc.splitTextToSize(seg_det.sd_question, sizeBody);
                doc.text(label, (sizeColum * column), (positionVertical + sizeRow));
                positionVertical += (sizeRow * 3);
                // Colocar cabeceras
                let everyHead = sizeBody / seg_det.sd_tabnumcol;
                let positionCol = sizeColum;
                let down = 0;

                seg_det.segments_det_tbl.forEach(element => {
                  let labelCol = doc.splitTextToSize(element.sdt_colname, everyHead);
                  doc.text(labelCol, positionCol, positionVertical);
                  positionCol += everyHead;
                  if (labelCol.length > down) { down = labelCol.length }
                });

                doc.line(sizeColum * column, (positionVertical + 1), (sizeBody + sizeColum), (positionVertical + 1))

                positionVertical += sizeRow;
                if (down) { positionVertical += (sizeRow * (down - 1)) }
                positionCol = sizeColum;
                down = 0;
                seg_det.table.forEach((row, indexRow) => {
                  row.forEach((col, indexCol) => {
                    let labelRes = doc.splitTextToSize(col['value_' + indexCol].toString(), everyHead);
                    doc.text(labelRes, positionCol, (positionVertical));
                    positionCol += everyHead;
                    if (labelRes.length > down) { down = labelRes.length }
                  });
                  positionCol = sizeColum;
                  positionVertical += sizeRow;
                  if (down) { positionVertical += (sizeRow * (down - 1)) }
                });

                positionVertical += (sizeRow) + 3
              }

            }

            if (seg_det.qt_name == 'OPC_MULTI') {
              if (seg_det.sd_colsize == 12) { column = 1; positionVertical += sizeRow }
              if (column >= 12) { column = 1; positionVertical += (sizeRow * 2 + (sizeRow / 2)) }
              doc.setDrawColor(216, 30, 5);
              doc.setFillColor(216, 30, 5);
              let positionCheck = sizeColum;
              if (column > 1) positionCheck = sizeColum * column
              let jump = seg_det.segments_det_opt.filter(e => e.qt_name == "TABLA").length
              let label = doc.splitTextToSize(seg_det.sd_question, sizeBody);

              doc.text(label, (sizeColum * column), (positionVertical));
              seg_det.segments_det_opt.forEach((seg_det_opt, index) => {

                if (seg_det_opt.sd_colsize == 12) { column = 1; positionVertical += (sizeRow * 2) + 1 }

                let label = doc.splitTextToSize(seg_det_opt.sdo_caption, sizeBody);
                let dimentions = doc.getTextDimensions(`0 ${seg_det_opt.sdo_caption}`);
                doc.setDrawColor(216, 30, 5);
                doc.setFillColor(216, 30, 5);
                doc.roundedRect((positionCheck), ((positionVertical + 3)), 3, 3, 0.5, 0.5, ((seg_det_opt.value) ? 'FD' : 'S'));
                doc.text(label, positionCheck + 5, (positionVertical + 6))

                if (
                  (dimentions.w >= (sizeBody - 10) ||
                    (sizeBody - dimentions.w) < sizeColum) ||
                  (positionCheck >= (sizeBody - 10) ||
                    (sizeBody - dimentions.w) < sizeColum) || jump) {
                  positionCheck = sizeColum;
                  positionVertical += sizeRow;
                } else {
                  positionCheck += dimentions.w + 5
                }

              });

              column += parseInt(seg_det.sd_colsize);
            }

            if (seg_det.qt_name == 'COMPLETAR') {
              if (seg_det.sd_colsize == 12) { column = 1; positionVertical += (sizeRow * 3) }
              if (column >= 12) { column = 1; positionVertical += (sizeRow * 3) }
              let array = seg_det.sd_question.split('{}');
              let answer = '';
              array.forEach((element, i) => {
                answer += element
                if (seg_det.value[i]) {
                  let text = (seg_det.value[i]) ? seg_det.value[i] : '';
                  answer += ' ' + text;
                }
              });
              let label = doc.splitTextToSize(answer, (seg_det.sd_colsize * sizeColum));
              doc.text(label, (sizeColum * column), positionVertical);
            }

            if (seg_det.qt_name == 'INFORMATIVA' || seg_det.qt_name == 'INFORMATIVA_N') {
              if (seg_det.sd_colsize == 12 || column >= 12) { column = 1; positionVertical += sizeRow }

              let splitText = doc.splitTextToSize(seg_det.sd_question, (seg_det.sd_colsize * sizeColum));
              let sizeHeight = doc.getTextDimensions(splitText);

              doc.text(splitText, (sizeColum * column), positionVertical);
              if (splitText.length >= 2 && seg_det.sd_colsize == 12) {
                positionVertical += (splitText.length * sizeRow);
              }
              if (splitText.length >= 2 && seg_det.sd_colsize != 12 && splitText.length > addLine) {
                addLine = splitText.length;
              }

              column += parseInt(seg_det.sd_colsize);
              doc.setFont("DIN", "normal");
            }

            //581
            if (positionVertical >= 548) {
              doc.addPage();
              positionVertical = 10;
            }

          });

          // doc.roundedRect(x, y, width, (positionVertical - y), borderRadius, borderRadius)

        }

        positionVertical = positionVertical + (sizeRow * 3)

      });



      if (type == 'datauri') {
        let base64Pdf: any = doc.output("datauri");
        resolve(base64Pdf)
      }
      if (type == 'datauristring') {
        let base64Pdf: any = doc.output("datauristring");
        resolve(base64Pdf)
      }

    })

  }

  secondMethod(data: any, html: any, title: string, type: 'datauri' | 'datauristring'): Promise<any> {
    return new Promise((resolve, reject) => {

      const doc = new jsPDF({
        format: 'a4',
        unit: 'px',
        precision: 1
      });

      doc.addFileToVFS("DIN-Medium.ttf", font);
      doc.addFont("DIN-Medium.ttf", "DIN", "normal");

      doc.addFileToVFS("DIN-Bold.ttf", fontBold)
      doc.addFont("DIN-Bold.ttf", "DIN-B", "normal");

      doc.setFont("DIN");
      doc.setDrawColor(216, 30, 5);
      doc.setFillColor(216, 30, 5);

      doc.roundedRect(-5, -5, 420, 50, 3, 3, "F");
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(23);
      let img = new Image();
      img.src = '/assets/images/logo-white.png';
      doc.addImage(img, 'png', 8, 10, 80, 26);
      doc.text(title.toLocaleUpperCase(), 410, 30, { align: 'right' });
      doc.setFontSize(14);
      doc.setTextColor(0, 0, 0);

      let positionVertical = 60;
      let sizeRow = 7.5;
      let sizeColum = 29.5;
      let column = 1;
      let sizeBody = (sizeColum * 12) + sizeColum;
      let indexCompare = 0;
      let pageSize = 632;
      let flagCloseContainer = true;
      // Hight 631.4175
      // Width 446.46
      // Container 354
      // Columa 29.5

      data.forEach((element: any, index: number) => {

        if (indexCompare != index) {
          indexCompare = index;
          positionVertical += (sizeRow * 2);
        }

        // Definir de donde comienza el cuadro
        let xRect = (sizeColum - 3);
        let yRect = (positionVertical - 10);
        let wRect = sizeBody;
        column = 1;

        if (element.type == 'key') {
          doc.setFontSize(10);
          doc.setFont("DIN-B")
          let labelKey = doc.splitTextToSize(element.k_question, sizeBody);
          doc.text(labelKey, sizeColum, positionVertical);
          let dimentions = doc.getTextDimensions(labelKey);
          positionVertical += dimentions.h + 2;

          // Verificamos si tiene subtitulo
          if (element.k_subtitle) {
            let labelSubtitle = doc.splitTextToSize(element.k_subtitle, sizeBody);
            doc.text(labelSubtitle, sizeColum, positionVertical);
            let dimentionsSubtitle = doc.getTextDimensions(labelSubtitle);
            positionVertical += dimentionsSubtitle.h + 2;
          }

          doc.line(sizeColum, positionVertical - sizeRow, sizeBody + sizeColum, positionVertical - sizeRow);

          doc.setFontSize(7);
          doc.setFont("DIN")
          // Verificamos el tipo de key
          if (element.kt_name == 'OPC_UNICA') {
            let positionCheck = sizeColum;
            element.keys_opt.forEach((key: any) => {
              let labelCheck = doc.splitTextToSize(key.ko_value, sizeBody);
              let dimentionsCheck = doc.getTextDimensions(`0  ${labelCheck}`);
              (element.value == key.ko_id) ? doc.setFillColor(216, 30, 5) : doc.setFillColor(255, 255, 255);
              doc.circle((positionCheck + 2), ((positionVertical - 2)), 2, 'FD');
              doc.text(labelCheck, positionCheck + 5, (positionVertical))
              positionCheck += dimentionsCheck.w
              if (positionCheck >= sizeBody) { positionCheck = sizeColum; positionVertical += dimentions.h }
            });
          }

          if (element.kt_name == 'NUM_ENTERO') {
            positionVertical += 3
            doc.text(new String(element.value).toString(), (sizeColum), (positionVertical));
          }

          positionVertical += sizeRow;

        }

        if (element.type == 'segment') {


          doc.setFontSize(10);
          doc.setFont("DIN-B")
          let labelTitle = doc.splitTextToSize(element.s_title, (sizeBody));
          let titleDimentions = doc.getTextDimensions(labelTitle);
          doc.text(labelTitle, sizeColum, positionVertical);
          positionVertical += titleDimentions.h;
          if (element.s_subtitle) {
            let labelSubtitle = doc.splitTextToSize(element.s_subtitle, sizeBody);
            let subtitleDimenstions = doc.getTextDimensions(labelSubtitle);
            doc.text(labelSubtitle, sizeColum, positionVertical);
            positionVertical += subtitleDimenstions.h;
          }

          doc.line(sizeColum, (positionVertical - sizeRow) + 2, sizeBody + sizeColum, (positionVertical - sizeRow) + 2, "S");

          positionVertical += 2;
          doc.setFontSize(7);
          let addLineBreak = 0;
          doc.setFont("DIN")
          // Recorremos los campos del segmento
          element.segments_det.forEach((seg_det: any, indexSegment: number) => {

            if (column >= 13 || (seg_det.sd_colsize == 12 && column < 12) || (parseInt(seg_det.sd_colsize) + column >= 14)) {
              positionVertical += addLineBreak + 3;
              addLineBreak = 0;
              column = 1;
            }

            if (!flagCloseContainer) {
              xRect = (sizeColum - 3);
              yRect = (positionVertical - 10);
              wRect = sizeBody;
            }


            if (seg_det.qt_name == 'TEXTO_CORTO' ||
              seg_det.qt_name == 'FECHA' ||
              seg_det.qt_name == 'TELEFONO' ||
              seg_det.qt_name == 'EMAIL' ||
              seg_det.qt_name == 'LISTA' ||
              seg_det.qt_name == 'NUM_DECIMAL' ||
              seg_det.qt_name == 'NUM_ENTERO' ||
              seg_det.qt_name == 'IDENTIFICACION' ||
              seg_det.qt_name == 'MM/AA') {
              // Ubicamos la pregunta
              doc.setFont("DIN-B");
              let labelQuestion = doc.splitTextToSize(seg_det.sd_question, (sizeColum * parseInt(seg_det.sd_colsize)));
              let questionDimentions = doc.getTextDimensions(labelQuestion);
              doc.text(labelQuestion, (column * sizeColum), positionVertical);

              doc.setFont("DIN");
              // Ubicamos la respuesta
              let labelAnswer = doc.splitTextToSize((seg_det.value) ? seg_det.value : '', (sizeColum * parseInt(seg_det.sd_colsize)));
              let answerDimentions = doc.getTextDimensions(labelAnswer);
              doc.text(labelAnswer, (column * sizeColum), (positionVertical + questionDimentions.h + 1));
              let aditional = questionDimentions.h;
              aditional += (seg_det.value) ? answerDimentions.h : sizeRow;
              if (aditional > addLineBreak) {
                addLineBreak = aditional;
              }
              column += parseInt(seg_det.sd_colsize);

            }


            if (seg_det.qt_name === 'TEXTO_LARGO') {
              // Ubicamos la pregunta
              doc.setFont("DIN-B");
              let labelQuestion = doc.splitTextToSize(seg_det.sd_question, (sizeColum * parseInt(seg_det.sd_colsize)));
              let questionDimentions = doc.getTextDimensions(labelQuestion);
              doc.text(labelQuestion, (column * sizeColum), positionVertical);

              doc.setFont("DIN");
              // Ubicamos la respuesta
              let labelAnswer = doc.splitTextToSize((seg_det.value) ? seg_det.value : '', (sizeColum * parseInt(seg_det.sd_colsize)));
              let answerDimentions = doc.getTextDimensions(labelAnswer);
              doc.text(labelAnswer, (column * sizeColum), (positionVertical + questionDimentions.h + 1));
              let aditional = questionDimentions.h;
              aditional += (seg_det.value) ? answerDimentions.h : sizeRow;
              if (aditional > addLineBreak) {
                addLineBreak = aditional;
              }
              column += parseInt(seg_det.sd_colsize);
            }

            if (seg_det.qt_name === 'SINO_JUST_SI') {
              let labelQuestion = doc.splitTextToSize(seg_det.sd_question, (sizeColum * parseInt(seg_det.sd_colsize)));
              let questionDimentions = doc.getTextDimensions(labelQuestion);
              let aditional: number = 0;
              aditional = questionDimentions.h;
              doc.setFont("DIN-B");
              doc.text(labelQuestion, (column * sizeColum), positionVertical);
              doc.setFont("DIN");
              ((seg_det.value == 'SI') ? doc.setFillColor(216, 30, 5) : doc.setFillColor(255, 255, 255));
              doc.circle((sizeColum * (column) + 2), ((positionVertical + aditional - 1)), 2, 'DF');
              doc.text('SI', (sizeColum * (column) + 5), (positionVertical + aditional + 1));
              ((seg_det.value == 'NO') ? doc.setFillColor(216, 30, 5) : doc.setFillColor(255, 255, 255));
              doc.circle((sizeColum * (column) + 15), ((positionVertical + aditional - 1)), 2, 'DF');
              doc.text('NO', (sizeColum * (column) + 18), (positionVertical + aditional + 1))
              let aditionalFields = 0;
              if (seg_det.value == 'SI') {
                // Mostrar demas campos
                aditionalFields += (aditional) + 7;
                let positionCheck = (sizeColum * column);
                let sizeColumComplete = sizeColum * seg_det.sd_colsize;
                let sizeBusy = 0;
                let countBreak = 0;
                seg_det.segments_det_opt.forEach((seg_det_opt: any) => {

                  if (seg_det_opt.qt_name !== 'COMPLETAR' && seg_det_opt.qt_name !== 'CHECKBOX') {
                    let labelSegDetOpt = doc.splitTextToSize(seg_det_opt.sdo_caption, (sizeColum * seg_det.sd_colsize));
                    let labelSegDetOptDimentions = doc.getTextDimensions(labelSegDetOpt);
                    doc.setFont("DIN-B");
                    doc.text(labelSegDetOpt, (sizeColum * column), positionVertical + aditionalFields);
                    let labelAnswer = doc.splitTextToSize((seg_det_opt.value) ? seg_det_opt.value : '', (sizeColum * seg_det.sd_colsize));
                    let labelAnswerDimentions = doc.getTextDimensions(labelAnswer);
                    doc.setFont("DIN");
                    doc.text(labelAnswer, (sizeColum * column), positionVertical + labelSegDetOptDimentions.h + aditionalFields);
                    aditionalFields += (labelSegDetOptDimentions.h + labelAnswerDimentions.h);
                  }

                  if (seg_det_opt.qt_name == 'COMPLETAR') {
                    let array = seg_det_opt.sdo_caption.split('{}');
                    let answer = '';
                    array.forEach((element: any, i: number) => {
                      answer += element
                      if (seg_det_opt?.value && seg_det_opt?.value[i]) {
                        let text = (seg_det_opt.value[i]) ? seg_det_opt.value[i] : '';
                        answer += ' ' + text;
                      } else {
                        answer += (i < array.length - 1) ? '_____' : '';
                      }
                    });
                    let label = doc.splitTextToSize(answer, (seg_det.sd_colsize * sizeColum));
                    let dimentions = doc.getTextDimensions(label);
                    doc.text(label, (sizeColum * column), positionVertical + aditionalFields);
                    positionVertical += dimentions.h;
                  }

                  if (seg_det_opt.qt_name == 'CHECKBOX') {
                    let labelCheck = doc.splitTextToSize(seg_det_opt.sdo_caption, sizeColumComplete);
                    let dimentionsCheck = doc.getTextDimensions(labelCheck);
                    if (labelCheck.length >= 2) { positionCheck = sizeColum * column; }
                    // Se calcula el espacio que queda
                    let quedaEspacio = (sizeColumComplete - sizeBusy);
                    // Se verifica si el campo nuevo cabe en el espacio que queda
                    if (dimentionsCheck.w > quedaEspacio && index != 0) { positionCheck = sizeColum * column; countBreak++; aditional += (dimentionsCheck.h + 2); }
                    (seg_det_opt?.value && seg_det_opt.value == true) ? doc.setFillColor(216, 30, 5) : doc.setFillColor(255, 255, 255);
                    doc.roundedRect((positionCheck), ((positionVertical - 4) + aditional + aditionalFields), 4, 4, 1, 1, 'DF');
                    doc.text(labelCheck, positionCheck + 5, (positionVertical) + aditional + aditionalFields)
                    if (labelCheck.length >= 2) { aditional += dimentionsCheck.h + 2; sizeBusy = 0; }
                    if (labelCheck.length == 1) { positionCheck += Math.round(dimentionsCheck.w) + 7; sizeBusy += Math.round(dimentionsCheck.w); }
                    if (sizeBusy > sizeColumComplete) { sizeBusy = 0 }
                  }

                });
                aditional += aditionalFields;
              } else {
                aditional += 5;
              }

              if (aditional > addLineBreak) { addLineBreak = aditional; }

              column += parseInt(seg_det.sd_colsize);

            }

            if (seg_det.qt_name === 'SINO') {
              doc.setFont("DIN-B");
              let labelQuestion = doc.splitTextToSize(seg_det.sd_question, (sizeColum * seg_det.sd_colsize));
              let labelQuestionDimentions = doc.getTextDimensions(labelQuestion);
              let aditional = 0;
              doc.text(labelQuestion, (sizeColum * column), positionVertical);
              aditional = labelQuestionDimentions.h;
              doc.setFont("DIN");
              ((seg_det.value == 'SI') ? doc.setFillColor(216, 30, 5) : doc.setFillColor(255, 255, 255));
              doc.circle((sizeColum * (column) + 2), ((positionVertical + aditional - 1)), 2, 'DF');
              doc.text('SI', (sizeColum * (column) + 5), (positionVertical + 1 + aditional));
              ((seg_det.value == 'NO') ? doc.setFillColor(216, 30, 5) : doc.setFillColor(255, 255, 255));
              doc.circle((sizeColum * (column) + 15), ((positionVertical + aditional - 1)), 2, 'DF');
              doc.text('NO', (sizeColum * (column) + 18), (positionVertical + 1 + aditional))
              aditional += 6;
              if (aditional > addLineBreak) {
                addLineBreak = aditional;
              }

              column += parseInt(seg_det.sd_colsize);
            }

            if (seg_det.qt_name === 'OPC_UNICA') {
              doc.setFont("DIN-B");
              let sizeColumComplete = sizeColum * seg_det.sd_colsize;
              let labelQuestion = doc.splitTextToSize(seg_det.sd_question, sizeColumComplete);
              let labelQuestionDimentions = doc.getTextDimensions(labelQuestion);
              let aditional = labelQuestionDimentions.h + 1;
              doc.text(labelQuestion, (sizeColum * column), positionVertical);
              let positionCheck = (sizeColum * column);
              doc.setFont("DIN");
              let countBreak = 0;
              let sizeBusy = 0;

              seg_det.segments_det_opt.forEach((seg_det_opt: any, index: number) => {
                if (seg_det_opt.qt_name == 'CHECKBOX') {
                  let labelCheck = doc.splitTextToSize(seg_det_opt.sdo_caption, sizeColumComplete);
                  let dimentionsCheck = doc.getTextDimensions(labelCheck);
                  if (labelCheck.length >= 2) { positionCheck = sizeColum * column; }
                  // Se calcula el espacio que queda
                  let quedaEspacio = (sizeColumComplete - sizeBusy);
                  // Se verifica si el campo nuevo cabe en el espacio que queda
                  if (dimentionsCheck.w > quedaEspacio && index != 0) { positionCheck = sizeColum * column; countBreak++; aditional += (dimentionsCheck.h + 2); }
                  (seg_det.value == seg_det_opt.sdo_caption) ? doc.setFillColor(216, 30, 5) : doc.setFillColor(255, 255, 255);
                  doc.circle((positionCheck + 2), ((positionVertical - 2) + aditional), 2, 'DF');
                  doc.text(labelCheck, positionCheck + 5, (positionVertical) + aditional)
                  if (labelCheck.length >= 2) { aditional += dimentionsCheck.h + 2; sizeBusy = 0; }
                  if (labelCheck.length == 1) { positionCheck += Math.round(dimentionsCheck.w) + 7; sizeBusy += Math.round(dimentionsCheck.w); }
                  if (sizeBusy > sizeColumComplete) { sizeBusy = 0 }

                }

                if (seg_det_opt.qt_name == 'TABLA') {
                  let labelCheck = doc.splitTextToSize(seg_det_opt.sdo_caption, sizeBody - 3);
                  let dimentionsCheck = doc.getTextDimensions(labelCheck);
                  positionVertical += sizeRow;
                  positionCheck = sizeColum * column;
                  (seg_det.value == seg_det_opt.sdo_caption) ? doc.setFillColor(216, 30, 5) : doc.setFillColor(255, 255, 255);
                  doc.circle((positionCheck + 2), ((positionVertical - 2) + aditional), 2, 'DF');
                  doc.text(labelCheck, positionCheck + 5, (positionVertical + aditional))
                  positionVertical += sizeRow + 3;
                  let everyHead = sizeBody / seg_det_opt.sdo_tabnumcol;
                  let positionCol = sizeColum;
                  if (labelCheck.length >= 2) { positionVertical += dimentionsCheck.h }
                  if (seg_det.value == seg_det_opt.sdo_caption) {
                    // Linea de cabecera de tabla
                    doc.line(sizeColum - 1, (positionVertical + aditional) - sizeRow, sizeBody + sizeColum, (positionVertical + aditional) - sizeRow);
                    let addBreakLineTable = 0;
                    doc.setFont("DIN-B");
                    seg_det_opt.segments_det_opt_tbl.forEach((seg_det_opt_table: any, index: number) => {
                      let labelHead = doc.splitTextToSize(seg_det_opt_table.sdot_colname, everyHead);
                      doc.text(labelHead, positionCol, positionVertical + aditional);
                      // doc.line(positionCol - 1, positionVertical + 2, positionCol - 1, positionVertical - sizeRow);
                      positionCol += everyHead;
                      // Si tiene dos lineas hacer el brinco de linea
                      if (labelHead.length >= 2 && labelHead.length > addBreakLineTable) {
                        addBreakLineTable = (labelHead.length - 1)
                      }
                    });
                    if (addBreakLineTable) { positionVertical += (sizeRow * addBreakLineTable) }
                    // doc.line(sizeBody + sizeColum, positionVertical + 2, sizeBody + sizeColum, positionVertical - sizeRow);
                    positionVertical += 2;
                    doc.line(sizeColum - 1, positionVertical + aditional, sizeBody + sizeColum, positionVertical + aditional);
                    positionVertical += sizeRow;
                    let addHeight = false;
                    doc.setFont("DIN");
                    // Imprimir los datos de la tabla                  
                    seg_det_opt.table.forEach((row: any, indexRow: number) => {
                      let firtsCel = row[0];
                      if (firtsCel['value_0']) {
                        positionCol = sizeColum;
                        let dimentionValue = 0;
                        row.forEach((col: any, indexCol: number) => {
                          let labelRes = doc.splitTextToSize(col['value_' + indexCol].toString(), everyHead);
                          dimentionValue = doc.getTextDimensions(labelRes).h;
                          doc.text(labelRes, positionCol, (positionVertical + aditional));
                          positionCol += everyHead;
                          if (labelRes.length >= 2) { addHeight = true; }
                        });
                        positionVertical += sizeRow;
                        if (addHeight) { positionVertical += dimentionValue; addHeight = false; }
                      }
                    });
                  }
                }

              });

              if (aditional > addLineBreak) { addLineBreak = aditional + 5 }

              column += parseInt(seg_det.sd_colsize);
            }

            if (seg_det.qt_name == 'CHECKBOX') {
              doc.setFont("DIN-B");
              let labelQuestion = doc.splitTextToSize(seg_det.sd_question, (sizeColum * seg_det.sd_colsize));
              let labelQuestionDimentions = doc.getTextDimensions(labelQuestion);
              let positionCheck = (sizeColum * column);
              (seg_det.value) ? doc.setFillColor(216, 30, 5) : doc.setFillColor(255, 255, 255);
              doc.rect((positionCheck), ((positionVertical - 3)), 3, 3, 'FD');
              doc.text(labelQuestion, positionCheck + 5, positionVertical);
              if (labelQuestionDimentions.h > addLineBreak) {
                addLineBreak = labelQuestionDimentions.h;
              }
              column += parseInt(seg_det.sd_colsize);
            }

            if (seg_det.qt_name == 'TABLA') {
              let labelQuestion = doc.splitTextToSize(seg_det.sd_question, (sizeColum * seg_det.sd_colsize));
              let labelQuestionDimentions = doc.getTextDimensions(labelQuestion);
              doc.text(labelQuestion, sizeColum * column, positionVertical);
              positionVertical += labelQuestionDimentions.h + sizeRow;
              doc.setFont("DIN-B");
              let positionCol = sizeColum;
              let everyHead = sizeBody / seg_det.sd_tabnumcol;
              let addBreakLineTable = 0;
              doc.line(sizeColum - 1, positionVertical - sizeRow, sizeBody + sizeColum, positionVertical - sizeRow);
              seg_det.segments_det_tbl.forEach((seg_det_table: any, index: number) => {
                let labelHead = doc.splitTextToSize(seg_det_table.sdt_colname, everyHead);
                doc.text(labelHead, positionCol, positionVertical);
                // doc.line(positionCol - 1, positionVertical + 2, positionCol - 1, positionVertical - sizeRow);
                positionCol += everyHead;
                // Si tiene dos o mas lineas hacer el brinco de linea
                if (labelHead.length >= 2 && labelHead.length > addBreakLineTable) {
                  addBreakLineTable = (labelHead.length - 1)
                }
              });

              positionVertical += 2;
              if (addBreakLineTable) { positionVertical += sizeRow * addBreakLineTable; addBreakLineTable = 0; }
              doc.line(sizeColum - 1, positionVertical, sizeBody + sizeColum, positionVertical);
              positionVertical += sizeRow;
              let addHeight = false;
              doc.setFont("DIN");
              // Imprimir los datos de la tabla                  
              seg_det.table.forEach((row: any, indexRow: number) => {
                let firtsCel = row[0];
                if (firtsCel['value_0']) {
                  positionCol = sizeColum;
                  let dimentionValue = 0;
                  row.forEach((col: any, indexCol: number) => {
                    let labelRes = doc.splitTextToSize(col['value_' + indexCol].toString(), everyHead);
                    dimentionValue = doc.getTextDimensions(labelRes).h;
                    doc.text(labelRes, positionCol, (positionVertical));
                    positionCol += everyHead;
                    if (labelRes.length >= 2) { addHeight = true; }
                  });
                  positionVertical += sizeRow;
                  if (addHeight) { positionVertical += dimentionValue; addHeight = false; }
                }
              });
            }

            if (seg_det.qt_name == 'OPC_MULTI') {
              doc.setFont("DIN-B");
              let sizeColumComplete = sizeColum * seg_det.sd_colsize;
              let labelQuestion = doc.splitTextToSize(seg_det.sd_question, sizeColumComplete);
              let labelQuestionDimentions = doc.getTextDimensions(labelQuestion);
              let aditional = labelQuestionDimentions.h + 1;
              doc.text(labelQuestion, (sizeColum * column), positionVertical);
              let positionCheck = (sizeColum * column);
              doc.setFont("DIN");
              let countBreak = 0;
              let sizeBusy = 0;

              seg_det.segments_det_opt.forEach((seg_det_opt: any, index: number) => {
                if (seg_det_opt.qt_name == 'CHECKBOX') {
                  let labelCheck = doc.splitTextToSize(seg_det_opt.sdo_caption, sizeColumComplete);
                  let dimentionsCheck = doc.getTextDimensions(labelCheck);
                  if (labelCheck.length >= 2) { positionCheck = sizeColum * column; }
                  // Se calcula el espacio que queda
                  let quedaEspacio = (sizeColumComplete - sizeBusy);
                  // Se verifica si el campo nuevo cabe en el espacio que queda
                  if (dimentionsCheck.w > quedaEspacio && index != 0) { positionCheck = sizeColum * column; countBreak++; aditional += (dimentionsCheck.h + 2); }
                  (seg_det_opt?.value && seg_det_opt.value == true) ? doc.setFillColor(216, 30, 5) : doc.setFillColor(255, 255, 255);
                  doc.roundedRect((positionCheck), ((positionVertical - 4) + aditional), 4, 4, 1, 1, 'DF');
                  doc.text(labelCheck, positionCheck + 5, (positionVertical) + aditional)
                  if (labelCheck.length >= 2) { aditional += dimentionsCheck.h + 2; sizeBusy = 0; }
                  if (labelCheck.length == 1) { positionCheck += Math.round(dimentionsCheck.w) + 7; sizeBusy += Math.round(dimentionsCheck.w); }
                  if (sizeBusy > sizeColumComplete) { sizeBusy = 0 }

                }

              });

              if (aditional > addLineBreak) { addLineBreak = aditional + 5 }

              column += parseInt(seg_det.sd_colsize);
            }

            if (seg_det.qt_name == 'COMPLETAR') {
              let array = seg_det.sd_question.split('{}');
              let answer = '';
              array.forEach((element: any, i: number) => {
                answer += element
                if (seg_det?.value && seg_det?.value[i]) {
                  let text = (seg_det.value[i]) ? seg_det.value[i] : '';
                  answer += ' ' + text;
                } else {
                  answer += '_____';
                }
              });
              let label = doc.splitTextToSize(answer, (seg_det.sd_colsize * sizeColum));
              let dimentions = doc.getTextDimensions(label);
              doc.text(label, (sizeColum * column), positionVertical);
              positionVertical += dimentions.h;
            }

            if (seg_det.qt_name == 'INFORMATIVA' || seg_det.qt_name == 'INFORMATIVA_N') {
              (seg_det.qt_name == 'INFORMATIVA_N') ? doc.setFont("DIN-B") : doc.setFont("DIN");
              let totalSize = sizeColum * seg_det.sd_colsize;
              totalSize += (seg_det.sd_colsize == 12) ? sizeColum : 0;
              let labelQuestion = doc.splitTextToSize(seg_det.sd_question, totalSize);
              let labelQuestionDimentions = doc.getTextDimensions(labelQuestion);
              if (seg_det.sd_colsize == 12) {
                doc.text(labelQuestion, sizeColum, positionVertical);
              } else {
                doc.text(labelQuestion, (sizeColum * column), positionVertical);
              }

              if (labelQuestionDimentions.h + positionVertical >= (pageSize - (sizeRow * 5))) {
                positionVertical += sizeRow;
                doc.roundedRect(xRect, yRect, wRect + 5, (positionVertical + labelQuestionDimentions.h - yRect), 3, 3);
                doc.addPage();
                flagCloseContainer = false;
                positionVertical = (sizeRow * 3);
              } else {
                if (labelQuestionDimentions.h > addLineBreak) {
                  addLineBreak = labelQuestionDimentions.h;
                }

                column += parseInt(seg_det.sd_colsize);
              }

            }

            if (seg_det.qt_name == 'CLAVE') {
              let label = doc.splitTextToSize(seg_det.segments_det_key.k_question, sizeColum * seg_det.sd_colsize);
              let labelDimentions = doc.getTextDimensions(label);
              doc.text(label, (sizeColum * column), positionVertical);
              let aditional = labelDimentions.h;
              if (seg_det.segments_det_key.kt_name == 'NUM_ENTERO') {
                let labelAnswer = new String(seg_det.value);
                doc.text(labelAnswer.toString(), sizeColum * column, positionVertical + labelDimentions.h + 3);
                let answerDimentions = doc.getTextDimensions(labelAnswer.toString());
                aditional += answerDimentions.h;
              }

              if (seg_det.segments_det_key.kt_name == 'OPC_UNICA') {
                let positionCheck = sizeColum;
                seg_det.segments_det_key.keys_opt.forEach((key_opt: any) => {
                  let labelCheck = doc.splitTextToSize(key_opt.ko_value, sizeBody);
                  let dimentionsCheck = doc.getTextDimensions(`0  ${labelCheck}`);
                  (element.value == key_opt.ko_id) ? doc.setFillColor(216, 30, 5) : doc.setFillColor(255, 255, 255);
                  doc.circle((positionCheck + 2), ((positionVertical - 2 + labelDimentions.h + 1)), 2, 'FD');
                  doc.text(labelCheck, positionCheck + 5, (positionVertical + labelDimentions.h + 1))
                  positionCheck += dimentionsCheck.w
                  if (positionCheck >= sizeBody) { positionCheck = sizeColum; aditional += labelDimentions.h }
                });
              }

              if (aditional > addLineBreak) {
                addLineBreak = aditional + 3;
              }

              column += parseInt(seg_det.sd_colsize);

            }

            //Verificar cuando debo cambiar de pagina y como cerrar el cuadro para que se vea bien
            let numberSize = (indexSegment == element.segments_det.length) ? 8 : 5;
            if ((pageSize - positionVertical) <= (sizeRow * numberSize)) {
              positionVertical += sizeRow;
              // Cerrar contenedor
              doc.roundedRect(xRect, yRect, wRect + 5, (positionVertical - yRect), 3, 3);
              // Añadir pagina
              doc.addPage();
              // Desanctivar flag
              flagCloseContainer = false;
              positionVertical = (sizeRow * 3);
            } else {
              flagCloseContainer = true;
            }

            if (indexSegment == (element.segments_det.length - 1)) {
              if (sizeRow * 2 > addLineBreak) {
                positionVertical += sizeRow + 2;
              } else {
                positionVertical += addLineBreak + 2;
              }
            }

          });
        }

        // Cerrar contenedor si no ha cambiado de pagina
        if (flagCloseContainer) {
          doc.roundedRect(xRect, yRect, wRect + 5, (positionVertical - yRect), 3, 3);
        }

        if ((pageSize - positionVertical) <= (sizeRow * 9)) {
          doc.addPage();
          positionVertical = (sizeRow * 3);
        }

      });

      if (type == 'datauri') {
        let base64Pdf: any = doc.output("datauri");
        resolve(base64Pdf)
      }
      if (type == 'datauristring') {
        let base64Pdf: any = doc.output("datauristring");
        resolve(base64Pdf)
      }

    })
  }

  sendBase64(base64Pdf): void {
    let params = {
      token: localStorage.getItem('token'),
      pdfb64: base64Pdf
    }

    this.methods.POST(`links/finishform`, params).subscribe(response => {
      let { status } = response;
    });
  }

}
