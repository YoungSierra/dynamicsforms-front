import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpClient
} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class JwtInterceptor implements HttpInterceptor {

  constructor() {

  }

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {

    let token = (localStorage.getItem('token')) ? localStorage.getItem('token') : null;
    let ip = (localStorage.getItem('ip')) ? localStorage.getItem('ip') : null;
    let userEmail = (localStorage.getItem('email')) ? localStorage.getItem('email') : "";
    request = request.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`,
        "User-Email": userEmail,
        "IP": `${ip}`
      }
    });
    return next.handle(request);
  }
}
