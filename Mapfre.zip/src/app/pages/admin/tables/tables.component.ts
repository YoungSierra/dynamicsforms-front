import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ECodeStatus } from '../../../enums/ecode-status';
import { AlertsService } from '../../../services/alerts.service';
import { TablesService } from '../../../services/tables.service';

@Component({
  selector: 'app-tables',
  templateUrl: './tables.component.html',
  styleUrls: ['./tables.component.scss']
})
export class TablesComponent implements OnInit {

  @ViewChild('tablesModal') tablesModal: ElementRef;
  listTables: any[] = [];
  listTableDetail: any[] = [];
  idTableEdit: any = null;
  formTables: FormGroup;

  constructor(
    private tableServices: TablesService,
    private modalService: NgbModal,
    private alertService: AlertsService,
    private fb: FormBuilder
  ) { }

  ngOnInit(): void {

    this.LoadTables();

    this.formTables = this.fb.group({
      name: ['', Validators.required]
    })
  }

  /** Methods */
  LoadTables(): void {
    this.tableServices.getTablesAll().subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listTables = data;
      }
    })
  }

  DeleteTable(id): void {
    this.tableServices.deleteTable(id).subscribe(response => {
      let { status, data, message } = response;
      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadTables();
      } else {
        this.alertService.error(message);
      }
    })
  }

  SaveTable(data): void {
    this.tableServices.saveTable(data).subscribe(response => {
      let { status, data, message } = response;
      if (status == ECodeStatus.Ok) {
        this.modalService.dismissAll();
        this.alertService.success(message);
        this.LoadTables();
      } else {
        this.alertService.error(message);
      }
    })
  }

  UpdateTable(id, data): void {
    this.tableServices.updateTable(id, data).subscribe(response => {
      let { status, data, message } = response;
      if (status == ECodeStatus.Ok) {
        this.modalService.dismissAll();
        this.alertService.success(message);
        this.LoadTables();
      } else {
        this.alertService.error(message);
      }
    })
  }

  /** Events */

  onClickInactivate(item): void {
    this.tableServices.inactivateTable(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message)
        this.LoadTables();
      } else {
        this.alertService.error(message);
      }
    })
  }

  onClickActivate(item): void {
    this.tableServices.activateTable(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message)
        this.LoadTables();
      } else {
        this.alertService.error(message);
      }
    })
  }

  onClickNewTable(): void {
    this.idTableEdit = null;
    this.formTables.reset();
    this.modalService.open(this.tablesModal, { centered: true })
  }

  onClickEditTable(item): void {
    this.idTableEdit = item.id;
    this.formTables.patchValue(item);
    this.modalService.open(this.tablesModal, { centered: true })
  }

  onClickDeleteTable(item): void {
    this.alertService.questionDelete("Desea eliminar tabla?").then(res => {
      if (res) {
        this.DeleteTable(item.id);
      }
    })
  }

  onClickSaveTable(): void {
    if (this.formTables.valid) {
      let data = this.formTables.value;

      if (this.idTableEdit) {
        this.UpdateTable(this.idTableEdit, data)
      } else {
        this.SaveTable(data);
      }
    }
  }


}
