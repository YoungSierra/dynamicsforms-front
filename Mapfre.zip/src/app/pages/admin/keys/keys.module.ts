import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { KeysComponent } from './keys.component';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';

const routes: Routes = [
  {
    path: '',
    component: KeysComponent
  }
]

@NgModule({
  declarations: [
    KeysComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    NgbTooltipModule,
    ReactiveFormsModule,
  ]
})
export class KeysModule { }
