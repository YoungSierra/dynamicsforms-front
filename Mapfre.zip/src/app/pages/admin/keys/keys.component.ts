import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ECodeStatus } from '../../../enums/ecode-status';
import { AlertsService } from '../../../services/alerts.service';
import { ConditionTypesService } from '../../../services/condition-types.service';
import { KeyService } from '../../../services/key.service';

@Component({
  selector: 'app-keys',
  templateUrl: './keys.component.html',
  styleUrls: ['./keys.component.scss']
})
export class KeysComponent implements OnInit {

  @ViewChild('modalKey') modalKey: ElementRef;
  idKeyEdit: any;
  listKeys: any[] = [];
  listKeyTypes: any[] = [];
  formKey: FormGroup;
  showInputMaxMin: string = null;

  constructor(
    private keyService: KeyService,
    private modalService: NgbModal,
    private fb: FormBuilder,
    private alertService: AlertsService,
  ) { }

  ngOnInit(): void {

    this.LoadKeys();
    setTimeout(() => {
      this.LoadKeyTypes();
    }, 2000);

    this.formKey = this.fb.group({
      name: ['', Validators.required],
      question: ['', Validators.required],
      ktypesId: ['', Validators.required],
      minValue: [''],
      maxValue: ['']
    })

    this.formKey.valueChanges.subscribe((form) => {
      if (form.ktypesId) {
        let find = this.listKeyTypes.find(e => e.id == form.ktypesId)
        if(find){
          this.showInputMaxMin = find.name;
        }else{
          this.showInputMaxMin = null;
        }
      }
    })

  }

  /** Methods */
  LoadKeys(): void {
    this.keyService.getKeysAll().subscribe(response => {
      let { status, data } = response;

      if (status == ECodeStatus.Ok) {
        this.listKeys = data;
      }
    })
  }

  LoadKeyTypes(): void {
    this.keyService.getKeyTypes().subscribe(response => {
      let { status, data } = response;

      if (status == ECodeStatus.Ok) {
        this.listKeyTypes = data;
      }
    })
  }

  SaveKey(data): void {
    this.keyService.saveKey(data).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.LoadKeys();
        this.alertService.success(message);
        this.modalService.dismissAll();
      } else {
        this.alertService.error(message);
      }
    })
  }

  UpdateKey(id: any, data: any): void {
    this.keyService.updateKey(id, data).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadKeys();
        this.modalService.dismissAll();
      } else {
        this.alertService.error(message);
      }
    })
  }

  DeleteKey(id: any): void {
    this.keyService.deleteKey(id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadKeys();
      } else {
        this.alertService.error(message);
      }
    })
  }


  /** Events */
  onClickNewKey(): void {
    this.idKeyEdit = null;
    this.formKey.reset();
    this.modalService.open(this.modalKey, { centered: true });
  }

  onClickInactivate(item: any): void {
    this.keyService.inactivateKey(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadKeys();
      }
    })
  }

  onClickActivate(item: any): void {
    this.keyService.activateKey(item.id).subscribe(response => {
      let { status, data, message } = response;
      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadKeys();
      }
    })
  }

  onClickEditKey(item: any): void {
    this.idKeyEdit = item.id;
    this.formKey.patchValue(item);
    this.modalService.open(this.modalKey, { centered: true });
  }

  onClickDeleteKey(item: any): void {
    this.alertService.questionDelete("Desea eliminar la clave?").then(res => {
      if (res) {
        this.DeleteKey(item.id);
      }
    })
  }

  onClickSaveKey(): void {
    if (this.formKey.valid) {
      let data = this.formKey.value;

      if (this.idKeyEdit) {
        this.UpdateKey(this.idKeyEdit, data);
      } else {
        this.SaveKey(data);
      }
    }
  }

}
