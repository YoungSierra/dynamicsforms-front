import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsComponent } from './forms.component';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule, FormsModule as FormsModuleAngular } from '@angular/forms';
import { ComponentsModule } from '../../../components/components.module';
import { NgxPaginationModule } from 'ngx-pagination';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';

const routes: Routes = [
  {
    path: '',
    component: FormsComponent
  }
]

@NgModule({
  declarations: [
    FormsComponent
  ],
  imports: [
    ReactiveFormsModule,
    FormsModuleAngular,
    NgxPaginationModule,
    Ng2SearchPipeModule,
    NgbTooltipModule,
    ComponentsModule,
    RouterModule.forChild(routes),
    CommonModule
  ]
})
export class FormsModule { }
