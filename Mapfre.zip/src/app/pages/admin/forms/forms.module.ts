import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsComponent } from './forms.component';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { ComponentsModule } from '../../../components/components.module';

const routes: Routes = [
  {
    path: '',
    component: FormsComponent
  }
]

@NgModule({
  declarations: [
    FormsComponent
  ],
  imports: [
    ReactiveFormsModule,
    ComponentsModule,
    RouterModule.forChild(routes),
    CommonModule
  ]
})
export class FormsModule { }
