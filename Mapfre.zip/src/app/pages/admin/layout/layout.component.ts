import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { NgProgress } from 'ngx-progressbar';
import { ProgressBarService } from '../../../services/progress-bar.service';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { UserService } from '../../../services/user.service';
import jwtDecode from 'jwt-decode';
import { ECodeStatus } from '../../../enums/ecode-status';
import { AlertsService } from '../../../services/alerts.service';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss'],
})
export class LayoutComponent implements OnInit {
  @ViewChild('passwordModal') passwordModal: ElementRef;
  formPassword: any = {
    password: '',
    newPassword: '',
    newPasswordConfirm: '',
  };
  showSidebar: boolean = false;
  dataUser: any;
  characterMore: boolean = false;
  characterSpecial: boolean = false;
  passwordSame: boolean = false;
  typeInput = "password";

  constructor(
    private loading: ProgressBarService,
    private progress: NgProgress,
    private route: Router,
    private modalService: NgbModal,
    private apiService: UserService,
    private alertService: AlertsService
  ) { }

  ngOnInit(): void {
    this.loading.progressRef = this.progress.ref('progressBar');

    this.dataUser = jwtDecode(localStorage.getItem('token'));

    if (!this.dataUser.sub) {
      this.route.navigate(['login'])
    }

    this.formPassword = {
      password: '',
      newPassword: '',
      newPasswordConfirm: '',
    };

    setTimeout(() => {
      this.VerificateChangePassword();
    }, 4000);
  }

  VerificateChangePassword(): void {
    let updPass = localStorage.getItem('updPass');

    if (updPass == 'false') {
      this.onClickChangePassword();
    }
  }

  SaveNewPassword(id, params): void {
    this.apiService.changePassword(id, params).subscribe((response) => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.formPassword = {
          password: '',
          newPassword: '',
          newPasswordConfirm: '',
        };
        this.modalService.dismissAll();
        this.passwordSame = false; this.characterMore = false; this.characterSpecial = false;
        this.alertService.success(message);
        localStorage.setItem('updPass', 'true');
      } else {
        this.alertService.error(message);
      }
    });
  }

  onClickLogout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('email');
    this.route.navigate(['login']);
  }

  onClickChangePassword(): void {
    this.modalService.open(this.passwordModal, {
      centered: true,
      size: 'md',
      backdrop: 'static',
      keyboard: false,
    });
  }

  onClickUpdate(): void {
    if (!this.characterMore) { this.alertService.error("Mínimo 6 caracteres"); return; }
    if (!this.characterSpecial) { this.alertService.error("Debe contener mínimo un caracter especial"); return; }
    if (!this.passwordSame) { this.alertService.error("Los campos de nueva contraseña no son iguales"); return; }
    if (!this.formPassword.password || !this.formPassword.newPassword || !this.formPassword.newPasswordConfirm) { this.alertService.error("Formulario invalido"); return; }
    if (this.formPassword.newPassword == this.formPassword.password) { this.alertService.error("La contraseña nueva no puede ser igual a la anterior"); return; }

    let params = {
      password: this.formPassword.password,
      newpassword: this.formPassword.newPassword,
    };
    let dataToken: any = jwtDecode(localStorage.getItem('token'));

    this.SaveNewPassword(dataToken.user, params);
  }

  onClickShowSidebar(): void {
    this.showSidebar = !this.showSidebar;
  }

  validateNewPassword(): void {
    const expresionRegular = /[^a-zA-Z0-9\s]/;
    this.characterSpecial = expresionRegular.test(this.formPassword.newPassword);
    this.characterMore = (this.formPassword.newPassword.length >= 6) ? true : false;
    this.passwordSame = ((this.formPassword.newPassword == this.formPassword.newPasswordConfirm) && this.formPassword.newPassword != null && this.formPassword.newPassword != '' && this.formPassword.newPasswordConfirm != null && this.formPassword.newPasswordConfirm != '') ? true : false
  }

  showPassword(): void {
    this.typeInput = (this.typeInput == 'password') ? 'text' : 'password';
  }
}
