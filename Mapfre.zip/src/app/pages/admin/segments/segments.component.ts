import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ECodeStatus } from '../../../enums/ecode-status';
import { AlertsService } from '../../../services/alerts.service';
import { ProgressBarService } from '../../../services/progress-bar.service';
import { SegmentsService } from '../../../services/segments.service';

@Component({
  selector: 'app-segments',
  templateUrl: './segments.component.html',
  styleUrls: ['./segments.component.scss']
})
export class SegmentsComponent implements OnInit {

  @ViewChild('segmentModal') segmentModal: ElementRef;
  listSegments: any[] = [];
  formSegment: FormGroup
  idSegmentsEdit: string;
  p: number = 1;
  textSearch: string = '';

  constructor(
    private modalService: NgbModal,
    private fb: FormBuilder,
    private segmentsService: SegmentsService,
    private alertService: AlertsService,
    private progressBar: ProgressBarService
  ) { }

  ngOnInit(): void {

    this.formSegment = this.fb.group({
      name: [''],
      title: [''],
      subtitle: ['']
    })

    this.LoadSegments();
  }


  LoadSegments(): void {
    this.progressBar.startLoading();
    this.segmentsService.getSegmentsAll().subscribe(response => {
      let { status, data, message } = response;
      this.progressBar.completeLoading();
      if (status == ECodeStatus.Ok) {
        this.listSegments = data;
      } else {
        this.alertService.error(message);
      }
    })
  }

  SaveSegment(data): void {
    this.segmentsService.saveSegments(data).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.modalService.dismissAll();
        this.LoadSegments();
        this.alertService.success(message);
      } else {
        this.alertService.error(message)
      }
    })
  }

  UpdateSegment(id, data): void {
    this.segmentsService.updateSegments(id, data).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.modalService.dismissAll();
        this.LoadSegments();
      } else {
        this.alertService.error(message);
      }
    })
  }

  DeleteProduct(id): void {
    this.segmentsService.deleteSegment(id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSegments();
      } else {
        this.alertService.error(message);
      }
    })
  }

  /** Events */
  onClickNewSegment(): void {
    this.idSegmentsEdit = null;
    this.formSegment.reset();
    this.modalService.open(this.segmentModal, { centered: true });
  }

  onClickSaveSegment(): void {
    if (this.formSegment.valid) {
      let data = this.formSegment.value;
      if (this.idSegmentsEdit) {
        this.UpdateSegment(this.idSegmentsEdit, data);
      } else {
        this.SaveSegment(data);
      }
    }
  }

  onClickEditProduct(item): void {
    this.idSegmentsEdit = item.id;
    this.formSegment.patchValue(item);
    this.modalService.open(this.segmentModal, { centered: true });
  }

  onClickDeleteProduct(item): void {
    this.alertService.questionDelete("Desea eliminar este producto?").then(res => {
      if (res) {
        this.DeleteProduct(item.id)
      }
    })
  }

  onClickActivate(item): void {
    this.segmentsService.activateSegment(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSegments();
      } else {
        this.alertService.error(message)
      }
    })
  }

  onClickInactivate(item): void {
    this.segmentsService.inactivateSegment(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSegments();
      } else {
        this.alertService.error(message)
      }
    })
  }

}
