import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SegmentsComponent } from './segments.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';
import { NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { Ng2SearchPipeModule } from 'ng2-search-filter';

const routes: Routes = [
  {
    path: '',
    component: SegmentsComponent
  }
]

@NgModule({
  declarations: [
    SegmentsComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    Ng2SearchPipeModule,
    FormsModule,
    NgxPaginationModule,
    NgbTooltipModule,
    RouterModule.forChild(routes)
  ]
})
export class SegmentsModule { }
