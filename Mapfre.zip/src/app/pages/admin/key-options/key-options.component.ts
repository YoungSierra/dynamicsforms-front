import { Location } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ECodeStatus } from '../../../enums/ecode-status';
import { AlertsService } from '../../../services/alerts.service';
import { ConditionTypesService } from '../../../services/condition-types.service';
import { KeyService } from '../../../services/key.service';
import { SegmentsService } from '../../../services/segments.service';

@Component({
  selector: 'app-key-options',
  templateUrl: './key-options.component.html',
  styleUrls: ['./key-options.component.scss']
})
export class KeyOptionsComponent implements OnInit {

  @ViewChild('modalConfigKey') modalConfigKey: ElementRef;

  idKey: string = null;
  listKeyOptions: any[] = [];
  listConditionTypes: any[] = [];
  listSegments: any[] = [];
  infoKey: any;
  formConfigKey: FormGroup;

  constructor(
    private route: ActivatedRoute,
    private keyServices: KeyService,
    private alertService: AlertsService,
    private conditionTypeService: ConditionTypesService,
    private modalService: NgbModal,
    private fb: FormBuilder,
    private location: Location,
    private segmentService: SegmentsService
  ) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      if (params['id']) {
        this.idKey = params['id'];
        this.LoadKeyDetail(params['id']);
      }
    })

    setTimeout(() => {
      this.LoadConditionTypes();
    }, 1500);

    setTimeout(() => {
      this.LoadSegments();
    }, 3000);

    this.formConfigKey = this.fb.group({
      value: [''],
      condtypesId: [''],
      listSegmentsForm: this.fb.array([])
    })


  }

  get listSegmentsForm(): FormArray {
    return this.formConfigKey.get('listSegmentsForm') as FormArray;
  }


  /** Methods */
  LoadKeyDetail(id): void {
    this.listKeyOptions = [];
    this.keyServices.getKeyOptionsByKeyId(id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listKeyOptions = data;
      }
    }, err => {
      let { error } = err;
      this.alertService.error(error);
    })
  }


  LoadConditionTypes(): void {
    this.conditionTypeService.getConditionTypes().subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listConditionTypes = data;
      }
    }, err => {
      let { error } = err;
      this.alertService.error(error);
    })
  }

  DeleteKeyOption(id): void {
    this.keyServices.deleteKeyOption(id).subscribe(response => {
      let { status, data, message } = response;
      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadKeyDetail(this.idKey);
      } else {
        this.alertService.error(message);
      }
    }, err => {
      let { error } = err;
      this.alertService.error(error.message);
    })
  }

  LoadSegments(): void {
    this.segmentService.getSegments().subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listSegments = data;
      }
    }, err => {
      let { error } = err;
      this.alertService.error(error.message);
    })
  }

  SaveKeyOption(params): void {
    let listsegments = params.listSegmentsForm;
    this.keyServices.saveKayOptions(params).subscribe(async (response) => {
      let { status, data, message } = response;
      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadKeyDetail(this.idKey);
        for (let i = 0; i < listsegments.length; i++) {
          const element = listsegments[i];
          if (element.segmentsId && element.ordernum) {
            let newParams = {
              keysOptId: data,
              segmentsId: element.segmentsId,
              ordernum: element.ordernum
            }
            await this.SaveKeyOptionSegment(newParams).then(async (res) => {
              await this.ActivateKeyOptionSegment(res).then(actived => {
                console.log(actived);
              });
            });
          }
        }
        this.modalService.dismissAll();
      } else {
        this.alertService.error(message);
      }
    }, err => {
      let { error } = err;
      this.alertService.error(error.message);
    })
  }

  SaveKeyOptionSegment(params): Promise<any> {

    return new Promise((resolve) => {
      this.keyServices.saveKeyOptionSegment(params).subscribe(async (response) => {
        let { status, data, message } = response;
        if (status == ECodeStatus.Ok) {
          resolve(data)
        } else {
          this.alertService.error(message);
        }

      }, err => {
        resolve(false)
        let { error } = err;
        this.alertService.error(error.message);
      })
    })
  }

  ActivateKeyOptionSegment(id): Promise<any> {
    return new Promise((resolve) => {
      this.keyServices.activateKeyOptionSegment(id).subscribe(response => {
        let { status, data, message } = response;
        if (status == ECodeStatus.Ok) {
          resolve(data);
          //this.alertService.success(message);
        } else {
          this.alertService.error(message);
        }
      }, err => {
        resolve(true);
        let { error } = err;
        this.alertService.error(error.message);
      })
    })
  }

  LoadKeyById(id): void {
    this.keyServices.getKeyById(id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.infoKey = data
      }
    }, err => {
      let { error } = err;
      this.alertService.error(error.message);
    })
  }

  /** Events */
  onClickInactivate(item): void {
    this.keyServices.inactivateKeyOption(item.id).subscribe(response => {
      let { status, data, message } = response;
      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadKeyDetail(this.idKey);
      } else {
        this.alertService.error(message);
      }
    }, err => {
      let { error } = err;
      this.alertService.error(error.message);
    })
  }

  onClickActivate(item): void {
    this.keyServices.activateKeyOption(item.id).subscribe(response => {
      let { status, data, message } = response;
      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadKeyDetail(this.idKey);
      } else {
        this.alertService.error(message);
      }
    }, err => {
      let { error } = err;
      this.alertService.error(error.message);
    })
  }

  onClickDeleteKeyOption(item): void {
    this.alertService.questionDelete("Desea eliminar esta opción?").then(res => {
      if (res) {
        this.DeleteKeyOption(item.id)
      }
    })
  }

  onClickNewKeyOption(): void {
    let count = this.listSegmentsForm.length;
    for (let i = 0; i < count; i++) {
      this.listSegmentsForm.removeAt(i);
    }
    this.formConfigKey.reset();
    this.formConfigKey.patchValue({ keysId: [this.idKey] });
    this.onClickAddSegment();
    this.modalService.open(this.modalConfigKey, { centered: true })
  }
  onClickBack(): void {
    this.location.back();
  }

  onClickSaveKeyOption(): void {
    let data = this.formConfigKey.value;
    data.keysId = this.idKey;
    if (this.formConfigKey.valid) {
      if (data.listSegmentsForm.length == 1 && !data.listSegmentsForm[0].segmentsId && !data.listSegmentsForm[0].ordernum) {
        this.alertService.questionConfirm("¿Está seguro de guardar la opción si ningún segmento asociado?").then(res => {
          if (res) {
            this.SaveKeyOption(data)
          }
        })
      } else {
        this.SaveKeyOption(data)
      }
    } else {
      this.alertService.error("Completar formulario");
    }
  }

  onClickAddSegment(): void {
    let newSegment = {
      segmentsId: [''],
      ordernum: ['']
    }

    this.listSegmentsForm.push(this.fb.group(newSegment));
  }

  onClickRemoveSegment(index): void {
    this.listSegmentsForm.removeAt(index);
  }

  // onClickEditKeyOption(item): void {
  //   this.formConfigKey.patchValue(item);
  //   this.modalService.open(this.modalConfigKey, { centered: true });
  // }

}
