import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { KeyOptionsComponent } from './key-options.component';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';

const routes: Routes = [
  {
    path: '',
    component: KeyOptionsComponent
  }
]

@NgModule({
  declarations: [
    KeyOptionsComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NgbTooltipModule,
    RouterModule.forChild(routes)
  ]
})
export class KeyOptionsModule { }
