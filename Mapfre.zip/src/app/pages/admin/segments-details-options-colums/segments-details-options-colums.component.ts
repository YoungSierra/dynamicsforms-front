import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { QTypeService } from '../../../services/qtype.service';
import { ECodeStatus } from '../../../enums/ecode-status';
import { AlertsService } from '../../../services/alerts.service';
import { ColTypesService } from '../../../services/col-types.service';
import { SegmentsService } from '../../../services/segments.service';
import { Location } from '@angular/common';
import { TablesService } from '../../../services/tables.service';

@Component({
  selector: 'app-segments-details-options-colums',
  templateUrl: './segments-details-options-colums.component.html',
  styleUrls: ['./segments-details-options-colums.component.scss']
})
export class SegmentsDetailsOptionsColumsComponent implements OnInit {

  @ViewChild('modalOpionsColums') modalOpionsColums: ElementRef;
  idSegmentDetailOption: string;
  listColums: any[] = [];
  listColTypes: any[] = [];
  listTables: any[] = [];
  formColums: FormGroup


  constructor(
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private modalService: NgbModal,
    private typeColService: ColTypesService,
    private tableService: TablesService,
    private alertService: AlertsService,
    private segmentService: SegmentsService,
    private location: Location
  ) { }

  ngOnInit(): void {

    this.route.params.subscribe(res => {
      console.log(res);
      this.idSegmentDetailOption = res['id'];

      this.LoadSegmentDetailOptionsColumsById(this.idSegmentDetailOption);

      setTimeout(() => {
        this.LoadQTypes();
      }, 1000);
    })

    this.formColums = this.fb.group({
      segmentsDetOptId: [this.idSegmentDetailOption],
      colname: [''],
      coltypesId: [''],
      colsize: [''],
    })
  }

  /** Methods */
  LoadSegmentDetailOptionsColumsById(id): void {
    this.segmentService.getSegmentDetailOptionTable().subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listColums = data.filter(e => e.segmentsDetOptId == id)
      }
    })
  }

  LoadQTypes(): void {
    this.typeColService.get().subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listColTypes = data;
      } else {
        this.alertService.error(message);
      }
    })
  }

  DeleteSegmentDetailOptionTable(id): void {
    this.segmentService.deleteSegmentDetailOptionTable(id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSegmentDetailOptionsColumsById(this.idSegmentDetailOption);
      } else {
        this.alertService.error(message);
      }
    })
  }

  SaveColum(data): void {
    this.segmentService.saveSegmentDetailOptionTable(data).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSegmentDetailOptionsColumsById(this.idSegmentDetailOption);
      } else {
        this.alertService.error(message);
      }
    })
  }

  // LoadTable(): void {
  //   this.tableService.getTables().subscribe(response => {
  //     let { status, data, message } = response;

  //     if (status == ECodeStatus.Ok) {
  //       this.listTables = data;
  //     } else {
  //       this.alertService.error(message)
  //     }
  //   })
  // }

  /** Events */
  onClickNewColum(): void {
    this.formColums.patchValue({ colname: '', coltypesId: '', colsize: '' });
    this.modalService.open(this.modalOpionsColums, { centered: true });
    // this.LoadTable();
  }

  onClickSaveColum(): void {
    let data = this.formColums.value
    this.SaveColum(data);
  }

  onClickInactivate(item): void {
    this.segmentService.inactivateSegmentDetailOptionTable(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSegmentDetailOptionsColumsById(this.idSegmentDetailOption);
      } else {
        this.alertService.error(message);
      }
    })
  }

  onClickActivate(item): void {
    this.segmentService.activateSegmentDetailOptionTable(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSegmentDetailOptionsColumsById(this.idSegmentDetailOption);
      } else {
        this.alertService.error(message);
      }
    })
  }

  onClickDeleteDetailOption(item): void {
    this.alertService.questionDelete("Desea eliminar esta columna ?").then(res => {
      if (res) {
        this.DeleteSegmentDetailOptionTable(item.id)
      }
    })
  }
  
  onClickBack(): void {
    this.location.back();
  }

}
