import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SegmentsDetailsOptionsColumsComponent } from './segments-details-options-colums.component';

describe('SegmentsDetailsOptionsColumsComponent', () => {
  let component: SegmentsDetailsOptionsColumsComponent;
  let fixture: ComponentFixture<SegmentsDetailsOptionsColumsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SegmentsDetailsOptionsColumsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SegmentsDetailsOptionsColumsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
