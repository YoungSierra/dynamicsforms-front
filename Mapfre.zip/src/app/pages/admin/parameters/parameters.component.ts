import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ParametersService } from '../../../services/parameters.service';
import { ECodeStatus } from '../../../enums/ecode-status';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AlertsService } from '../../../services/alerts.service';

@Component({
  selector: 'app-parameters',
  templateUrl: './parameters.component.html',
  styleUrls: ['./parameters.component.scss']
})
export class ParametersComponent implements OnInit {

  @ViewChild('modalParams') modalParams: ElementRef;
  listParameters: any[] = [];
  idParamEdit: string = null;
  formParam: FormGroup;

  constructor(
    private parameterService: ParametersService,
    private modalService: NgbModal,
    private fb: FormBuilder,
    private alertService: AlertsService
  ) { }

  ngOnInit(): void {

    this.formParam = this.fb.group({
      id: ['', Validators.required],
      paramValue: ['', Validators.required]
    })

    this.LoadParameters();
  }

  /** Methods */
  LoadParameters(): void {
    this.parameterService.getAll().subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listParameters = data;
      }
    })
  }

  SaveNewParam(id: string, paramValue: string): void {
    this.parameterService.create(id, paramValue).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.modalService.dismissAll();
        this.LoadParameters();
      } else {
        this.alertService.error(message);
      }
    }, (err) => {
      this.alertService.error(err.message);
    })
  }

  UpdateParam(id: string, paramValue: string): void {

    this.parameterService.update(id, paramValue).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.modalService.dismissAll();
        this.LoadParameters();
      } else {
        this.alertService.error(message);
      }
    })
  }

  DeleteParam(id: string): void {
    this.parameterService.delete(id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadParameters();
      } else {
        this.alertService.error(message);
      }
    })
  }

  /** Events */
  onClickNewParameter(): void {
    this.formParam.reset();
    this.idParamEdit = null;
    this.modalService.open(this.modalParams, { centered: true });
  }

  onClickEditParam(param: any): void {
    this.idParamEdit = param.id;
    this.formParam.patchValue(param);
    this.modalService.open(this.modalParams, { centered: true });
  }

  onClickDeleteParam(param: any): void {
    this.alertService.questionDelete("¿Desea eliminar el parametro?").then(res => {
      if (res) { this.DeleteParam(param.id) }
    })
  }

  onClickSaveParam(): void {
    if (this.formParam.valid) {
      let { id, paramValue } = this.formParam.value;

      if (this.idParamEdit) {
        if (this.idParamEdit == 'PASSW_TK_MINUTES') {
          // Validar numero
          let valueValidate = parseInt(paramValue)
          if (Number.isInteger(valueValidate) && valueValidate > 0) {
            this.UpdateParam(id, paramValue);
          }else{
            this.alertService.error("Valor debe ser numero, mayor que 0")
          }
        } else {
          this.UpdateParam(id, paramValue);
        }
      } else {
        this.SaveNewParam(id, paramValue);
      }
    } else {
      this.alertService.error("Completar campos");
    }
  }

}
