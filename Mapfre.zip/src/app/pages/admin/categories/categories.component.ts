import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ECodeStatus } from '../../../enums/ecode-status';
import { File } from '../../../interfaces/file';
import { AlertsService } from '../../../services/alerts.service';
import { CategoriesService } from '../../../services/categories.service';
import { ProgressBarService } from '../../../services/progress-bar.service';
import { SectionsService } from '../../../services/sections.service';

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.scss']
})
export class CategoriesComponent implements OnInit {

  @ViewChild('modalCategory') modalCategory: ElementRef;
  listCategories: any[] = [];
  listSection: any[] = [];
  formCategory: FormGroup
  idCategoryEdit: string;
  image: File = {
    name: '',
    base64: '',
    base64Sort: ''
  }

  constructor(
    private categoriesService: CategoriesService,
    private sectionService: SectionsService,
    private modalService: NgbModal,
    private fb: FormBuilder,
    private alertService: AlertsService,
    private progressBar: ProgressBarService
  ) { }

  ngOnInit(): void {

    this.LoadCategories();

    this.formCategory = this.fb.group({
      name: [''],
      sectionsId: [''],
      pathimg: [''],
      ordernum: ['']
    })
  }

  /** Methods */
  LoadCategories(): void {
    this.categoriesService.getAllCategories().subscribe(response => {
      let { status, data } = response;

      if (status == ECodeStatus.Ok) {
        this.listCategories = data;
      }
    })
  }

  LoadSections(): void {
    this.sectionService.getSections().subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listSection = data;
      }
    })
  }

  SaveCategory(data): void {
    this.progressBar.startLoading();
    this.categoriesService.saveCategories(data).subscribe(response => {
      this.progressBar.completeLoading();
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.modalService.dismissAll();
        this.LoadCategories();
      } else {
        this.alertService.error(message);
      }
    })
  }

  UpdateCategory(id, data): void {
    this.progressBar.startLoading();
    this.categoriesService.updateCategory(id, data).subscribe(response => {
      this.progressBar.completeLoading();
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.modalService.dismissAll();
        this.LoadCategories();
      } else {
        this.alertService.error(message);
      }
    })
  }

  DeleteCategory(id): void {
    this.categoriesService.deleteCategory(id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadCategories();
      } else {

      }
    }, err => {
      this.alertService.error(err.error)
    })
  }

  /** Events */

  onClickEditCategories(data): void {
    if (!this.listSection.length) { this.LoadSections(); }
    let item = { ...data }
    this.idCategoryEdit = item.id;
    if (item.pathimg) {
      this.image = {
        base64: item.pathimg,
        name: 'yes',
        base64Sort: ''
      }
      delete item.pathimg
    }

    this.formCategory.patchValue(item);
    this.modalService.open(this.modalCategory, { centered: true });
  }

  onClickDeleteCategories(item): void {
    this.alertService.questionDelete("Desea eliminar la categoria?").then(res => {
      if (res) {
        this.DeleteCategory(item.id)
      }
    })
  }

  onClickNewCategory(): void {
    this.LoadSections();
    this.idCategoryEdit = null;
    this.formCategory.reset();
    this.image = { name: null, base64: null, base64Sort: null };
    this.modalService.open(this.modalCategory, { centered: true });
  }

  onClickSaveCategory(): void {
    if (this.formCategory.valid) {
      let data = this.formCategory.value;

      if (this.idCategoryEdit) {
        this.UpdateCategory(this.idCategoryEdit, data)
      } else {
        this.SaveCategory(data);
      }
    }
  }

  setImage(img: File): void {
    this.image = img;
    this.formCategory.patchValue({ pathimg: this.image.base64Sort });
  }

  onClickInactivate(item): void {
    this.categoriesService.inactivateCategory(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.LoadCategories();
        this.alertService.success(message)
      }
    })
  }

  onClickActivate(item): void {
    this.categoriesService.activateCategory(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.LoadCategories();
        this.alertService.success(message)
      }
    })
  }

  onClickDeleteImage(): void {
    this.image = {
      name: null,
      base64: null,
      base64Sort: null
    }
  }

}
