import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SectionsComponent } from './sections.component';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { ComponentsModule } from '../../../components/components.module';

const routes: Routes = [
  {
    path: '',
    component: SectionsComponent
  }
]

@NgModule({
  declarations: [
    SectionsComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    ReactiveFormsModule,
    ComponentsModule,
    CommonModule
  ]
})
export class SectionsModule { }
