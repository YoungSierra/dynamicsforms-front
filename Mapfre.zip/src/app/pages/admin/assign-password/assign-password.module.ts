import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AssignPasswordComponent } from './assign-password.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

const routes: Routes = [
  {
    path: '',
    component: AssignPasswordComponent
  }
];

@NgModule({
  declarations: [
    AssignPasswordComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes)
  ]
})
export class AssignPasswordModule { }
