import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AssignPasswordComponent } from './assign-password.component';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    component: AssignPasswordComponent
  }
];

@NgModule({
  declarations: [
    AssignPasswordComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class AssignPasswordModule { }
