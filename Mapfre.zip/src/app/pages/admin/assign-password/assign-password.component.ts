import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../../../services/user.service';
import { Response } from '../../../interfaces/response';
import { ECodeStatus } from '../../../enums/ecode-status';
import { AlertsService } from '../../../services/alerts.service';

@Component({
  selector: 'app-assign-password',
  templateUrl: './assign-password.component.html',
  styleUrls: ['./assign-password.component.scss']
})
export class AssignPasswordComponent implements OnInit {

  tokenAssignPassword: string = null;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private userServices: UserService,
    private alertServices: AlertsService
  ) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe((res: any) => {
      if (res.tk) {
        this.tokenAssignPassword = res.tk;
      } else {
        this.router.navigate(['login']);
      }
    })

    this.ValidateTokenPassword(this.tokenAssignPassword);
  }

  /** Methods */
  ValidateTokenPassword(token: string): void {
    this.userServices.validateTokenPassword(token).subscribe((res: Response) => {
      let { status, data, message } = res;
      if (status == ECodeStatus.Ok) {

      } else if (status == ECodeStatus.Unauthorized) {
        this.alertServices.error(message);
      }
    }, ({ error }) => {
      this.alertServices.error(error.message)
      setTimeout(() => {
        // this.router.navigate(['login']);
      }, 3000);
    })
  }

  /** Events */


}
