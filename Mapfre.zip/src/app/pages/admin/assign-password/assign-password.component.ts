import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../../../services/user.service';
import { Response } from '../../../interfaces/response';
import { ECodeStatus } from '../../../enums/ecode-status';
import { AlertsService } from '../../../services/alerts.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-assign-password',
  templateUrl: './assign-password.component.html',
  styleUrls: ['./assign-password.component.scss']
})
export class AssignPasswordComponent implements OnInit {

  tokenAssignPassword: string = null;
  formNewPassword: FormGroup;
  characterMore: boolean = false;
  characterSpecial: boolean = false;
  passwordSame: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private userServices: UserService,
    private alertServices: AlertsService,
    private fb: FormBuilder
  ) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe((res: any) => {
      if (res.tk) {
        this.tokenAssignPassword = res.tk;
      } else {
        this.router.navigate(['login']);
      }
    })

    this.ValidateTokenPassword(this.tokenAssignPassword).then(res => {
      if (!res) {
        this.alertServices.error("Link cadudado, debe solicitar un nuevo link");
      }
    })

    this.formNewPassword = this.fb.group({
      newPassword: ['', Validators.required],
      newPasswordConfirm: ['', Validators.required]
    })
  }

  /** Methods */
  ValidateTokenPassword(token: string): Promise<boolean> {

    return new Promise((resolve, rejact) => {
      this.userServices.validateTokenPassword(token).subscribe((res: Response) => {
        let { status, data, message } = res;
        if (status == ECodeStatus.Ok) {
          resolve(true);
        } else if (status == ECodeStatus.Unauthorized) {
          this.alertServices.error(message);
          resolve(false);
        }
      }, ({ error }) => {
        resolve(false);
      })
    })

  }

  UpdateToNewPassword(): void {
    this.userServices.assignNewPasswordByToken(this.tokenAssignPassword, this.formNewPassword.value.newPassword).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertServices.success(message);
        this.formNewPassword.reset();
        this.router.navigate(['login']);
      } else {
        this.alertServices.error(message)
      };
    })
  }

  /** Events */

  onClickValidateAndSavePassword(): void {
    if (this.characterMore && this.characterSpecial && this.passwordSame && this.formNewPassword.valid) {
      this.ValidateTokenPassword(this.tokenAssignPassword).then(res => {
        if (res) {
          this.UpdateToNewPassword();
        } else {
          this.alertServices.error("Link cadudado, debe solicitar un nuevo link");
        }
      })
    }
  }

  validatePassword(): void {
    const formPassword = this.formNewPassword.value;
    const expresionRegular = /[^a-zA-Z0-9\s]/;
    this.characterSpecial = expresionRegular.test(formPassword.newPassword);
    this.characterMore = (formPassword.newPassword.length >= 6) ? true : false;
    this.passwordSame = ((formPassword.newPassword == formPassword.newPasswordConfirm) && formPassword.newPassword != null && formPassword.newPassword != '' && formPassword.newPasswordConfirm != null && formPassword.newPasswordConfirm != '') ? true : false
  }

}
