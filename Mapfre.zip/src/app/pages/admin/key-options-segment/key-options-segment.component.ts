import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { KeyService } from '../../../services/key.service';
import { ECodeStatus } from '../../../enums/ecode-status';
import { SegmentsService } from '../../../services/segments.service';
import { Location } from '@angular/common';
import { AlertsService } from '../../../services/alerts.service';

@Component({
  selector: 'app-key-options-segment',
  templateUrl: './key-options-segment.component.html',
  styleUrls: ['./key-options-segment.component.scss']
})
export class KeyOptionsSegmentComponent implements OnInit {

  idOptionKey: string = '';
  listDataRelation: any[] = [];
  listKeys: any[] = [];
  listSegments: any[] = [];
  loadingData: boolean = true;

  constructor(
    private route: ActivatedRoute,
    private keyService: KeyService,
    private segmentService: SegmentsService,
    private location: Location,
    private alertServices: AlertsService
  ) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      if (params['id']) {
        this.idOptionKey = params['id'];
        this.LoadKeyOptionSegment(params['id']);
      }
    })
  }

  /** Methods */
  LoadKeyOptionSegment(idOptionKey): void {
    this.keyService.getKeyOptionSegmentAll().subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.LoadSegments();
        setTimeout(() => {
          this.LoadKeys();
        }, 2000);
        setTimeout(() => {
          this.listDataRelation = data.filter(e => e.keysOptId == idOptionKey);
          this.FilterData()
        }, 5000);
      } else {
        this.alertServices.error(message);
      }
    })
  }

  LoadSegments(): void {
    this.segmentService.getSegmentsAll().subscribe(response => {
      let { status, data, message } = response;
      if (status == ECodeStatus.Ok) {
        this.listSegments = data;
      }
    })
  }

  LoadKeys(): void {
    this.keyService.getKeys().subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listKeys = data;
      }
    })
  }

  FilterData(): void {
    this.listDataRelation.forEach(e => {
      let seg = this.listSegments.find(s => s.id == e.segmentsId);
      if (seg) {
        e.segmentName = seg.title
        e.segmentCode = seg.name
      } else {
        let key = this.listKeys.find(k => k.id == e.keysId);
        if (key) {
          e.keyName = key.question;
          e.keyCode = key.name
        }
      }
    })
    this.loadingData = false;
  }

  /** Events */
  onClickBack(): void {
    this.location.back();
  }

  onClickInactivate(item): void {
    this.keyService.inactivateKeyOptionSegment(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.LoadKeyOptionSegment(this.idOptionKey);
      } else {

      }
    })
  }

  onClickActivate(item): void {
    this.keyService.activateKeyOptionSegment(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.LoadKeyOptionSegment(this.idOptionKey);
      } else {

      }
    })
  }

}
