import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { KeyService } from '../../../services/key.service';
import { ECodeStatus } from '../../../enums/ecode-status';
import { SegmentsService } from '../../../services/segments.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-key-options-segment',
  templateUrl: './key-options-segment.component.html',
  styleUrls: ['./key-options-segment.component.scss']
})
export class KeyOptionsSegmentComponent implements OnInit {

  idOptionKey: string = '';
  listDataRelation: any[] = [];

  constructor(
    private route: ActivatedRoute,
    private keyService: KeyService,
    private segmentService: SegmentsService,
    private location: Location,
  ) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      if (params['id']) {
        this.idOptionKey = params['id'];
        this.LoadKeyOptionSegment(params['id']);
      }
    })
  }

  /** Methods */
  LoadKeyOptionSegment(idOptionKey): void {
    this.keyService.getKeyOptionSegmentAll().subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listDataRelation = data.filter(e => e.keysOptId == idOptionKey);
        this.LoadSegments();
      } else {

      }
    })
  }

  LoadSegments(): void {
    this.segmentService.getSegmentsAll().subscribe(response => {
      let { status, data, message } = response;
      if (status == ECodeStatus.Ok) {
        this.listDataRelation.forEach(e => {
          let seg = data.filter(s => s.id == e.segmentsId);
          if (seg.length) {
            e.segmentName = seg[0].title
            e.segmentCode = seg[0].name
          }
        })
      }
    })
  }

  /** Events */
  onClickBack(): void {
    this.location.back();
  }

  onClickInactivate(item): void {
    this.keyService.inactivateKeyOptionSegment(item.id).subscribe(response => {
      let { status, data, message } = response;

      if(status == ECodeStatus.Ok){
        this.LoadKeyOptionSegment(this.idOptionKey);
      }else{

      }
    })
  }

  onClickActivate(item): void {
    this.keyService.activateKeyOptionSegment(item.id).subscribe(response => {
      let { status, data, message } = response;

      if(status == ECodeStatus.Ok){
        this.LoadKeyOptionSegment(this.idOptionKey);
      }else{
        
      }
    })
  }

}
