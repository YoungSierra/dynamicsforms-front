import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KeyOptionsSegmentComponent } from './key-options-segment.component';

describe('KeyOptionsSegmentComponent', () => {
  let component: KeyOptionsSegmentComponent;
  let fixture: ComponentFixture<KeyOptionsSegmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KeyOptionsSegmentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(KeyOptionsSegmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
