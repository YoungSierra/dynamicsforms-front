import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { SegmentsService } from '../../../services/segments.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ColTypesService } from '../../../services/col-types.service';
import { ECodeStatus } from '../../../enums/ecode-status';
import { AlertsService } from '../../../services/alerts.service';
import { Location } from '@angular/common';
import { TablesService } from '../../../services/tables.service';

@Component({
  selector: 'app-segments-detail-colums',
  templateUrl: './segments-detail-colums.component.html',
  styleUrls: ['./segments-detail-colums.component.scss']
})
export class SegmentsDetailColumsComponent implements OnInit {

  @ViewChild('modalColums') modalColums: ElementRef;
  idTable: string = '';
  formSegmentDetailColums: FormGroup
  listColTypes: any[] = [];
  listColums: any[] = [];
  listTables: any[] = [];
  typeSelected: string = null;

  constructor(
    private router: ActivatedRoute,
    private fb: FormBuilder,
    private segmentsService: SegmentsService,
    private typeColService: ColTypesService,
    private tableService: TablesService,
    private modalService: NgbModal,
    private alertService: AlertsService,
    private location: Location
  ) { }

  ngOnInit(): void {
    this.router.params.subscribe(params => {
      console.log(params);
      if (params['id']) {
        this.idTable = params['id'];
        this.LoadSegmentDetailColums(this.idTable)
      }
    })

    this.LoadTable();

    this.formSegmentDetailColums = this.fb.group({
      segmentsDetId: [''],
      colname: ['', Validators.required],
      coltypesId: ['', Validators.required],
      colsize: [],
      tablesId: []
    })

    this.formSegmentDetailColums.valueChanges.subscribe((form: any) => {
      if (form.coltypesId) {
        let find: any = this.listColTypes.find(e => e.id == form.coltypesId);
        if(find){
          this.typeSelected = find.name;
        }
      }
    })
  }

  /** Methods */
  LoadSegmentDetailColums(id): void {
    this.segmentsService.getSegmentDetailTable().subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listColums = data.filter(e => e.segmentsDetId == id)
      }
      this.LoadQTypes();
    })
  }

  LoadQTypes(): void {
    this.typeColService.get().subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listColTypes = data;
      } else {
        this.alertService.error(message);
      }
    })
  }

  SaveColums(data): void {
    this.segmentsService.saveSegmentDetailTable(data).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSegmentDetailColums(this.idTable);
        this.formSegmentDetailColums.reset();
        this.modalService.dismissAll();
      }
    }, ({ error }) => {
      this.alertService.error(error);
    })
  }

  DeleteColum(id): void {
    this.segmentsService.deleteSegmentDetailTable(id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSegmentDetailColums(this.idTable);
      } else {
        this.alertService.error(message)
      }
    }, ({ error }) => {
      this.alertService.error(error)
    })
  }

  LoadTable(): void {
    this.tableService.getTables().subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listTables = data;
      } else {
        this.alertService.error(message)
      }
    })
  }

  /** Events */
  onClickNewColum(): void {
    this.formSegmentDetailColums.reset();
    this.modalService.open(this.modalColums, { centered: true, size: 'md' })
  }

  onClickSaveColum(): void {
    let data = this.formSegmentDetailColums.value
    data.segmentsDetId = this.idTable;
    this.SaveColums(data);
  }

  onClickInactivate(item): void {
    this.segmentsService.inactivateSegmentDetailTable(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSegmentDetailColums(this.idTable);
      } else {
        this.alertService.error(message)
      }
    }, ({ error }) => {
      this.alertService.error(error)
    })
  }

  onClickActivate(item): void {
    this.segmentsService.activateSegmentDetailTable(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSegmentDetailColums(this.idTable);
      } else {
        this.alertService.error(message)
      }
    }, ({ error }) => {
      this.alertService.error(error)
    })
  }

  onClickDeleteDetailOption(item): void {
    this.alertService.questionDelete("Seguro desea eliminar esta columna?").then(res => {
      if (res) {
        this.DeleteColum(item.id);
      }
    })
  }

  onClickBack(): void {
    this.location.back();
  }

}
