import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SegmentsDetailColumsComponent } from './segments-detail-colums.component';

describe('SegmentsDetailColumsComponent', () => {
  let component: SegmentsDetailColumsComponent;
  let fixture: ComponentFixture<SegmentsDetailColumsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SegmentsDetailColumsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SegmentsDetailColumsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
