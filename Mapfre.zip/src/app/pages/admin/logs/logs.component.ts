import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ECodeStatus } from '../../../enums/ecode-status';
import { LogsService } from '../../../services/logs.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ProgressBarService } from '../../../services/progress-bar.service';
import { AlertsService } from '../../../services/alerts.service';

@Component({
  selector: 'app-logs',
  templateUrl: './logs.component.html',
  styleUrls: ['./logs.component.scss']
})
export class LogsComponent implements OnInit {

  @ViewChild('modalLogDetail') modalLogDetail: ElementRef;
  listData: any[] = [];
  formFilter: FormGroup;
  modalInfo: any;

  constructor(
    private logsService: LogsService,
    private fb: FormBuilder,
    private modalService: NgbModal,
    private progressBar: ProgressBarService,
    private alerService: AlertsService
  ) { }

  ngOnInit(): void {

    this.formFilter = this.fb.group({
      date: [''],
      page: ['1'],
      size: ['50']
    })
  }

  /** Methods */
  LoadLogs(params): void {
    this.progressBar.startLoading();
    this.logsService.getLogs(params).subscribe(response => {
      let { status, data, message } = response;
      this.progressBar.completeLoading();
      if (status == ECodeStatus.Ok) {
        this.listData = data;
      } else {
        this.alerService.error(message);
      }
    }, err => {
      this.alerService.error(err);
    })
  }

  /** Events */
  onClickSearchLogs(): void {
    let data = this.formFilter.value
    if (!data.page) { data.page = 1 }
    if (!data.size) { data.page = 50 }
    this.LoadLogs(data);
  }

  onClickShowDetail(item): void {
    this.modalService.open(this.modalLogDetail, { centered: true, size: 'xl' });
    this.modalInfo = item;
  }

}
