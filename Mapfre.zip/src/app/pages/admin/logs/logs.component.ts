import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ECodeStatus } from '../../../enums/ecode-status';
import { LogsService } from '../../../services/logs.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ProgressBarService } from '../../../services/progress-bar.service';
import { AlertsService } from '../../../services/alerts.service';

@Component({
  selector: 'app-logs',
  templateUrl: './logs.component.html',
  styleUrls: ['./logs.component.scss']
})
export class LogsComponent implements OnInit {

  @ViewChild('modalLogDetail') modalLogDetail: ElementRef;
  listData: any[] = [];
  formFilter: FormGroup;
  modalInfo: any;
  loadingData: boolean = false;
  emailSearch: string = '';
  listMethods: any[] = [
    "LogIn",
    "GetUsers",
    "GetAll",
    "GetByKeysId",
    "GetByFormsId",
    "GetBySegmentId",
    "GetBySegmentsDetId",
    "GetBySectionsId",
    "GetByTablesId",
    "GetById",
    "Get",
    "Generate",
    "RememberPassword",
    "ValidatePasswordToken",
    "AssignPassword",
    "GetByProductId",
    "Update",
    "Activate",
    "Inactivate",
    "Delete",
    "Show",
    "ChangeOrderNum",
    "FormByToken",
    "FinishForm",
    "GetFormDet",
    "GetKeyOpt",
    "GetSegment",
    "Form-independent-bytoken",
    "GetPaginate",
    "ImportData",
    "SaveUser",
    "UpdateUser",
    "UpdatePassword",
    "DeleteUser",
    "ResendPasswordToken",
    "Create/Save"
  ];
  methodsSelected: any[] = [];

  constructor(
    private logsService: LogsService,
    private fb: FormBuilder,
    private modalService: NgbModal,
    private progressBar: ProgressBarService,
    private alerService: AlertsService
  ) { }

  ngOnInit(): void {

    this.formFilter = this.fb.group({
      date: ['', Validators.required],
      page: ['1'],
      size: ['50']
    })
  }

  /** Methods */
  LoadLogs(params): void {
    this.listData = [];
    this.progressBar.startLoading();
    this.loadingData = true;
    this.logsService.getLogs(params).subscribe(response => {
      let { status, data, message } = response;
      this.progressBar.completeLoading();
      this.loadingData = false;
      if (status == ECodeStatus.Ok) {
        this.FilterData(data);
      } else {
        this.alerService.error(message);
      }
    }, err => {
      this.alerService.error(err);
    })
  }

  FilterData(data: any): void {
    let newDataFiltered = data;
    if (this.emailSearch) {
      newDataFiltered = newDataFiltered.filter(e => e.email == this.emailSearch);
    }

    if (this.methodsSelected.length) {
      newDataFiltered = newDataFiltered.filter(e => this.methodsSelected.some(m => m == e.method));
    }
    this.listData = newDataFiltered;
  }

  /** Events */
  onClickSearchLogs(): void {
    if (this.formFilter.valid) {
      let data = this.formFilter.value
      if (!data.page) { data.page = 1 }
      if (!data.size) { data.page = 50 }
      this.LoadLogs(data);
    } else {
      this.alerService.error("Fecha es requerida");
    }
  }

  onClickShowDetail(item): void {
    this.modalService.open(this.modalLogDetail, { centered: true, size: 'xl' });
    this.modalInfo = item;
  }

}
