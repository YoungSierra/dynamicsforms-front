import { Location } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ECodeStatus } from '../../../enums/ecode-status';
import { AlertsService } from '../../../services/alerts.service';
import { QTypeService } from '../../../services/qtype.service';
import { SegmentsService } from '../../../services/segments.service';
import { TablesService } from '../../../services/tables.service';

@Component({
  selector: 'app-segments-detail-options',
  templateUrl: './segments-detail-options.component.html',
  styleUrls: ['./segments-detail-options.component.scss']
})
export class SegmentsDetailOptionsComponent implements OnInit {

  @ViewChild('modalSegmentDetailOption') modalSegmentDetailOption: ElementRef;
  listSegmentDetailOptions: any[] = [];
  idSegmentDetailOption: string = null;
  listQTypes: any[] = [];
  idSegmentDetail: string;
  formSegmentDetailOption: FormGroup;
  dataTable: any;

  constructor(
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private modalService: NgbModal,
    private segmentService: SegmentsService,
    private qTypeServices: QTypeService,
    private alertService: AlertsService,
    private location: Location,
    private tablesService: TablesService
  ) { }

  ngOnInit(): void {
    this.route.params.subscribe(res => {
      this.idSegmentDetail = res['id'];

      this.LoadSegmentDetailOptionsById(this.idSegmentDetail);
    })

    setTimeout(() => {
      this.LoadQtypes();
    }, 2000);

    this.formSegmentDetailOption = this.fb.group({
      segmentsDetId: [''],
      caption: [''],
      qtypesId: [''],
      tabnumcol: [''],
      tabnumrow: [''],
      tablesId: ['']
    })
  }

  /** Methods */
  LoadSegmentDetailOptionsById(id: string): void {
    this.segmentService.getSegmentDetailOptionsBySegmentDetailId(id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listSegmentDetailOptions = data;
      } else {
        this.LoadDependesTable(id);
      }
    })
  }

  LoadDependesTable(id): void {
    this.segmentService.getSegmentDetailById(id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.LoadTableName(data.tablesId);
      }
    })
  }

  LoadTableName(id): void {
    this.tablesService.getTableById(id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.dataTable = data;
      }
    })
  }

  LoadQtypes(): void {
    this.qTypeServices.get().subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listQTypes = data;
      }
    })
  }

  DeleteDetailOption(id): void {
    this.segmentService.deleteSegmentDetailOption(id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSegmentDetailOptionsById(this.idSegmentDetail);
      }
    })
  }

  SaveSegmentDetailOption(data): void {
    this.segmentService.saveSegmentDetailOption(data).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.modalService.dismissAll();
        this.LoadSegmentDetailOptionsById(this.idSegmentDetail);
      }
    })
  }

  /** Events */
  onClickNewSegmentDetailOption(): void {
    this.idSegmentDetailOption = null;
    this.formSegmentDetailOption.reset();
    this.modalService.open(this.modalSegmentDetailOption, { centered: true });
  }

  onClickEditDetailOption(item): void {
    this.idSegmentDetailOption = item.id;
    this.formSegmentDetailOption.patchValue(item);
    this.modalService.open(this.modalSegmentDetailOption, { centered: true });
  }

  onClickDeleteDetailOption(item): void {
    this.alertService.questionDelete("Desea eliminar esta opción?").then(res => {
      if (res) {
        this.DeleteDetailOption(item.id);
      }
    })
  }

  onClickBack(): void {
    this.location.back();
  }

  onClickInactivate(item): void {
    this.segmentService.inactivateSegmentDetailOption(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSegmentDetailOptionsById(this.idSegmentDetail);
      }
    })
  }

  onClickActivate(item): void {
    this.segmentService.activateSegmentDetailOption(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSegmentDetailOptionsById(this.idSegmentDetail);
      }
    })
  }

  onClickSaveSegmentDetailOption(): void {
    let data = this.formSegmentDetailOption.value;
    data.segmentsDetId = this.idSegmentDetail;
    if (!this.idSegmentDetailOption) {
      this.SaveSegmentDetailOption(data);
    }
  }

}
