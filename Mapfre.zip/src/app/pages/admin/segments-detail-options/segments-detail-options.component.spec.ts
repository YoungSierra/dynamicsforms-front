import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SegmentsDetailOptionsComponent } from './segments-detail-options.component';

describe('SegmentsDetailOptionsComponent', () => {
  let component: SegmentsDetailOptionsComponent;
  let fixture: ComponentFixture<SegmentsDetailOptionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SegmentsDetailOptionsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SegmentsDetailOptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
