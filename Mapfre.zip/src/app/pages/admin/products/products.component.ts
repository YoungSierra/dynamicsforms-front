import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ECodeStatus } from '../../../enums/ecode-status';
import { File } from '../../../interfaces/file';
import { AlertsService } from '../../../services/alerts.service';
import { ProductsService } from '../../../services/products.service';
import { SectionsService } from '../../../services/sections.service';
import { CategoriesService } from '../../../services/categories.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss']
})
export class ProductsComponent implements OnInit {

  @ViewChild('productModal') productModal: ElementRef;
  listProducts: any[] = [];
  listSections: any[] = [];
  listCategories: any[] = [];
  listCategoriesSec: any[] = [];
  idProductEdit: any;
  formProduct: FormGroup;
  imageProduct: File = {
    name: null,
    base64: null,
    base64Sort: null
  };
  p: number = 1;

  constructor(
    private productsServices: ProductsService,
    private sectionServices: SectionsService,
    private categoriesServices: CategoriesService,
    private modalService: NgbModal,
    private fb: FormBuilder,
    private alertService: AlertsService
  ) { }

  ngOnInit(): void {
    this.LoadProducts();

    setTimeout(() => {
      this.LoadSections();
    }, 2000);

    setTimeout(() => {
      this.LoadCategories();
    }, 3000);

    this.formProduct = this.fb.group({
      name: ['', Validators.required],
      sectionsId: ['', Validators.required],
      categoriesId: [],
      ordernum: ['', Validators.required],
      pathimg: ['', Validators.required]
    })
  }

  /** Methods */
  LoadProducts(): void {
    this.productsServices.getProductsAll().subscribe(response => {
      let { status, data } = response;

      if (status == ECodeStatus.Ok) {
        this.listProducts = data;
      }
    })
  }

  LoadSections(): void {
    this.sectionServices.getSections().subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listSections = data;
      } else {

      }
    })
  }

  LoadCategories(): void {
    this.categoriesServices.getAllCategories().subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listCategories = data;
      }
    })
  }

  SaveProduct(data): void {
    this.productsServices.saveProduct(data).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.LoadProducts();
        this.modalService.dismissAll();
        this.alertService.success(message);
      } else {
        this.alertService.error(message);
      }
    })
  }

  UpdateProduct(id, data): void {
    this.productsServices.updateProduct(id, data).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.LoadProducts();
        this.modalService.dismissAll();
        this.alertService.success(message);
      } else {
        this.alertService.error(message);
      }
    })
  }

  DeleteProduct(id): void {
    this.productsServices.deleteProduct(id).subscribe(response => {
      let { status, data, message } = response;

      if (status) {
        this.alertService.success(message);
        this.LoadProducts();
      } else {
        this.alertService.error(message);
      }
    })
  }

  /** Events */
  onClickInactivate(item): void {
    this.productsServices.inactivateProduct(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.LoadProducts();
        this.alertService.success(message);
      }
    })
  }

  onClickActivate(item): void {
    this.productsServices.activateProduct(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.LoadProducts();
        this.alertService.success(message);
      }
    })
  }

  onClickNewProduct(): void {
    this.idProductEdit = null;
    this.formProduct.reset();
    this.formProduct.get('pathimg').setValidators([Validators.required]);

    this.imageProduct = { name: null, base64: null, base64Sort: null }
    this.modalService.open(this.productModal, { centered: true })
  }

  onClickEditProduct(item): void {
    this.idProductEdit = item.id;
    if (item.pathimg) {
      this.imageProduct = {
        name: 'yes',
        base64: item.pathimg,
        base64Sort: null,
      }
    }
    delete item.pathimg;
    this.formProduct.patchValue(item);
    this.formProduct.get('pathimg').clearValidators();
    this.formProduct.get('pathimg').updateValueAndValidity();
    this.modalService.open(this.productModal, { centered: true });
  }

  onClickDeleteProduct(item): void {
    this.alertService.questionDelete("Desea eliminar el producto?").then(res => {
      if (res) {
        this.DeleteProduct(item.id);
      }
    })
  }

  setImage(img: File): void {
    this.imageProduct = img;
    this.formProduct.patchValue({ pathimg: this.imageProduct.base64Sort });
  }

  onClickSaveProduct(): void {
    if (this.formProduct.valid) {
      let data = this.formProduct.value;
      if(data.categoriesId){ delete data.sectionsId }
      if (this.idProductEdit) {
        this.UpdateProduct(this.idProductEdit, data);
      } else {
        this.SaveProduct(data);
      }
    }else{
      this.alertService.error("Completar campos");
    }
  }

  onClickDeleteImage(): void {
    this.imageProduct = {
      name: null,
      base64: null,
      base64Sort: null
    }

    this.formProduct.patchValue({ pathimg: null });
  }

  onChangeSection(): void {
    let data = this.formProduct.value.sectionsId;
    if(data){
      this.listCategoriesSec = this.listCategories.filter(e => e.sectionsId == data);
    }else{
      this.formProduct.patchValue({ categoriesId: null });
      this.listCategoriesSec = [];
    }
  }

}
