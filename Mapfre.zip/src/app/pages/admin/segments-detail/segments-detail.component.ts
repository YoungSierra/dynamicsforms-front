import { Location } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ECodeStatus } from '../../../enums/ecode-status';
import { AlertsService } from '../../../services/alerts.service';
import { ApiService } from '../../../services/api.service';
import { QTypeService } from '../../../services/qtype.service';
import { SegmentsService } from '../../../services/segments.service';
import { TablesService } from '../../../services/tables.service';
import { ThemeService } from '../../../services/theme.service';
import { animate, style, transition, trigger } from '@angular/animations';
import { KeyService } from '../../../services/key.service';
import { Response } from '../../../interfaces/response';

@Component({
  selector: 'app-segments-detail',
  templateUrl: './segments-detail.component.html',
  styleUrls: ['./segments-detail.component.scss'],
  animations: [
    trigger(
      'inOutAnimation',
      [
        transition(
          ':enter',
          [
            style({ height: 0, opacity: 0 }),
            animate('0.5s ease-out',
              style({ height: 62, opacity: 1 }))
          ]
        ),
        transition(
          ':leave',
          [
            style({ height: 62, opacity: 1 }),
            animate('0.5s ease-in',
              style({ height: 0, opacity: 0 }))
          ]
        )
      ]
    )
  ]
})
export class SegmentsDetailComponent implements OnInit {

  @ViewChild('segmentDetailModal') segmentDetailModal: ElementRef;
  @ViewChild('previewSegment') previewSegment: ElementRef;
  idSegment: string = null;
  idSegmentDetail: string = null;
  listSegmentDetail: any[] = [];
  listQTypes: any[] = [];
  listThemes: any[] = [];
  listTables: any[] = [];
  listKeys: any[] = [];
  segmentData: any = null;
  formSegmentDetail: FormGroup;
  segmentForPreview: any;
  addInputView: string;
  dateMax: any = "";
  listSegmentDetailCopy: any[] = [];

  constructor(
    private router: ActivatedRoute,
    private segmentService: SegmentsService,
    private qTypesService: QTypeService,
    private modalService: NgbModal,
    private fb: FormBuilder,
    private alertService: AlertsService,
    private tablesServices: TablesService,
    private keyServices: KeyService,
    private location: Location
  ) { }

  ngOnInit(): void {
    this.router.params.subscribe(params => {
      if (params['id']) {
        this.idSegment = params['id'];

        this.LoadSegmentsDetail(this.idSegment);
        setTimeout(() => {
          this.LoadSegmentInfo(this.idSegment);
        }, 2000);

      } else {

      }
    })

    setTimeout(() => { this.LoadQTypes(); }, 4000);

    setTimeout(() => { this.LoadTables(); }, 5000);

    setTimeout(() => { this.LoadKeys(); }, 6000);

    this.formSegmentDetail = this.fb.group({
      segmentsId: ['', Validators.required],
      question: ['', Validators.required],
      colsize: ['', [Validators.required, Validators.min(1), Validators.max(12)]],
      qtypesId: ['', Validators.required],
      aboveOf: [""],
      tabnumcol: [''],
      tabnumrow: [''],
      required: [''],
      tablesId: [''],
      keyId: [''],
      boldFont: [0],
      minValue: [''],
      maxValue: [''],
      showVerticaly: ['']
    })

    this.formSegmentDetail.valueChanges.subscribe(form => {
      if (form.qtypesId) {
        let find = this.listQTypes.find(qTypes => qTypes.id == form.qtypesId);
        if (find) {
          this.addInputView = find.name;
        } else {
          this.addInputView = null;
        }
      }
    })

    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');

    this.dateMax = `${year}-${month}-${day}`;

  }

  /** Methods */

  LoadSegmentsDetail(id): void {
    this.segmentService.getDetailBySegmentId(id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listSegmentDetail = data;
      }
    })
  }

  LoadSegmentInfo(id): void {
    this.segmentService.getSegmentById(id).subscribe(response => {
      let { status, data, message } = response

      if (status == ECodeStatus.Ok) {
        this.segmentData = data
      }
    })
  }

  LoadQTypes(): void {
    this.qTypesService.get().subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listQTypes = data;
      }
    })
  }

  LoadKeys(): void {
    this.keyServices.getKeys().subscribe((response: Response) => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listKeys = data;
      } else {
        this.alertService.error(message);
      }

    })
  }

  LoadTables(): void {
    this.tablesServices.getTables().subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listTables = data;
      }
    })
  }

  SaveSegmentDetail(data): void {
    this.segmentService.saveSegmentDetail(data).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.modalService.dismissAll();
        this.LoadSegmentsDetail(this.idSegment);
      } else {
        this.alertService.error(message);
      }
    })
  }

  UpdateSegmentDetail(id, data): void {
    this.segmentService.updateSegmentDetail(id, data).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.modalService.dismissAll();
        this.alertService.success(message);
        this.LoadSegmentsDetail(this.idSegment);
      } else {
        this.alertService.error(message);
      }
    })
  }

  DeleteDetail(id): void {
    this.segmentService.deleteSegmentDetail(id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSegmentsDetail(this.idSegment);
      } else {
        this.alertService.error(message);
      }
    })
  }



  /** Events */

  onClickNewDetail(): void {
    this.idSegmentDetail = null;
    this.formSegmentDetail.reset();
    this.formSegmentDetail.patchValue({ required: false, segmentsId: this.idSegment, boldFont: 0, aboveOf: "" });
    this.modalService.open(this.segmentDetailModal, { centered: true, backdrop: 'static', keyboard: false, });
    this.listSegmentDetailCopy = [...this.listSegmentDetail];
  }

  onClickEditDetail(item: any): void {
    this.idSegmentDetail = item.id;
    this.formSegmentDetail.patchValue(item);
    this.modalService.open(this.segmentDetailModal, { centered: true, backdrop: 'static', keyboard: false, });
    let newList = [... this.listSegmentDetail];
    let indexQuestion = newList.findIndex(e => e.id == item.id);
    newList.splice(indexQuestion, 1);
    this.listSegmentDetailCopy = newList;  
  }

  onClickPreview(): void {
    this.segmentService.segmentDraw(this.idSegment).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        console.log(JSON.stringify(data));        
        this.segmentForPreview = data;
      }
    })
    this.modalService.open(this.previewSegment, { centered: true, backdrop: 'static', keyboard: false, size: 'xl' });
  }

  onClickInactivate(item): void {
    this.segmentService.inactivateSegmentDetail(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSegmentsDetail(this.idSegment);
      } else {
        this.alertService.error(message);
      }
    })
  }

  onClickActivate(item): void {
    this.segmentService.activateSegmentDetail(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSegmentsDetail(this.idSegment);
      } else {
        this.alertService.error(message);
      }
    })
  }

  onClickSaveSegmentDetail(): void {
    if (this.formSegmentDetail.valid) {
      let data = this.formSegmentDetail.value;
      (data.required) ? data.required = 1 : data.required = 0;
      (data.boldFont) ? data.boldFont = 1 : data.boldFont = 0;
      (data.showVerticaly) ? data.showVerticaly = 1 : data.showVerticaly = 0;
      if(data.aboveOf == null){ this.alertService.error('Verificar campo "Arriba de"'); return; }
      if (this.idSegmentDetail) {
        this.UpdateSegmentDetail(this.idSegmentDetail, data);
      } else {
        this.SaveSegmentDetail(data);
      }
    }
  }

  onValidateShowButton(id): boolean {
    let list = ['9d43dca4-9955-45f1-8089-64adca65c305', '2693e982-1242-443f-9b97-adf59bc07b23', '4d39279a-bb33-482a-b19e-aaa9ef0c6163', '3e9f3654-3fed-4889-9fe9-277529c9ac24', 'b1bbcb2d-9478-4d3b-a660-38e735de6d07']
    let found = list.filter(element => element == id);
    if (found.length) {
      return true;
    } else {
      return false
    }
  }

  onClickDeleteDetail(item): void {
    this.alertService.questionDelete("Desea eliminar este campo?").then(res => {
      if (res) {
        this.DeleteDetail(item.id);
      }
    })
  }

  onClickBack(): void {
    this.location.back()
  }

  createArray(rows: any) {
    let array = [];

    for (let i = 0; i < rows; i++) {
      let arrayCol = [];
      array.push(arrayCol);
    }

    return array;
  }


  onChangeValidateFuture(seg_det: any, index = 0): void {
    let value = (seg_det?.value) ? seg_det.value : seg_det['value_' + index];
    let date1 = new Date(this.dateMax);
    let date2 = new Date(value);
    if (date2.getTime() < date1.getTime()) {
      this.alertService.error("No se puede colocar fechas menores a hoy");
      seg_det.value = this.dateMax;
    }

  }



}
