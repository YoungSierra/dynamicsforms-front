import { Location } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ECodeStatus } from '../../../enums/ecode-status';
import { AlertsService } from '../../../services/alerts.service';
import { ApiService } from '../../../services/api.service';
import { QTypeService } from '../../../services/qtype.service';
import { SegmentsService } from '../../../services/segments.service';
import { TablesService } from '../../../services/tables.service';
import { ThemeService } from '../../../services/theme.service';
import { animate, style, transition, trigger } from '@angular/animations';

@Component({
  selector: 'app-segments-detail',
  templateUrl: './segments-detail.component.html',
  styleUrls: ['./segments-detail.component.scss'],
  animations: [
    trigger(
      'inOutAnimation',
      [
        transition(
          ':enter',
          [
            style({ height: 0, opacity: 0 }),
            animate('0.5s ease-out',
              style({ height: 62, opacity: 1 }))
          ]
        ),
        transition(
          ':leave',
          [
            style({ height: 62, opacity: 1 }),
            animate('0.5s ease-in',
              style({ height: 0, opacity: 0 }))
          ]
        )
      ]
    )
  ]
})
export class SegmentsDetailComponent implements OnInit {

  @ViewChild('segmentDetailModal') segmentDetailModal: ElementRef;
  @ViewChild('previewSegment') previewSegment: ElementRef;
  idSegment: string = null;
  idSegmentDetail: string = null;
  listSegmentDetail: any[] = [];
  listQTypes: any[] = [];
  listThemes: any[] = [];
  listTables: any[] = [];
  segmentData: any = null;
  formSegmentDetail: FormGroup;
  segmentForPreview: any;

  constructor(
    private router: ActivatedRoute,
    private segmentService: SegmentsService,
    private qTypesService: QTypeService,
    private modalService: NgbModal,
    private fb: FormBuilder,
    private alertService: AlertsService,
    private tablesServices: TablesService,
    private location: Location
  ) { }

  ngOnInit(): void {
    this.router.params.subscribe(params => {
      if (params['id']) {
        this.idSegment = params['id'];

        this.LoadSegmentsDetail(this.idSegment);
        setTimeout(() => {
          this.LoadSegmentInfo(this.idSegment);
        }, 2000);

      } else {

      }
    })

    setTimeout(() => {
      this.LoadQTypes();
    }, 4000);

    setTimeout(() => {
      this.LoadTables();
    }, 5000);

    this.formSegmentDetail = this.fb.group({
      segmentsId: ['', Validators.required],
      question: ['', Validators.required],
      colsize: ['', [Validators.required, Validators.min(1), Validators.max(12)]],
      qtypesId: ['', Validators.required],
      tabnumcol: [''],
      tabnumrow: [''],
      required: [''],
      tablesId: ['']
    })
  }

  /** Methods */

  LoadSegmentsDetail(id): void {
    this.segmentService.getDetailBySegmentId(id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listSegmentDetail = data;
      }
    })
  }

  LoadSegmentInfo(id): void {
    this.segmentService.getSegmentById(id).subscribe(response => {
      let { status, data, message } = response

      if (status == ECodeStatus.Ok) {
        this.segmentData = data
      }
    })
  }

  LoadQTypes(): void {
    this.qTypesService.get().subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listQTypes = data;
      }
    })
  }

  LoadTables(): void {
    this.tablesServices.getTables().subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listTables = data;
      }
    })
  }

  SaveSegmentDetail(data): void {
    this.segmentService.saveSegmentDetail(data).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.modalService.dismissAll();
        this.LoadSegmentsDetail(this.idSegment);
      } else {
        this.alertService.error(message);
      }
    })
  }

  UpdateSegmentDetail(id, data): void {
    this.segmentService.updateSegmentDetail(id, data).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.modalService.dismissAll();
        this.alertService.success(message);
        this.LoadSegmentsDetail(this.idSegment);
      } else {
        this.alertService.error(message);
      }
    })
  }

  DeleteDetail(id): void {
    this.segmentService.deleteSegmentDetail(id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSegmentsDetail(this.idSegment);
      } else {
        this.alertService.error(message);
      }
    })
  }



  /** Events */

  onClickNewDetail(): void {
    this.idSegmentDetail = null;
    this.formSegmentDetail.reset();
    this.formSegmentDetail.patchValue({ required: false, segmentsId: this.idSegment });
    this.modalService.open(this.segmentDetailModal, { centered: true, backdrop: 'static', keyboard: false, });
  }

  onClickEditDetail(item): void {
    this.idSegmentDetail = item.id;
    this.formSegmentDetail.patchValue(item);
    this.modalService.open(this.segmentDetailModal, { centered: true, backdrop: 'static', keyboard: false, });
  }

  onClickPreview(): void {
    this.segmentService.segmentDraw(this.idSegment).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.segmentForPreview = data;
      }
    })
    this.modalService.open(this.previewSegment, { centered: true, backdrop: 'static', keyboard: false, size: 'xl' });
  }

  onClickInactivate(item): void {
    this.segmentService.inactivateSegmentDetail(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSegmentsDetail(this.idSegment);
      } else {
        this.alertService.error(message);
      }
    })
  }

  onClickActivate(item): void {
    this.segmentService.activateSegmentDetail(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSegmentsDetail(this.idSegment);
      } else {
        this.alertService.error(message);
      }
    })
  }

  onClickSaveSegmentDetail(): void {
    if (this.formSegmentDetail.valid) {
      let data = this.formSegmentDetail.value;
      (data.required) ? data.required = 1 : data.required = 0;
      if (this.idSegmentDetail) {
        this.UpdateSegmentDetail(this.idSegmentDetail, data);
      } else {
        this.SaveSegmentDetail(data);
      }
    }
  }

  onValidateShowButton(id): boolean {
    let list = ['9d43dca4-9955-45f1-8089-64adca65c305', '2693e982-1242-443f-9b97-adf59bc07b23', '4d39279a-bb33-482a-b19e-aaa9ef0c6163', '3e9f3654-3fed-4889-9fe9-277529c9ac24', 'b1bbcb2d-9478-4d3b-a660-38e735de6d07']
    let found = list.filter(element => element == id);
    if (found.length) {
      return true;
    } else {
      return false
    }
  }

  onClickDeleteDetail(item): void {
    this.alertService.questionDelete("Desea eliminar este campo?").then(res => {
      if (res) {
        this.DeleteDetail(item.id);
      }
    })
  }

  onClickBack(): void {
    this.location.back()
  }

  createArray(rows: any) {
    let array = [];

    for (let i = 0; i < rows; i++) {
      let arrayCol = [];
      array.push(arrayCol);
    }

    return array;
  }


}
