import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SegmentsDetailComponent } from './segments-detail.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { DirectivesModule } from '../../../directives/directives.module';

const routes: Routes = [
  {
    path: '',
    component: SegmentsDetailComponent
  }
]

@NgModule({
  declarations: [
    SegmentsDetailComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NgbTooltipModule,
    DirectivesModule,
    RouterModule.forChild(routes)
  ]
})
export class SegmentsDetailModule { }
