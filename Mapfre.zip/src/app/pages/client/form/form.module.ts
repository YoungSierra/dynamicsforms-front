import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormComponent } from './form.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NgProgressModule } from 'ngx-progressbar';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { ComponentsModule } from '../../../components/components.module';
import { OnlyNumbersDirective } from '../../../helpers/only-numbers.directive';
import { NoNegativeDirective } from '../../../helpers/no-negative.directive';
import { DateExpiredDirective } from '../../../directives/date-expired.directive';
import { DirectivesModule } from '../../../directives/directives.module';


const routes: Routes = [
  {
    path: '',
    component: FormComponent
  }
]

@NgModule({
  declarations: [
    FormComponent,
    OnlyNumbersDirective,
    NoNegativeDirective,
  ],
  imports: [
    CommonModule,
    FormsModule,
    NgProgressModule,
    PdfViewerModule,
    ComponentsModule,
    DirectivesModule,
    RouterModule.forChild(routes)
  ]
})
export class FormModule { }
