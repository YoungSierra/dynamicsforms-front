import { Location } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { environment } from '../../../../environments/environment';
import { ECodeStatus } from '../../../enums/ecode-status';
import { ApiService } from '../../../services/api.service';

@Component({
  selector: 'app-survey',
  templateUrl: './survey.component.html',
  styleUrls: ['./survey.component.scss']
})
export class SurveyComponent implements OnInit {

  @ViewChild('modalEmail') modalEmail: any;

  products: any[] = [];
  email: string = '';
  idProduct: string = '';
  productsView: number = 1;
  titleSubProduct: string = '';
  subtitleSubProduct: string = ''
  productsDetail: any[] = [];
  productsCategories: any[] = [];
  emailIsValid: boolean = false;
  pathImgSection: string = "assets/images/vida-indi.jpg";
  pathImgHome: string = "assets/images/home.jpg"

  urlEndPoint: string = environment.apiEndPoint

  constructor(
    private modalService: NgbModal,
    private apiService: ApiService,
    private http: HttpClient,
    private location: Location
  ) { }

  ngOnInit(): void {
    this.LoadProducts();
  }

  /** Methods */

  LoadProducts(): void {
    this.apiService.getMenuProducts().subscribe(response => {
      let { status, data } = response;

      if (status == ECodeStatus.Ok) {
        this.products = data;
      }
    })
  }

  GenerateLink(idProduct: string, email: string): void {
    let headerConfig = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json; charset=UTF-8',
        'User-Email': email
      })
    };

    this.http.post(`${this.urlEndPoint}links/generate/${idProduct}`, {}, headerConfig).subscribe((response: any) => {
      let { status, data, message } = response;
      if (status == 200) {
        this.productsView = 5;
      } else {
        alert(message);
      }
    })
  }

  /** Events */

  onClickShowModal(item: any): void {
    this.idProduct = item.p_id;
    this.modalService.open(this.modalEmail, { size: 'md', centered: true });
  }

  onClickGenerateLink(): void {
    let expresion = /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
    if (this.email.match(expresion)) {
      localStorage.setItem('email', this.email);
      this.GenerateLink(this.idProduct, this.email)
    } else {
      alert("Email no valido");
    }
  }

  onClickShowDetail(item: any): void {
    this.titleSubProduct = (item.s_name) ? item.s_name : this.titleSubProduct;
    if (item.s_backgroundimg) {
      this.pathImgSection = item.s_backgroundimg;
    } else if (!item.s_backgroundimg && this.productsView == 1) {
      this.pathImgSection = null;
    }
    this.subtitleSubProduct = (item.c_name) ? item.c_name : '';
    if (item.categories && this.productsView == 1) {
      this.productsView = 2;
      this.productsCategories = item.categories;
    } else {
      if (this.productsView == 1) { this.productsCategories = [] }
      this.productsView = 3;
      this.productsDetail = item.products;
    }
  }

  onClickProductView(item: any): void {
    this.idProduct = item.p_id;
    this.productsView = 4;
  }

  onClickBack(): void {

    if (!this.productsCategories.length && this.productsView == 3) {
      this.productsView = 1;
    } else {
      this.productsView--;
    }
  }

}
