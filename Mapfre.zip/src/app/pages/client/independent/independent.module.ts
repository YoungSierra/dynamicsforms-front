import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IndependentComponent } from './independent.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';

const route: Routes = [
  {
    path: '',
    component: IndependentComponent
  }
]

@NgModule({
  declarations: [
    IndependentComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule.forChild(route)
  ]
})
export class IndependentModule { }
