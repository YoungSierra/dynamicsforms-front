import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertsService } from '../../../services/alerts.service';
import { FormsService } from '../../../services/forms.service';
import { ECodeStatus } from '../../../enums/ecode-status';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-independent',
  templateUrl: './independent.component.html',
  styleUrls: ['./independent.component.scss']
})
export class IndependentComponent implements OnInit {

  dataForm: any = {
    title: '',
    subtitle: '',
    pathimg: ''
  };
  urlEndPoint: string = environment.apiEndPoint
  email: string = '';
  linkGenerated: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private alertServices: AlertsService,
    private formServices: FormsService,
    private http: HttpClient,
  ) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe((res: any) => {      
      if (res) {
        localStorage.setItem('token', res.tk);
        this.ValidateLinkToken();
      } else {
        this.alertServices.error("Link no disponible, solicitar uno nuevo");
      }
    })
  }

  /** Methods */
  ValidateLinkToken(): void {
    this.formServices.linkFormIndependent().subscribe((response) => {
      let { status, data, message } = response

      if (status == ECodeStatus.Ok) {
        this.dataForm = data.product;
      }
    })
  }

  GenerateLink(idProduct: string, email: string): void {
    let headerConfig = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json; charset=UTF-8',
        'User-Email': email,
        'Content-Length': '0'
      })
    };

    this.http.post(`${this.urlEndPoint}links/generate/${idProduct}`, {}, headerConfig).subscribe((response: any) => {
      let { status, data, message } = response;
      if (status == 200) {
        this.linkGenerated = true;
      } else {
        alert(message);
      }
    })
  }

  /** Events */
  onClickGenerateLink(): void {
    let expresion = /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
    if (this.email.match(expresion)) {
      localStorage.setItem('email', this.email);
      this.GenerateLink(this.dataForm.id, this.email)
    } else {
      alert("Email no valido");
    }
  }

}
