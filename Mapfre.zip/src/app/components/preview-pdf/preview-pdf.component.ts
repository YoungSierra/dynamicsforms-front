import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-preview-pdf',
  templateUrl: './preview-pdf.component.html',
  styleUrls: ['./preview-pdf.component.scss']
})
export class PreviewPdfComponent implements OnInit {

  @Input() formQuestions: any[] = [];

  constructor() { }

  ngOnInit(): void {
  }

}
