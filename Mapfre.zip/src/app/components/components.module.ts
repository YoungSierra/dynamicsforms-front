import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FileuploadComponent } from './fileupload/fileupload.component';
import { DirectivesModule } from '../directives/directives.module';



@NgModule({
  declarations: [
    FileuploadComponent
  ],
  imports: [
    CommonModule,
    DirectivesModule
  ],
  exports: [
    FileuploadComponent
  ]
})
export class ComponentsModule { }
