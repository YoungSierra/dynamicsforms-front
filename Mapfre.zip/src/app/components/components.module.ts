import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FileuploadComponent } from './fileupload/fileupload.component';
import { DirectivesModule } from '../directives/directives.module';
import { VirtualSelectComponent } from './virtual-select/virtual-select.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormsModule } from '@angular/forms'


@NgModule({
  declarations: [
    FileuploadComponent,
    VirtualSelectComponent
  ],
  imports: [
    CommonModule,
    DirectivesModule,
    NgSelectModule,
    FormsModule
  ],
  exports: [
    FileuploadComponent,
    VirtualSelectComponent
  ]
})
export class ComponentsModule { }
