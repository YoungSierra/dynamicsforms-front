import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VirtualSelectComponent } from './virtual-select.component';

describe('VirtualSelectComponent', () => {
  let component: VirtualSelectComponent;
  let fixture: ComponentFixture<VirtualSelectComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VirtualSelectComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VirtualSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
