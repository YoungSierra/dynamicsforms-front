import { Component, EventEmitter, Input, OnInit, Output, forwardRef } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'app-virtual-select',
  templateUrl: './virtual-select.component.html',
  styleUrls: ['./virtual-select.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => VirtualSelectComponent),
      multi: true,
    },
  ],
})
export class VirtualSelectComponent implements OnInit {

  @Input() options: any[] = [];
  @Input() invalid: boolean;
  @Input() pageSize = 150;
  @Output() optionSelected = new EventEmitter<any>();
  @Input() propertyLabel: string;
  @Input() propertyValue: string;
  optionsBuffer: any[] = [];
  loading = false;

  constructor() { }

  ngOnInit(): void {
    this.optionsBuffer = this.options.slice(0, this.pageSize)
  }

  visibleOptions: any[] = [];
  currentPage = 1;

  selectedOption: any;

  private onChange = (option: any) => { };
  private onTouched = () => { };

  writeValue(option: any): void {
    this.selectedOption = option;
  }

  registerOnChange(fn: (option: any) => void): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  selectOption(option: any): void {
    this.selectedOption = option[this.propertyValue];
    this.onChange(option[this.propertyValue]);
    this.onTouched();
    this.optionSelected.emit(option[this.propertyValue]);
  }

  onScrollToEnd() {
    this.fetchMore();
  }

  onScroll({ end }) {
    if (this.loading || this.options.length <= this.optionsBuffer.length) {
      return;
    }

    if (end + this.pageSize >= this.optionsBuffer.length) {
      this.fetchMore();
    }
  }

  private fetchMore() {
    const len = this.optionsBuffer.length;
    const more = this.options.slice(len, this.pageSize + len);
    this.loading = true;
    // using timeout here to simulate backend API delay
    setTimeout(() => {
      this.optionsBuffer = this.optionsBuffer.concat(more);
      this.loading = false;
    }, 200);
  }

  onSearchItem(event: any): void {
    if (event?.term && event?.term !== "") {
      this.optionsBuffer = [];
      this.optionsBuffer = this.options.filter((e) => e[this.propertyLabel].toLowerCase().includes(event.term.toLowerCase()));
    } else {
      this.optionsBuffer = [];
      this.optionsBuffer = this.options.slice(0, this.pageSize);
    }
  }

  onClearSearch(event: any): void {
    this.optionsBuffer = this.options.slice(0, this.pageSize)
  }


}
