import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DragAndDropFileDirective } from './drag-and-drop-file.directive';
import { DateExpiredDirective } from './date-expired.directive';
import { DatePickerDirective } from './date-picker.directive';


@NgModule({
  declarations: [DragAndDropFileDirective, DateExpiredDirective, DatePickerDirective],
  imports: [
    CommonModule
  ],
  exports: [DragAndDropFileDirective, DateExpiredDirective, DatePickerDirective]
})
export class DirectivesModule { }
