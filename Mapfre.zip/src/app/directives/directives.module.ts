import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DragAndDropFileDirective } from './drag-and-drop-file.directive';
import { DateExpiredDirective } from './date-expired.directive';


@NgModule({
  declarations: [DragAndDropFileDirective, DateExpiredDirective],
  imports: [
    CommonModule
  ],
  exports: [DragAndDropFileDirective, DateExpiredDirective]
})
export class DirectivesModule { }
