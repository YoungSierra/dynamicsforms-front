import { Directive, ElementRef, HostListener, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appDateExpired]'
})
export class DateExpiredDirective {

  constructor(private el: ElementRef) { }

  @HostListener('input', ['$event']) onInput(event: any) {
    const input = event.target;
    let value = input.value.replace(/\D/g, ''); // Elimina caracteres no numéricos
    if (value.length > 4) {
      // Limita el año a dos dígitos
      value = `${value.slice(0, 2)}/${value.slice(2, 4)}`;
    } else if (value.length > 2) {
      // Añade la barra después de los dos primeros dígitos
      value = `${value.slice(0, 2)}/${value.slice(2)}`;
    }

    input.value = value;

    if (value) {
      const parts = value.split('/');
      const month = parseInt(parts[0], 10);
      const year = parseInt(parts[1], 10);

      if (isNaN(month) || isNaN(year) || month < 1 || month > 12 || year < 0 || year > 99) {
        // Si la fecha no es válida, puedes agregar lógica para manejar el error, como agregar una clase de estilo rojo, mostrar un mensaje, etc.
        input.classList.add('is-invalid');
      } else {
        // Si la fecha es válida, puedes quitar la clase de estilo rojo y realizar otras acciones necesarias.
        input.classList.remove('is-invalid');
      }
    }else{
      input.classList.remove('is-invalid');
    }
  }

}
