import { Directive, ElementRef, HostListener, Input, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appDatePicker]'
})
export class DatePickerDirective {

  private dateInput: any;
  private overlay: HTMLDivElement;

  @Input() dateMin: string = "";
  @Input() dateMax: string = "";

  constructor(private el: ElementRef, private renderer: Renderer2) {}

  @HostListener('focus') onFocus() {
    this.openDatePicker();
    this.addOverlay();
  }

  @HostListener('input', ['$event']) onInput(event: any) {
    const input = event.target as HTMLInputElement;
    const regex = /^\d{4}-\d{2}-\d{2}$/;
    if (!regex.test(input.value)) {
      input.value = input.value.slice(0, -1); // Elimina el último carácter si no coincide con el formato
    }
  }

  private openDatePicker() {
    const input = this.el.nativeElement;

    if (!this.dateInput) {
      this.dateInput = this.renderer.createElement('input');
      this.dateInput.type = 'date';
      this.dateInput.style.position = 'absolute';
      this.dateInput.style.opacity = '0';
      this.dateInput.style.width = '0';
      this.dateInput.style.height = '0';
      this.dateInput.style.zIndex = '-1';
      this.dateInput.style.top = "30%";
      this.dateInput.style.left = "41%";
      this.dateInput.style.transform = "translateX(-44%)";
      this.dateInput.min = this.dateMin;
      this.dateInput.max = this.dateMax;
      this.renderer.appendChild(document.body, this.dateInput);

      this.dateInput.addEventListener('change', () => {
        input.value = this.dateInput.value; // Set value to YYYY-MM-DD
        input.dispatchEvent(new Event('input'));
        this.removeOverlay();
      });

      this.dateInput.addEventListener('blur', () => {
        this.removeOverlay();
      });

    }

    

    this.dateInput.focus();
    this.dateInput.click();
    this.dateInput.showPicker()
    
  }

  private addOverlay() {
    this.overlay = this.renderer.createElement('div');
    this.overlay.style.position = 'fixed';
    this.overlay.style.top = '0';
    this.overlay.style.left = '0';
    this.overlay.style.width = '100%';
    this.overlay.style.height = '100%';
    this.overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
    this.overlay.style.zIndex = '10';
    this.renderer.appendChild(document.body, this.overlay);
  }

  private removeOverlay() {
    if (this.overlay) {
      this.renderer.removeChild(document.body, this.overlay);
      this.overlay = null;
    }
  }

}
