import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Response } from '../interfaces/response';
import { MethodsService } from './methods.service';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {

  constructor(
    private methods: MethodsService
  ) { }

  getThemeAll(): Observable<Response> {
    return this.methods.GET(`themes/getAll`);
  }

  getThemes(): Observable<Response> {
    return this.methods.GET(`themes`)
  }

  getThemeById(id): Observable<Response> {
    return this.methods.GET(`themes/${id}`);
  }

  saveTheme(params): Observable<Response> {
    return this.methods.POST(`themes`, params)
  }

  updateTheme(id, params): Observable<Response> {
    return this.methods.PUT(`themes/${id}`, params);
  }

  activateTheme(id): Observable<Response> {
    return this.methods.POST(`themes/activate/${id}`);
  }

  inactivateTheme(id): Observable<Response> {
    return this.methods.POST(`themes/inactivate/${id}`);
  }

  deleteTheme(id): Observable<Response> {
    return this.methods.DELETE(`themes/${id}`);
  }
}
