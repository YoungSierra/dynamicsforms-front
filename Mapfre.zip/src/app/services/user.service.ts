import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Response } from '../interfaces/response';
import { MethodsService } from './methods.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(
    private methods: MethodsService
  ) { }

  login(params): Observable<Response> {
    return this.methods.POST(`users/login`, params);
  }

  getUser(): Observable<Response> {
    return this.methods.GET(`users`);
  }

  saveUser(params): Observable<Response> {
    return this.methods.POST(`users`, params);
  }

  updateUser(id, params): Observable<Response> {
    return this.methods.PUT(`users/${id}`, params);
  }

  deleteUser(id): Observable<Response>{
    return this.methods.DELETE(`users/${id}`);
  }

  activateUser(id): Observable<Response> {
    return this.methods.POST(`users/activate/${id}`);
  }

  inactivateUser(id): Observable<Response> {
    return this.methods.POST(`users/inactivate/${id}`);
  }

  changePassword(idUser, params): Observable<Response>{
    return this.methods.POST(`users/updatepassword/${idUser}`, params)
  }

  rememberPassword(): Observable<Response>{
    return this.methods.POST(`users/rememberpassword`);
  }
}
