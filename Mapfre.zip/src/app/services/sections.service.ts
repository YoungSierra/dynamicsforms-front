import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Response } from '../interfaces/response';
import { MethodsService } from './methods.service';

@Injectable({
  providedIn: 'root'
})
export class SectionsService {

  constructor(
    private methods: MethodsService
  ) { }

  getAllSections(): Observable<Response> {
    return this.methods.GET(`sections/getAll`);
  }

  getSections(): Observable<Response> {
    return this.methods.GET(`sections`);
  }

  saveSection(params): Observable<Response> {
    return this.methods.POST(`sections`, params)
  }

  updateSection(id, params): Observable<Response> {
    return this.methods.PUT(`sections/${id}`, params);
  }

  deleteSection(id): Observable<Response> {
    return this.methods.DELETE(`sections/${id}`);
  }

  activateSection(id): Observable<Response> {
    return this.methods.POST(`sections/activate/${id}`);
  }

  inactiveSection(id): Observable<Response> {
    return this.methods.POST(`sections/inactivate/${id}`);
  }

}
