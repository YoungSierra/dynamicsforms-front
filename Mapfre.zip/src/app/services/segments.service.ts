import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Response } from '../interfaces/response';
import { MethodsService } from './methods.service';

@Injectable({
  providedIn: 'root'
})
export class SegmentsService {

  constructor(
    private methods: MethodsService
  ) { }

  getSegmentsAll(): Observable<Response> {
    return this.methods.GET(`segments/getAll`);
  }

  getSegments(): Observable<Response> {
    return this.methods.GET(`segments`)
  }

  getSegmentById(id): Observable<Response> {
    return this.methods.GET(`segments/${id}`);
  }

  saveSegments(params): Observable<Response> {
    return this.methods.POST(`segments`, params);
  }

  updateSegments(id, params): Observable<Response> {
    return this.methods.PUT(`segments/${id}`, params);
  }

  deleteSegment(id): Observable<Response> {
    return this.methods.DELETE(`segments/${id}`);
  }

  activateSegment(id): Observable<Response> {
    return this.methods.POST(`segments/activate/${id}`);
  }

  inactivateSegment(id): Observable<Response> {
    return this.methods.POST(`segments/inactivate/${id}`);
  }

  segmentDraw(id): Observable<Response> {
    return this.methods.GET(`segments/draw/${id}`);
  }

  /** Detalle */
  getDetailBySegmentId(id): Observable<Response> {
    return this.methods.GET(`segmentsdet/GetBySegmentId/${id}`);
  }

  saveSegmentDetail(params): Observable<Response> {
    return this.methods.POST(`segmentsdet`, params);
  }

  saveSegmentDetailTable(params): Observable<Response> {
    return this.methods.POST(`segmentsdettbl`, params)
  }

  activateSegmentDetailTable(id): Observable<Response> {
    return this.methods.POST(`segmentsdettbl/activate/${id}`);
  }

  inactivateSegmentDetailTable(id): Observable<Response> {
    return this.methods.POST(`segmentsdettbl/inactivate/${id}`);
  }

  deleteSegmentDetailTable(id): Observable<Response> {
    return this.methods.DELETE(`segmentsdettbl/${id}`);
  }

  getSegmentDetailById(id): Observable<Response> {
    return this.methods.GET(`segmentsdet/${id}`);
  }

  updateSegmentDetail(id, params): Observable<Response> {
    return this.methods.PUT(`segmentsdet/${id}`, params);
  }

  activateSegmentDetail(id): Observable<Response> {
    return this.methods.POST(`segmentsdet/activate/${id}`)
  }

  inactivateSegmentDetail(id): Observable<Response> {
    return this.methods.POST(`segmentsdet/inactivate/${id}`)
  }

  deleteSegmentDetail(id): Observable<Response> {
    return this.methods.DELETE(`segmentsdet/${id}`);
  }


  /** Detalle Opcionoes */
  getSegmentDetailOptionsAll(): Observable<Response> {
    return this.methods.GET(`segmentsdetopt/getAll`);
  }

  getSegmentDetailOptions(): Observable<Response> {
    return this.methods.GET(`segmentsdetopt`);
  }

  getSegmentDetailOptionById(id): Observable<Response> {
    return this.methods.GET(`segmentsdetopt/${id}`);
  }

  getSegmentDetailOptionsBySegmentDetailId(id): Observable<Response> {
    return this.methods.GET(`segmentsdetopt/getBySegmentsDetId/${id}`);
  }

  getSegmentDetailTable(): Observable<Response> {
    return this.methods.GET(`segmentsdettbl/getAll`);
  }

  saveSegmentDetailOption(params): Observable<Response> {
    return this.methods.POST(`segmentsdetopt`, params);
  }

  // updateSegmentDetailOption(id, params): Observable<Response>{
  //   return this.methods.PUT(``)
  // }

  activateSegmentDetailOption(id): Observable<Response> {
    return this.methods.POST(`segmentsdetopt/activate/${id}`);
  }

  inactivateSegmentDetailOption(id): Observable<Response> {
    return this.methods.POST(`segmentsdetopt/inactivate/${id}`)
  }

  deleteSegmentDetailOption(id): Observable<Response> {
    return this.methods.DELETE(`segmentsdetopt/${id}`);
  }

  //Table
  saveSegmentDetailOptionTable(params): Observable<Response> {
    return this.methods.POST(`segmentsdetopttbl`, params);
  }

  getSegmentDetailOptionTable(): Observable<Response> {
    return this.methods.GET(`segmentsdetopttbl/getAll`);
  }

  activateSegmentDetailOptionTable(id): Observable<Response> {
    return this.methods.POST(`segmentsdetopttbl/activate/${id}`);
  }

  inactivateSegmentDetailOptionTable(id): Observable<Response> {
    return this.methods.POST(`segmentsdetopttbl/inactivate/${id}`);
  }

  deleteSegmentDetailOptionTable(id): Observable<Response> {
    return this.methods.DELETE(`segmentsdetopttbl/${id}`);
  }



}
