import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Response } from '../interfaces/response';
import { MethodsService } from './methods.service';

@Injectable({
  providedIn: 'root'
})
export class ConditionTypesService {

  constructor(
    private methods: MethodsService
  ) { }

  getConditionTypes(): Observable<Response>{
    return this.methods.GET(`condtypes`);
  }
}
