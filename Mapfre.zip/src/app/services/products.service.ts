import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Response } from '../interfaces/response';
import { MethodsService } from './methods.service';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  constructor(
    private methods: MethodsService
  ) { }

  getProducts(): Observable<Response> {
    return this.methods.GET(`products`);
  }

  getProductsAll(): Observable<Response> {
    return this.methods.GET(`products/getAll`);
  }

  saveProduct(params): Observable<Response> {
    return this.methods.POST(`products`, params);
  }

  updateProduct(id, params): Observable<Response> {
    return this.methods.PUT(`products/${id}`, params);
  }

  deleteProduct(id): Observable<Response>{
    return this.methods.DELETE(`products/${id}`);
  }

  activateProduct(id): Observable<Response>{
    return this.methods.POST(`products/activate/${id}`)
  }

  inactivateProduct(id): Observable<Response>{
    return this.methods.POST(`products/inactivate/${id}`)
  }
}
