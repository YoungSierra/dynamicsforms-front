import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Response } from '../interfaces/response';
import { MethodsService } from './methods.service';

@Injectable({
  providedIn: 'root'
})
export class FormsService {

  constructor(
    private methods: MethodsService
  ) { }

  getFormsAll(): Observable<Response> {
    return this.methods.GET(`forms/getAll`);
  }

  getForms(): Observable<Response> {
    return this.methods.GET(`forms`)
  }

  saveForm(data): Observable<Response> {
    return this.methods.POST(`forms`, data);
  }

  updateForm(id, data): Observable<Response> {
    return this.methods.PUT(`forms/${id}`, data);
  }

  activateForm(id): Observable<Response> {
    return this.methods.POST(`forms/activate/${id}`);
  }

  inactivateForm(id): Observable<Response> {
    return this.methods.POST(`forms/inactivate/${id}`);
  }

  deleteForm(id): Observable<Response> {
    return this.methods.DELETE(`forms/${id}`);
  }

  linkFormIndependent(): Observable<Response> {
    return this.methods.GET(`links/form-independent-bytoken`);
  }

  /** Detail */

  saveFormDetail(data): Observable<Response> {
    return this.methods.POST(`formsdet`, data);
  }

  getDetailtById(id): Observable<Response> {
    return this.methods.GET(`formsdet/getByFormsId/${id}`);
  }

  activateFormDetail(id): Observable<Response> {
    return this.methods.POST(`formsdet/activate/${id}`);
  }

  inactivateFormDetail(id): Observable<Response> {
    return this.methods.POST(`formsdet/inactivate/${id}`);
  }

  deleteFormDetail(id): Observable<Response> {
    return this.methods.DELETE(`formsdet/${id}`);
  }

  changeOrderFormDetail(params: any): Observable<Response> {
    return this.methods.POST(`formsdet/changeOrderNum`, params)
  }
}
