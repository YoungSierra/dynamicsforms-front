import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Response } from '../interfaces/response';
import { MethodsService } from './methods.service';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(
    private methods: MethodsService
  ) { }

  getMenuProducts(): Observable<Response> {
    return this.methods.GET(`menuproducts`)
  }

  /** Generate link to Email */
  getQuestion(id: string): Observable<Response> {
    return this.methods.POST(`links/generate/${id}`);
  }

  // Get Form by token - email
  getFormByToken(): Observable<Response> {
    return this.methods.GET(`links/formbytoken`);
  }

  getFormDet(id: any): Observable<Response> {
    return this.methods.GET(`links/getformdet/${id}`);
  }

  getKeyOpt(id: any): Observable<Response> {
    return this.methods.GET(`links/getkeyopt/${id}`);
  }

  getSegment(id: any): Observable<Response> {
    return this.methods.GET(`links/getsegment/${id}`);
  }
}
