import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Response } from '../interfaces/response';
import { MethodsService } from './methods.service';

@Injectable({
  providedIn: 'root'
})
export class LogsService {

  constructor(
    private methods: MethodsService
  ) { }

  getLogs(params): Observable<Response> {
    return this.methods.GET(`logs`, params);
  }

  getLogById(id): Observable<Response> {
    return this.methods.GET(`logs/${id}`);
  }
}
