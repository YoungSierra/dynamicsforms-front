import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { map } from "rxjs/operators";
import { environment } from "../../environments/environment";
@Injectable({
    providedIn: 'root'
})
export class MethodsService {

    private ip: string = '';

    private readonly urlEndPoing: string = environment.apiEndPoint;
    private headerConfig = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json; charset=UTF-8',
            IP: this.ip,
            'Content-Length': '20166'
        })
    };

    constructor(
        private http: HttpClient
    ) {

    }

    POST(nameService: string, param: any = null): Observable<any> {
        return this.http.post<any>(`${this.urlEndPoing}${nameService}`, param, this.headerConfig)
            .pipe(map((res: any) => {
                return res;
            }))
    }

    GET(nameService: string, params: any = null): Observable<any> {
        return this.http.get<any>(`${this.urlEndPoing}${nameService}`, {
            headers: this.headerConfig.headers,
            params: params
        })
    }

    PUT(nameService: string, params: any = null): Observable<any> {
        return this.http.put(`${this.urlEndPoing}${nameService}`, params, this.headerConfig)
            .pipe(map((res: any) => {
                return res;
            }));
    }

    DELETE(nameService: string): Observable<any> {
        return this.http.delete(`${this.urlEndPoing}${nameService}`)
            .pipe(map((res: any) => {
                return res;
            }))
    }
}
