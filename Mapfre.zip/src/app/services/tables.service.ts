import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Response } from '../interfaces/response';
import { MethodsService } from './methods.service';

@Injectable({
  providedIn: 'root'
})
export class TablesService {

  constructor(
    private methods: MethodsService
  ) { }

  getTablesAll(): Observable<Response> {
    return this.methods.GET(`tables/getAll`)
  }

  getTables(): Observable<Response> {
    return this.methods.GET(`tables`);
  }

  getTableById(id: any): Observable<Response> {
    return this.methods.GET(`tables/${id}`);
  }

  saveTable(params): Observable<Response> {
    return this.methods.POST(`tables`, params);
  }

  updateTable(id, params): Observable<Response> {
    return this.methods.PUT(`tables/${id}`, params);
  }

  activateTable(id): Observable<Response> {
    return this.methods.POST(`tables/activate/${id}`)
  }

  inactivateTable(id): Observable<Response> {
    return this.methods.POST(`tables/inactivate/${id}`);
  }

  deleteTable(id): Observable<Response> {
    return this.methods.DELETE(`tables/${id}`);
  }

  // Detailt
  saveTableDetail(params): Observable<Response> {
    return this.methods.POST(`tablesdet`, params);
  }

  updateTableDetail(id, params): Observable<Response>{
    return this.methods.PUT(`tablesdet/${id}`, params)
  }

  getDetailByIdTable(id): Observable<Response> {
    return this.methods.GET(`tablesdet/GetByTablesId/${id}`);
  }

  activateTablesDetail(id): Observable<Response>{
    return this.methods.POST(`tablesdet/activate/${id}`)
  }

  inactivateTablesDetail(id): Observable<Response>{
    return this.methods.POST(`tablesdet/inactivate/${id}`)
  }

  deleteTableDetail(id): Observable<Response>{
    return this.methods.DELETE(`tablesdet/${id}`);
  }

  saveTableDetailImportTable(params): Observable<Response>{
    return this.methods.POST(`tablesdet/importTable`, params)
  }

}
