import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Response } from '../interfaces/response';
import { MethodsService } from './methods.service';

@Injectable({
  providedIn: 'root'
})
export class CategoriesService {

  constructor(
    private methods: MethodsService
  ) { }

  getAllCategories(): Observable<Response> {
    return this.methods.GET(`categories/getAll`)
  }

  saveCategories(params: any): Observable<Response> {
    return this.methods.POST(`categories`, params);
  }

  updateCategory(id, params): Observable<Response> {
    return this.methods.PUT(`categories/${id}`, params)
  }
  
  deleteCategory(id): Observable<Response>{
    return this.methods.DELETE(`categories/${id}`);
  }

  activateCategory(id): Observable<Response>{
    return this.methods.POST(`categories/activate/${id}`)
  }

  inactivateCategory(id): Observable<Response>{
    return this.methods.POST(`categories/inactivate/${id}`)
  }
}
