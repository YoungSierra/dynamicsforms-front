import { Injectable } from '@angular/core';
import Swal from 'sweetalert2';

@Injectable({
  providedIn: 'root'
})
export class AlertsService {

  constructor() { }

  success(text): void {
    Swal.fire({
      position: 'center',
      icon: 'success',
      title: text,
      showConfirmButton: false,
      timer: 1500
    })
  }

  error(text: string): void {
    Swal.fire({
      position: 'center',
      icon: 'error',
      title: text,
      showConfirmButton: false,
      timer: 5000
    })
  }

  questionDelete(title: string): Promise<boolean> {
    return new Promise(async (resolve) => {
      Swal.fire({
        title: title,
        text: "No podra revertir este proceso",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: "#D81E05",
        confirmButtonText: "Si",
        cancelButtonText: "No"
      }).then(res => {
        if (res.isConfirmed) {
          resolve(true);
        } else {
          resolve(false);
        }
      })
    })
  }

  questionConfirm(text: string): Promise<boolean> {
    return new Promise(async (resolve) => {
      Swal.fire({
        title: text,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: "#D81E05",
        confirmButtonText: "Si",
        cancelButtonText: "No"
      }).then(res => {
        if (res.isConfirmed) {
          resolve(true);
        } else {
          resolve(false);
        }
      })
    })
  }
}
