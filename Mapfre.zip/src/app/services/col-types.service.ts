import { Injectable } from '@angular/core';
import { MethodsService } from './methods.service';
import { Observable } from 'rxjs';
import { Response } from '../interfaces/response';

@Injectable({
  providedIn: 'root'
})
export class ColTypesService {

  constructor(
    private methods: MethodsService
  ) { }

  get(): Observable<Response> {
    return this.methods.GET(`coltypes`);
  }

  getAll(): Observable<Response> {
    return this.methods.GET(`coltypes/getAll`);
  }
}
