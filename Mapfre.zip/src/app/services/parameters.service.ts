import { Injectable } from '@angular/core';
import { MethodsService } from './methods.service';
import { Observable } from 'rxjs';
import { Response } from '../interfaces/response';

@Injectable({
  providedIn: 'root'
})
export class ParametersService {

  constructor(
    private methods: MethodsService
  ) { }

  getAll(): Observable<Response> {
    return this.methods.GET(`parameters/getAll`);
  }

  getById(id: string): Observable<Response> {
    return this.methods.GET(`/parameters/${id}`);
  }

  create(id: string, paramValue: string): Observable<Response> {
    return this.methods.POST(`parameters`, { id, paramValue });
  }

  update(id: string, paramValue: string): Observable<Response> {
    return this.methods.PUT(`parameters/${id}`, { paramValue });
  }

  delete(id: string): Observable<Response> {
    return this.methods.DELETE(`parameters/${id}`);
  }

}
