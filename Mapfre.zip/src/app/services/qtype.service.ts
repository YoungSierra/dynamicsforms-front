import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Response } from '../interfaces/response';
import { MethodsService } from './methods.service';

@Injectable({
  providedIn: 'root'
})
export class QTypeService {

  constructor(
    private methods: MethodsService
  ) { }

  get(): Observable<Response> {
    return this.methods.GET(`qtypes`);
  }

  getAll(): Observable<Response> {
    return this.methods.GET(`qtypes/getAll`)
  }

  saveQType(params): Observable<Response> {
    return this.methods.POST(`qtypes`, params);
  }
}
