export const environment = {
  production: true,
  apiEndPoint: "http://localhost:8080/"
};
