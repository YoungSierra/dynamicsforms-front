export const environment = {
  production: true,
  apiEndPoint: "https://10.223.241.110/"
};
