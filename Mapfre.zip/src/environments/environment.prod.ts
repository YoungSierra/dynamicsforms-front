export const environment = {
  production: true,
  apiEndPoint: "https://10.221.0.113:8080/"
};
