export const environment = {
  production: true,
  apiEndPoint: "https://formulariosvida.mapfre.com.ar/back/"
};
