export const environment = {
  production: true,
  apiEndPoint: "http://formulariosvida.mapfre.com.ar:8080/"
};
