export const environment = {
  production: true,
  apiEndPoint: "https://backformularios.mapfre.com.ar/"
};
