export const environment = {
  production: true,
  apiEndPoint: "http://10.221.0.113:8080/"
};
