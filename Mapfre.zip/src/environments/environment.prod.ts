export const environment = {
  production: true,
  apiEndPoint: "http://backformularios.mapfre.com.ar/"
};
