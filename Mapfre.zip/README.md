# Formularios Dinamicos

Projecto generado con [Angular CLI](https://github.com/angular/angular-cli) version 14.1.0.

## Development server

Ejecutar `npm start` para servidor de desarrollo. Automaticamente abrira la ruta `http://localhost:4400/`.


## Compilación

Ejecutar `ng build` para compilar el proyecto. El compilado estara guardado en carpeta `dist/`.

