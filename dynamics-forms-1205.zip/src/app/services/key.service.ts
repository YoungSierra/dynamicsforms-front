import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Response } from '../interfaces/response';
import { MethodsService } from './methods.service';

@Injectable({
  providedIn: 'root'
})
export class KeyService {

  constructor(
    private methods: MethodsService
  ) { }

  getKeysAll(): Observable<Response> {
    return this.methods.GET(`keys/getAll`)
  }

  getKeys(): Observable<Response> {
    return this.methods.GET(`keys`);
  }

  getKeyById(id): Observable<Response> {
    return this.methods.GET(`keys/${id}`);
  }

  saveKey(params): Observable<Response> {
    return this.methods.POST(`keys`, params);
  }

  updateKey(id, params): Observable<Response> {
    return this.methods.PUT(`keys/${id}`, params);
  }

  activateKey(id): Observable<Response> {
    return this.methods.POST(`keys/activate/${id}`);
  }

  inactivateKey(id): Observable<Response> {
    return this.methods.POST(`keys/inactivate/${id}`);
  }

  deleteKey(id): Observable<Response> {
    return this.methods.DELETE(`keys/${id}`);
  }

  /** KeyTypes */
  getKeyTypes(): Observable<Response> {
    return this.methods.GET(`ktypes`);
  }

  getKeyTypesAll(): Observable<Response> {
    return this.methods.GET(`ktypes/getAll`);
  }

  /** Detail */
  getKeyOptionsByKeyId(id): Observable<Response> {
    return this.methods.GET(`keysopt/GetByKeysId/${id}`);
  }

  saveKayOptions(params): Observable<Response> {
    return this.methods.POST(`keysopt`, params);
  }

  activateKeyOption(id): Observable<Response> {
    return this.methods.POST(`keysopt/activate/${id}`)
  }

  inactivateKeyOption(id): Observable<Response> {
    return this.methods.POST(`keysopt/inactivate/${id}`);
  }

  deleteKeyOption(id): Observable<Response> {
    return this.methods.DELETE(`keysopt/${id}`);
  }

  /** Detail Segment */
  saveKeyOptionSegment(params): Observable<Response> {
    return this.methods.POST(`keysoptseg`, params);
  }

  activateKeyOptionSegment(id): Observable<Response> {
    return this.methods.POST(`keysoptseg/activate/${id}`);
  }

}
