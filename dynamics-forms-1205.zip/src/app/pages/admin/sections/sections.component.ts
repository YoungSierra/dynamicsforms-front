import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ECodeStatus } from '../../../enums/ecode-status';
import { File } from '../../../interfaces/file';
import { AlertsService } from '../../../services/alerts.service';
import { ProgressBarService } from '../../../services/progress-bar.service';
import { SectionsService } from '../../../services/sections.service';

@Component({
  selector: 'app-sections',
  templateUrl: './sections.component.html',
  styleUrls: ['./sections.component.scss']
})
export class SectionsComponent implements OnInit {

  @ViewChild('modalSection') modalSection: ElementRef;
  listSections: any[] = [];
  idSectionEdit: string;
  formSection: FormGroup;
  image: File = {
    base64: '',
    name: '',
    base64Sort: ''
  };
  inputEmailValid: boolean = false;

  constructor(
    private sectionsService: SectionsService,
    private progressBar: ProgressBarService,
    private modalService: NgbModal,
    private fb: FormBuilder,
    private alertService: AlertsService
  ) { }

  ngOnInit(): void {

    this.LoadSections();

    this.formSection = this.fb.group({
      name: ['', Validators.required],
      pathimg: [''],
      ordernum: ['', Validators.required],
      email: ['', Validators.required]
    })

    this.formSection.valueChanges.subscribe(form => {
      if (form.email) {
        let items = form.email.split(';');
        for (let i = 0; i < items.length; i++) {
          const element = items[i];
          if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(element)) {
            this.inputEmailValid = true;
          } else {
            this.inputEmailValid = false;
          }
        }
      } else {
        this.inputEmailValid = false;
      }
    })
  }


  /** Methods */
  LoadSections(): void {
    this.progressBar.startLoading();
    this.sectionsService.getAllSections().subscribe(response => {
      this.progressBar.completeLoading();
      let { status, data } = response;
      if (status == ECodeStatus.Ok) {
        this.listSections = data;
      }
    })
  }

  SaveSection(data): void {
    this.progressBar.startLoading();
    this.sectionsService.saveSection(data).subscribe(response => {
      this.progressBar.completeLoading();
      let { status, data, message } = response;
      if (status == ECodeStatus.Ok) {
        this.LoadSections()
        this.modalService.dismissAll();
        this.alertService.success(message);
      } else {
        this.alertService.error(message)
      }
    }, ({ error }) => {
      this.alertService.error(error)
    })
  }

  UpdateSection(id: any, data: any): void {
    this.sectionsService.updateSection(id, data).subscribe(response => {
      let { status, data, message } = response;
      if (status == ECodeStatus.Ok) {
        this.LoadSections()
        this.modalService.dismissAll();
        this.alertService.success(message);
      } else {
        this.alertService.error(message)
      }
    }, ({ error }) => {
      this.alertService.error(error)
    })
  }

  DeleteSection(id): void {
    this.sectionsService.deleteSection(id).subscribe(response => {
      let { status, data, message } = response;
      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSections();
      }
    }, ({ error }) => {
      this.alertService.error(error)
    })
  }

  /** Events */
  onClickNewSection(): void {
    this.idSectionEdit = null;
    this.formSection.reset();
    this.image = { base64: null, name: null, base64Sort: null }
    this.modalService.open(this.modalSection, { centered: true });
  }

  onClickInactivate(item): void {
    this.sectionsService.inactiveSection(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSections();
      } else {
        this.alertService.error(message);
      }
    })
  }

  onClickActivate(item): void {
    this.sectionsService.activateSection(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadSections();
      } else {
        this.alertService.error(message);
      }
    })
  }

  onClickEditSection(item): void {
    this.idSectionEdit = item.id;
    if (item.pathimg) {
      this.image = {
        name: 'yes',
        base64: item.pathimg,
        base64Sort: null
      }
    }
    this.formSection.patchValue(item);
    this.modalService.open(this.modalSection, { centered: true });
  }

  onClickDeleteSection(item): void {
    this.alertService.questionDelete("Desea eliminar esta sección?").then(res => {
      if (res) {
        this.DeleteSection(item.id);
      }
    })
  }

  setImage(img: File): void {
    this.image = img;
    this.formSection.patchValue({ pathimg: img.base64Sort })
  }

  onClickSaveSection(): void {
    if (this.formSection.valid && this.inputEmailValid) {
      let data = this.formSection.value;

      if (this.idSectionEdit) {
        data.pathimg = this.image.base64Sort;
        this.UpdateSection(this.idSectionEdit, data);
      } else {
        this.SaveSection(data);
      }
    } else if (!this.inputEmailValid) {
      this.alertService.error("Emails invalidos");
    }
  }

  onClickDeleteImage(): void {
    this.image = {
      name: '',
      base64: '',
      base64Sort: ''
    }

    this.formSection.patchValue({ pathimg: '' });
  }

}
