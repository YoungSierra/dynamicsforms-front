import { Injectable } from '@angular/core';
import { jsPDF } from "jspdf";
import { MethodsService } from '../services/methods.service';
import { font } from './font';
import { fontBold } from './fontBold'

@Injectable({
  providedIn: 'root'
})
export class PdfService {

  constructor(
    private methods: MethodsService
  ) { }

  generateDoc(data: any, html: any, title: string, type: 'datauri' | 'datauristring'): Promise<any> {

    return new Promise((resolve, reject) => {
      const doc = new jsPDF({
        format: 'a4',
        unit: 'mm',
        precision: 1
      });

      var width = doc.internal.pageSize.getWidth();
      var height = doc.internal.pageSize.getHeight();
      console.log("Ancho", width);
      console.log("Alto", height);

      let positionVertical = 25;
      let sizeRow = 3;
      let sizeColum = 16;
      let column = 1;
      let row = 1;

      doc.addFileToVFS("DIN-Medium.ttf", font);
      doc.addFont("DIN-Medium.ttf", "DIN", "normal");

      doc.addFileToVFS("DIN-Bold.ttf", fontBold)
      doc.addFont("DIN-Bold.ttf", "DIN-B", "normal");

      doc.setFont("DIN");


      doc.setFillColor(216, 30, 5);
      // doc.rect(0, 0, 200, 25, "F");
      doc.roundedRect(-5, -5, 210, 30, 3, 3, "F");
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(23);
      doc.text(title.toLocaleUpperCase(), 198, 13, { align: 'right' });
      doc.setFontSize(13);
      // doc.text('DECLARACIÓN REDUCIDA', 198, 17, { align: 'right' });
      doc.setTextColor(0, 0, 0);

      doc.setFontSize(7);
      data.forEach(element => {
        if (element.type == 'key') {

        }

        if (element.type == 'segment') {

          let positionVertialInitial = (positionVertical - 6);

          doc.setFontSize(10);
          doc.text(element.s_title, sizeColum, positionVertical);
          console.log(element.s_title);
          if (element.s_subtitle) {
            positionVertical += sizeRow + 2;
            let countCol = doc.splitTextToSize(element.s_subtitle, sizeColum);
            let rows = doc.splitTextToSize(element.s_subtitle, 180);
            console.log(rows)
            doc.text(rows, sizeColum, positionVertical);
            positionVertical += (sizeRow * rows.length)
          }
          doc.setDrawColor(216, 30, 5);
          doc.setFillColor(216, 30, 5);
          doc.line(16, ((positionVertical + 2)), (16 * 12), ((positionVertical + 2)), "S")
          positionVertical += (sizeRow * 2);
          doc.setFontSize(7);
          doc.setTextColor(0, 0, 0);


          // Campos con data
          element.segments_det.forEach(seg_det => {

            if (seg_det.qt_name == 'TEXTO_CORTO' || seg_det.qt_name == 'FECHA' || seg_det.qt_name == 'TELEFONO' || seg_det.qt_name == 'EMAIL' || seg_det.qt_name == 'LISTA' || seg_det.qt_name == 'NUM_DECIMAL' || seg_det.qt_name == 'NUM_ENTERO') {

              if (seg_det.sd_colsize == 12) { column = 1; positionVertical += sizeRow }
              if (column >= 12) { column = 1; positionVertical += (sizeRow * 2 + (sizeRow / 2)) }
              // Buscar posicion horizonal
              doc.text(seg_det.sd_question + '-' + seg_det.sd_colsize, (sizeColum * column), positionVertical);
              doc.text(new String(seg_det.value).toString(), (sizeColum * column), (positionVertical + sizeRow));
              doc.line(sizeColum * column, (positionVertical + sizeRow + 1), (sizeColum * 12), (positionVertical + sizeRow + 1))

              column += parseInt(seg_det.sd_colsize);
            }

            if (seg_det.qt_name == 'TEXTO_LARGO') {
              if (seg_det.sd_colsize == 12) { column = 1; positionVertical += sizeRow }
              if (column >= 12) { column = 1; positionVertical += (sizeRow * 2 + (sizeRow / 2)) }
              let splitText = doc.splitTextToSize(seg_det.sd_question, 180);
              let count = doc.splitTextToSize(seg_det.sd_question, sizeColum);
              doc.text(splitText, (sizeColum * column), positionVertical);
              console.log(splitText);
              if (splitText.length >= 2) {
                positionVertical += sizeRow
              }
              let splitResponse = doc.splitTextToSize(seg_det.value, (sizeColum * seg_det.sd_colsize))
              doc.text(splitResponse, (sizeColum * column), positionVertical + sizeRow);
              if (splitResponse.length >= 2) {
                positionVertical += sizeRow * splitResponse.length
              } else {
                positionVertical += sizeRow
              }
              // doc.line(sizeColum, (positionVertical + 1), (sizeColum * 12), (positionVertical + 1));
              column += parseInt(seg_det.sd_colsize);
            }

            if (seg_det.qt_name == 'OPC_UNICA') {

              if (seg_det.sd_colsize == 12) { column = 1; positionVertical += (sizeRow * 2) + 1 }

              doc.text(seg_det.sd_question + '-' + seg_det.sd_colsize, (sizeColum * column), (positionVertical));
              let positionHorizontal = sizeColum + 1;
              seg_det.segments_det_opt.forEach((seg_det_opt, index) => {
                let label = new String(seg_det_opt.sdo_caption).toString();

                if (seg_det_opt.qt_name == 'CHECKBOX') {
                  console.log(seg_det_opt);
                  // if (seg_det_opt.sd_colsize == 12) { column = 1; positionVertical += (sizeRow * 2) + 1 }
                  let count = doc.splitTextToSize(seg_det_opt.sdo_caption, sizeColum)
                  let label = doc.splitTextToSize(seg_det_opt.sdo_caption, 180);

                  if (index == 0) {
                    doc.circle((sizeColum * (column) + 1), ((positionVertical + 2)), 1, ((seg_det.value == seg_det_opt.sdo_caption) ? 'FD' : 'S'));
                    doc.text(label, (sizeColum * (column) + 1) + 2, (positionVertical + 3))
                  } else {
                    doc.circle((sizeColum * (column) + 8), ((positionVertical + 2)), 1, ((seg_det.value == seg_det_opt.sdo_caption) ? 'FD' : 'S'));
                    doc.text(label, (sizeColum * (column) + 8) + 2, (positionVertical + 3))
                  }
                  if (seg_det_opt.sdo_caption.length > 4) {
                    column += count.length
                  }

                  if (count.length >= 11) {
                    column = 1; positionVertical += (sizeRow) + 1;
                  }
                }

                if (seg_det_opt.qt_name == 'TABLA') {
                  doc.text(label, (positionHorizontal - 1), (positionVertical + 3));

                  positionVertical += (sizeRow) + 1
                }
              });

              column += parseInt(seg_det.sd_colsize);
            }

            if (seg_det.qt_name == 'SINO_JUST_SI') {
              if (seg_det.sd_colsize == 12) { column = 1; positionVertical += (sizeRow * 2) + 1 }
              doc.setFillColor(216, 30, 5);
              doc.text(seg_det.sd_question + '-' + seg_det.sd_colsize, (sizeColum * column), (positionVertical));
              doc.circle((sizeColum * (column) + 1), ((positionVertical + 2)), 1, ((seg_det.value == 'SI') ? 'F' : 'S'));
              doc.text('SI', (sizeColum * (column) + 1) + 3, (positionVertical + 3))
              doc.circle((sizeColum * (column) + 8), ((positionVertical + 2)), 1, ((seg_det.value == 'NO') ? 'F' : 'S'));
              doc.text('NO', (sizeColum * (column) + 8) + 3, (positionVertical + 3))
              doc.line(sizeColum, (positionVertical + sizeRow + 1), (sizeColum * seg_det.sd_colsize), (positionVertical + sizeRow + 1))

              positionVertical += (sizeRow)
              column += parseInt(seg_det.sd_colsize);
            }

            if (seg_det.qt_name == 'SINO') {
              if (seg_det.sd_colsize == 12) { column = 1; positionVertical += (sizeRow * 2) + 1 }
              if (column >= 12) { column = 1; positionVertical += (sizeRow * 2 + (sizeRow / 2)) }
              let label = doc.splitTextToSize(seg_det.sd_question, 180);
              doc.text(label, (sizeColum * column), (positionVertical));
              if (label.length > 1) { positionVertical += (sizeRow * (label.length - 1)) }
              doc.setFillColor(216, 30, 5);
              doc.circle((sizeColum * (column) + 1), ((positionVertical + 2)), 1, ((seg_det.value == 'SI') ? 'FD' : 'S'));
              doc.text('SI', (sizeColum * (column) + 1) + 3, (positionVertical + 3))
              doc.circle((sizeColum * (column) + 8), ((positionVertical + 2)), 1, ((seg_det.value == 'NO') ? 'FD' : 'S'));
              doc.text('NO', (sizeColum * (column) + 8) + 3, (positionVertical + 3))
              doc.line(sizeColum, (positionVertical + sizeRow + 1), (sizeColum * seg_det.sd_colsize), (positionVertical + sizeRow + 1))

              column += parseInt(seg_det.sd_colsize);
            }

            if (seg_det.qt_name == 'CHECKBOX') {
              if (seg_det.sd_colsize == 12) { column = 1; positionVertical += (sizeRow * 2) + 1 }


              column += parseInt(seg_det.sd_colsize);

            }

            if (seg_det.qt_name == 'OPC_MULTI') {
              let positionHorizontal = 0
              seg_det.segments_det_opt.forEach((seg_det_opt, index) => {
                let label = new String(seg_det_opt.sdo_caption).toString();
                if (index == 0) {
                  positionHorizontal = (sizeColum * (column) + 1)
                } else {
                  positionHorizontal = positionHorizontal + ((label.length <= 12) ? 8 : 12 + ((label.length - 12) * 2))
                }
                doc.circle(positionHorizontal, ((positionVertical + 2)), 1, ((seg_det.value == seg_det_opt.sdo_caption) ? 'FD' : 'S'));
                doc.text(label + ' ' + label.length, (positionHorizontal + 2), (positionVertical + 3));

              });

              column += parseInt(seg_det.sd_colsize);
            }

            if (seg_det.qt_name == 'INFORMATIVA' || seg_det.qt_name == 'INFORMATIVA_N') {
              if (seg_det.sd_colsize == 12) { column = 1; positionVertical += (sizeRow * 2) + 1 }
              let splitText = doc.splitTextToSize(seg_det.sd_question, 180);
              doc.text(seg_det.sd_question, (sizeColum * column), positionVertical, { maxWidth: 180 });
              positionVertical += 2 * ((splitText.length == 1) ? 1 : splitText.length);
              column += parseInt(seg_det.sd_colsize);
              doc.setFont("DIN", "normal");
            }


            if (positionVertical >= 260) {
              doc.addPage();
              positionVertical = 10;
            }

          });

          // doc.roundedRect((sizeColum - 2), positionVertialInitial, 180, positionVertical, 3, 3);

        }

        positionVertical = positionVertical + (sizeRow * 5)

      });



      if (type == 'datauri') {
        let base64Pdf: any = doc.output("datauri");
        resolve(base64Pdf)
      }
      if (type == 'datauristring') {
        let base64Pdf: any = doc.output("datauristring");
        resolve(base64Pdf)
      }

    })

  }

  sendBase64(base64Pdf): void {
    let params = {
      token: localStorage.getItem('token'),
      pdfb64: base64Pdf
    }

    this.methods.POST(`links/finishform`, params).subscribe(response => {
      let { status } = response;
    });
  }

}
