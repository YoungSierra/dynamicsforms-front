import { Location } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { environment } from '../../../../environments/environment';
import { ECodeStatus } from '../../../enums/ecode-status';
import { ApiService } from '../../../services/api.service';

@Component({
  selector: 'app-survey',
  templateUrl: './survey.component.html',
  styleUrls: ['./survey.component.scss']
})
export class SurveyComponent implements OnInit {

  @ViewChild('modalEmail') modalEmail: any;

  products: any[] = [];
  email: string = '';
  idProduct: string = '';
  productsView: number = 1;
  titleSubProduct: string = '';
  productsDetail: any[] = [];
  emailIsValid: boolean = false;

  urlEndPoint: string = environment.apiEndPoint

  constructor(
    private modalService: NgbModal,
    private apiService: ApiService,
    private http: HttpClient,
    private location: Location
  ) { }

  ngOnInit(): void {
    this.LoadProducts();
  }

  /** Methods */

  LoadProducts(): void {
    this.apiService.getMenuProducts().subscribe(response => {
      let { status, data } = response;

      if (status == ECodeStatus.Ok) {
        this.products = data;
      }
    })
  }

  GenerateLink(idProduct: string, email: string): void {
    let headerConfig = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json; charset=UTF-8',
        'User-Email': email
      })
    };

    this.http.post(`${this.urlEndPoint}links/generate/${idProduct}`, {}, headerConfig).subscribe(response => {
      console.log(response);
      this.productsView = 4;
    })
  }

  /** Events */

  onClickShowModal(item: any): void {
    this.idProduct = item.p_id;
    this.modalService.open(this.modalEmail, { size: 'md', centered: true });
  }

  onClickGenerateLink(): void {
    let expresion = /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
    if (this.email.match(expresion)) {
      localStorage.setItem('email', this.email);
      this.GenerateLink(this.idProduct, this.email)
    } else {
      alert("Email no valido");
    }
  }

  onClickShowDetail(item: any): void {
    this.productsView = 2;
    this.titleSubProduct = item.s_name;
    this.productsDetail = item.products;
  }

  onClickProductView(item: any): void {
    this.idProduct = item.p_id;
    this.productsView = 3;
  }

  onClickBack(): void {
    this.productsView = 1;
  }

}
