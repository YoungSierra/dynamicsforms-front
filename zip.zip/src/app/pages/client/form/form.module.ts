import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormComponent } from './form.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NgProgressModule } from 'ngx-progressbar';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { ComponentsModule } from '../../../components/components.module';


const routes: Routes = [
  {
    path: '',
    component: FormComponent
  }
]

@NgModule({
  declarations: [
    FormComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    NgProgressModule,
    PdfViewerModule,
    ComponentsModule,
    RouterModule.forChild(routes)
  ]
})
export class FormModule { }
