import { trigger, state, style, animate, transition } from '@angular/animations';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ECodeStatus } from '../../../enums/ecode-status';
import { PdfService } from '../../../helpers/pdf.service';
import { FormDet } from '../../../interfaces/form-det';
import { ApiService } from '../../../services/api.service';
import { NgProgress } from 'ngx-progressbar';
import jwt_decode from "jwt-decode";

import { ProgressBarService } from '../../../services/progress-bar.service';
import { DomSanitizer } from '@angular/platform-browser';

import { jsPDF } from "jspdf";

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss'],
  animations: [
    trigger(
      'inOutAnimation',
      [
        transition(
          ':enter',
          [
            style({ height: 0, opacity: 0 }),
            animate('0.5s ease-out',
              style({ height: 62, opacity: 1 }))
          ]
        ),
        transition(
          ':leave',
          [
            style({ height: 62, opacity: 1 }),
            animate('0.5s ease-in',
              style({ height: 0, opacity: 0 }))
          ]
        )
      ]
    )
  ]
})
export class FormComponent implements OnInit {

  formName: string = '';
  formImage: string = '';
  formDet: FormDet[] = [];
  formQuestions: any[] = [];
  tab: any = null;
  indexParents: number = 1;
  formLoadingComplete: boolean = false;
  showCongratulations: boolean = false;
  showPreviewPdf: boolean = false;
  emailUser: string = '';
  pdfBase64: any;

  @ViewChild('container') container: ElementRef;
  @ViewChild('documentTemplate') documentTemplate: ElementRef;
  constructor(
    private route: ActivatedRoute,
    private api: ApiService,
    private router: Router,
    private pdfService: PdfService,
    private progress: NgProgress,
    private loading: ProgressBarService,
    private sanitazer: DomSanitizer
  ) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe((res: any) => {
      if (res.tk) {
        localStorage.setItem('token', res.tk);
        let dataUser: any = jwt_decode(res.tk);
        this.emailUser = dataUser.sub;
        // Prueba
        /*this.formQuestions = [
          {
            "type": "key",
            "k_id": "e75e44e8-2f0f-4a15-97bf-003abfc55fcf",
            "k_name": "SELECCION_TIPO_PERSONA",
            "k_question": "Seleccione el tipo de persona:",
            "kt_id": "b9946eb9-0c23-48c2-aea7-57e6b33fa220",
            "kt_name": "OPC_UNICA",
            "keys_opt": [
              {
                "ko_id": "86491806-4d82-46d1-8c50-a6f839c2c205",
                "ko_value": "JURIDICA",
                "ct_id": "028d9b26-d064-4249-81c9-5acb29958e2d",
                "ct_name": "IGUAL",
                "ct_condition": "="
              },
              {
                "ko_id": "da26b6d2-38a4-4714-90e2-ff1439740688",
                "ko_value": "FISICA",
                "ct_id": "028d9b26-d064-4249-81c9-5acb29958e2d",
                "ct_name": "IGUAL",
                "ct_condition": "="
              }
            ],
            "value": "86491806-4d82-46d1-8c50-a6f839c2c205",
            "invalid": false
          },
          {
            "type": "segment",
            "s_id": "e95f8970-a277-48ca-8c6d-dfa4dd19a8b6",
            "s_name": "TOMADOR_PERSONA_JURIDICA",
            "s_title": "TOMADOR PERSONA JURIDICA",
            "s_subtitle": "Asociaciones, Fideicomisos, Fundaciones, Utes, agrupaciones y otros entes",
            "s_finalnote": "",
            "segments_det": [
              {
                "sd_id": "4744d30d-7298-40d3-a2c0-a2bdac27276c",
                "sd_colsize": "8",
                "sd_question": "Denominación o razón social",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "55e4063e-879b-4fca-a934-e4480353d7a4",
                "qt_name": "TEXTO_CORTO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "f4801cce-b243-41e6-8e3c-0a245b5c7d33",
                "sd_colsize": "4",
                "sd_question": "Número de teléfono de la sede social",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "eb2ff6e2-40f5-4cd0-94e5-93b88ab8d6de",
                "qt_name": "TELEFONO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": 123123213,
                "invalid": false
              },
              {
                "sd_id": "8aadcf04-6158-47e5-8a90-224ed6455a21",
                "sd_colsize": "4",
                "sd_question": "Fecha de inscripción registral(IGJ)",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "bf785bcc-731d-4797-819e-dde9bfb6e117",
                "qt_name": "FECHA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "2023-03-07",
                "invalid": false
              },
              {
                "sd_id": "e89c65dd-ed5e-4453-86a4-4eff24004f10",
                "sd_colsize": "4",
                "sd_question": "N° de inscripción registral(IGJ)",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "55e4063e-879b-4fca-a934-e4480353d7a4",
                "qt_name": "TEXTO_CORTO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "e170a5f2-caa9-4f0b-8d41-acadaef15792",
                "sd_colsize": "4",
                "sd_question": "CUIT o CDI",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "55e4063e-879b-4fca-a934-e4480353d7a4",
                "qt_name": "TEXTO_CORTO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "bbd9a7d6-d4a5-49a5-abbb-12632c58a11d",
                "sd_colsize": "6",
                "sd_question": "Fecha de contrato o escritura constitución",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "bf785bcc-731d-4797-819e-dde9bfb6e117",
                "qt_name": "FECHA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "2023-03-07",
                "invalid": false
              },
              {
                "sd_id": "c5e5c6e8-ef6f-4c37-b47c-0360dc7b84e1",
                "sd_colsize": "6",
                "sd_question": "Domicilio legal",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "55e4063e-879b-4fca-a934-e4480353d7a4",
                "qt_name": "TEXTO_CORTO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "023255c2-4963-4dc6-9de3-dfe3b0a61bd6",
                "sd_colsize": "4",
                "sd_question": "Código postal",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "55e4063e-879b-4fca-a934-e4480353d7a4",
                "qt_name": "TEXTO_CORTO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "0c6b9da1-0f4e-49b9-bd46-a07da4fe8cc5",
                "sd_colsize": "8",
                "sd_question": "Localidad",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "4d39279a-bb33-482a-b19e-aaa9ef0c6163",
                "qt_name": "LISTA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [
                  {
                    "sdo_id": "e30175de-6c3a-4f6b-97cd-5fe44b21db0f",
                    "sdo_caption": "Abel (Buenos Aires)",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "84924fb8-6d9c-4fd2-ab9d-8adcc6693863",
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "6ba93d79-92d4-4628-b82d-0230f1554e3a",
                    "sdo_caption": "Adrogué",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "84924fb8-6d9c-4fd2-ab9d-8adcc6693863",
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "88930f67-8261-42df-a77a-cf8cc3ca020b",
                    "sdo_caption": "Aldo Bonzi",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "84924fb8-6d9c-4fd2-ab9d-8adcc6693863",
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  }
                ],
                "value": "Adrogué",
                "invalid": false
              },
              {
                "sd_id": "70bdc473-2159-4a32-8a1f-00da692f6d68",
                "sd_colsize": "6",
                "sd_question": "Actividad principal",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "55e4063e-879b-4fca-a934-e4480353d7a4",
                "qt_name": "TEXTO_CORTO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "0e7b6b9c-a271-4f58-8105-b076e6b4b658",
                "sd_colsize": "3",
                "sd_question": "Teléfono celular",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "eb2ff6e2-40f5-4cd0-94e5-93b88ab8d6de",
                "qt_name": "TELEFONO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": 231231321,
                "invalid": false
              },
              {
                "sd_id": "084b3dbb-9596-4361-af4c-568b8b8f2b0f",
                "sd_colsize": "3",
                "sd_question": "Teléfono comercial",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "eb2ff6e2-40f5-4cd0-94e5-93b88ab8d6de",
                "qt_name": "TELEFONO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": 123123132,
                "invalid": false
              },
              {
                "sd_id": "00224dc8-25e2-44d9-981b-2b22c58446f5",
                "sd_colsize": "12",
                "sd_question": "Desea recibir la documentación vía correo electrónico:",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "3e9f3654-3fed-4889-9fe9-277529c9ac24",
                "qt_name": "SINO_JUST_SI",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [
                  {
                    "sdo_id": "616717fe-7dee-4eff-a79c-2940d858c706",
                    "sdo_caption": "Email",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "e2bb2d88-e4f3-4683-8c5b-ac2e4211f6b5",
                    "qt_name": "EMAIL",
                    "segments_det_opt_tbl": []
                  }
                ],
                "value": "NO",
                "invalid": false
              },
              {
                "sd_id": "7d443396-39be-4fb3-9539-ad9709b57f71",
                "sd_colsize": "6",
                "sd_question": "Domicilio de Correspondencia",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "55e4063e-879b-4fca-a934-e4480353d7a4",
                "qt_name": "TEXTO_CORTO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "ca190626-d464-42a4-8a18-b33d2abc79a6",
                "sd_colsize": "3",
                "sd_question": "Código postal",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "55e4063e-879b-4fca-a934-e4480353d7a4",
                "qt_name": "TEXTO_CORTO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "107877fb-f73f-42ac-8ab7-af2a7d83cbb5",
                "sd_colsize": "3",
                "sd_question": "Localidad",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "4d39279a-bb33-482a-b19e-aaa9ef0c6163",
                "qt_name": "LISTA",
                "sd_tablesId": "ee587405-ab2a-46b0-bf1f-e5fd2a6e4d62",
                "segments_det_tbl": [],
                "segments_det_opt": [
                  {
                    "sdo_id": "931b3872-1467-4171-a910-7ee4f2f1d417",
                    "sdo_caption": "Abel (Buenos Aires)",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "5983952d-b6c4-4c9a-a6b8-2c74a363dcf7",
                    "sdo_caption": "Adrogué",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "396a15b8-5473-4d72-aadc-3a17fde5c586",
                    "sdo_caption": "Aldo Bonzi",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "b5e4d969-3312-4274-a947-11318b055303",
                    "sdo_caption": "Alfredo Demarchi",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "eaee88a1-681c-43f9-8f5e-fc06ffb3d6d5",
                    "sdo_caption": "Altamirano (Buenos Aires)",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "ad11e812-c15c-4ae4-bf57-199f9f01d63e",
                    "sdo_caption": "Amalia (Buenos Aires)",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "29121589-b2ec-4b19-8340-56c2cad242c7",
                    "sdo_caption": "Antonio Carboni",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "97721546-06ef-4225-a8f3-85b67c40c3a5",
                    "sdo_caption": "Arturo Vatteone",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  }
                ],
                "value": "Aldo Bonzi",
                "invalid": false
              },
              {
                "sd_id": "9970e137-58ea-40c0-9c25-39b314a633d6",
                "sd_colsize": "4",
                "sd_question": "Provincia",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "4d39279a-bb33-482a-b19e-aaa9ef0c6163",
                "qt_name": "LISTA",
                "sd_tablesId": "a02d41d8-e1a3-4649-adeb-39cc23765a00",
                "segments_det_tbl": [],
                "segments_det_opt": [
                  {
                    "sdo_id": "c2199a35-5b46-482c-8568-651aca05cd12",
                    "sdo_caption": "Buenos Aires",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "a7874833-ed0a-46c7-a8da-d15243a94643",
                    "sdo_caption": "Catamarca",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "8ebffdc8-2129-499d-b4bf-b31d382724f0",
                    "sdo_caption": "Chaco",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "8d323455-fbcd-4cc4-ae30-145507fe8fd2",
                    "sdo_caption": "Chubut",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "e8717d45-a237-4989-9229-4c72c82c295e",
                    "sdo_caption": "Córdoba",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "a4356f4d-f9af-4dc3-b903-00b1b6bbea34",
                    "sdo_caption": "Corrientes",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "b40d0983-c46a-4bbc-81e2-48e864209ece",
                    "sdo_caption": "Entre Ríos",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "8d9a16cb-2660-4b08-a9ec-098541b527b2",
                    "sdo_caption": "Formosa",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "cb220d6d-70cf-42c3-8c7d-d04285ae16a9",
                    "sdo_caption": "Jujuy",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "6fe9980f-73e0-47f9-afff-8f5baf8b4b80",
                    "sdo_caption": "La Pampa",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "57d225f3-940d-4497-a396-a622b02966f6",
                    "sdo_caption": "La Rioja",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "1ee4f050-374d-4a0f-9772-342b6a9e9709",
                    "sdo_caption": "Mendoza",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  }
                ],
                "value": "Formosa",
                "invalid": false
              },
              {
                "sd_id": "6e96d63e-be8b-49d3-8131-3f62e89f332b",
                "sd_colsize": "8",
                "sd_question": "Observaciones",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "abf8e545-d4f4-4774-a589-67fe924f0cd3",
                "qt_name": "TEXTO_LARGO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              }
            ]
          },
          {
            "type": "segment",
            "s_id": "fd150541-8d58-49ed-8a19-1817978c3503",
            "s_name": "PROPUESTO_ASEGURADO",
            "s_title": "PROPUESTO ASEGURADO",
            "s_subtitle": "",
            "s_finalnote": "",
            "segments_det": [
              {
                "sd_id": "70234316-66fc-40fc-9224-2b647bd32d07",
                "sd_colsize": "6",
                "sd_question": "Apellido",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "55e4063e-879b-4fca-a934-e4480353d7a4",
                "qt_name": "TEXTO_CORTO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "17444e0b-1def-4bee-839c-ee9a03e07f36",
                "sd_colsize": "6",
                "sd_question": "Nombres",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "55e4063e-879b-4fca-a934-e4480353d7a4",
                "qt_name": "TEXTO_CORTO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "73dd754d-fd30-4c0d-a279-25ba45d20468",
                "sd_colsize": "2",
                "sd_question": "Fecha de Nacimiento",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "bf785bcc-731d-4797-819e-dde9bfb6e117",
                "qt_name": "FECHA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "invalid": false,
                "value": "2023-03-07"
              },
              {
                "sd_id": "7ba3ffd5-3403-4b57-b7b3-d3cab67cee2f",
                "sd_colsize": "8",
                "sd_question": "Domicilio",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "55e4063e-879b-4fca-a934-e4480353d7a4",
                "qt_name": "TEXTO_CORTO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "70b42e8f-fe48-49ff-b89b-64b295c7d0f3",
                "sd_colsize": "2",
                "sd_question": "Código Postal",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "55e4063e-879b-4fca-a934-e4480353d7a4",
                "qt_name": "TEXTO_CORTO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "4b12f10f-3758-4cfa-826c-548528c17e3a",
                "sd_colsize": "3",
                "sd_question": "Localidad",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "4d39279a-bb33-482a-b19e-aaa9ef0c6163",
                "qt_name": "LISTA",
                "sd_tablesId": "ee587405-ab2a-46b0-bf1f-e5fd2a6e4d62",
                "segments_det_tbl": [],
                "segments_det_opt": [
                  {
                    "sdo_id": "931b3872-1467-4171-a910-7ee4f2f1d417",
                    "sdo_caption": "Abel (Buenos Aires)",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "5983952d-b6c4-4c9a-a6b8-2c74a363dcf7",
                    "sdo_caption": "Adrogué",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "396a15b8-5473-4d72-aadc-3a17fde5c586",
                    "sdo_caption": "Aldo Bonzi",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "b5e4d969-3312-4274-a947-11318b055303",
                    "sdo_caption": "Alfredo Demarchi",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "eaee88a1-681c-43f9-8f5e-fc06ffb3d6d5",
                    "sdo_caption": "Altamirano (Buenos Aires)",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "ad11e812-c15c-4ae4-bf57-199f9f01d63e",
                    "sdo_caption": "Amalia (Buenos Aires)",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "29121589-b2ec-4b19-8340-56c2cad242c7",
                    "sdo_caption": "Antonio Carboni",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "97721546-06ef-4225-a8f3-85b67c40c3a5",
                    "sdo_caption": "Arturo Vatteone",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  }
                ],
                "value": "Abel (Buenos Aires)",
                "invalid": false
              },
              {
                "sd_id": "fbac4e6f-82bd-45fe-af7b-b445068299cc",
                "sd_colsize": "3",
                "sd_question": "Provincia",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "4d39279a-bb33-482a-b19e-aaa9ef0c6163",
                "qt_name": "LISTA",
                "sd_tablesId": "a02d41d8-e1a3-4649-adeb-39cc23765a00",
                "segments_det_tbl": [],
                "segments_det_opt": [
                  {
                    "sdo_id": "c2199a35-5b46-482c-8568-651aca05cd12",
                    "sdo_caption": "Buenos Aires",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "a7874833-ed0a-46c7-a8da-d15243a94643",
                    "sdo_caption": "Catamarca",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "8ebffdc8-2129-499d-b4bf-b31d382724f0",
                    "sdo_caption": "Chaco",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "8d323455-fbcd-4cc4-ae30-145507fe8fd2",
                    "sdo_caption": "Chubut",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "e8717d45-a237-4989-9229-4c72c82c295e",
                    "sdo_caption": "Córdoba",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "a4356f4d-f9af-4dc3-b903-00b1b6bbea34",
                    "sdo_caption": "Corrientes",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "b40d0983-c46a-4bbc-81e2-48e864209ece",
                    "sdo_caption": "Entre Ríos",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "8d9a16cb-2660-4b08-a9ec-098541b527b2",
                    "sdo_caption": "Formosa",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "cb220d6d-70cf-42c3-8c7d-d04285ae16a9",
                    "sdo_caption": "Jujuy",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "6fe9980f-73e0-47f9-afff-8f5baf8b4b80",
                    "sdo_caption": "La Pampa",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "57d225f3-940d-4497-a396-a622b02966f6",
                    "sdo_caption": "La Rioja",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "1ee4f050-374d-4a0f-9772-342b6a9e9709",
                    "sdo_caption": "Mendoza",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": null,
                    "qt_name": "INFORMATIVA",
                    "segments_det_opt_tbl": []
                  }
                ],
                "value": "Chubut",
                "invalid": false
              },
              {
                "sd_id": "eb1e7084-287a-4d34-9ec4-5bc44dc65b7a",
                "sd_colsize": "2",
                "sd_question": "Teléfono Particular",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "eb2ff6e2-40f5-4cd0-94e5-93b88ab8d6de",
                "qt_name": "TELEFONO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": 23123123,
                "invalid": false
              },
              {
                "sd_id": "f2a0259f-b55b-44a5-a62b-6078dff7f9c8",
                "sd_colsize": "2",
                "sd_question": "Teléfono Comercial",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "eb2ff6e2-40f5-4cd0-94e5-93b88ab8d6de",
                "qt_name": "TELEFONO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": 1231244,
                "invalid": false
              },
              {
                "sd_id": "0739f70d-18b7-400e-9049-c3d865287363",
                "sd_colsize": "2",
                "sd_question": "Sexo",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "2693e982-1242-443f-9b97-adf59bc07b23",
                "qt_name": "OPC_UNICA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [
                  {
                    "sdo_id": "030a7251-e533-48f1-a006-9074d170a16d",
                    "sdo_caption": "M",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "b1bbcb2d-9478-4d3b-a660-38e735de6d07",
                    "qt_name": "CHECKBOX",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "fea63584-2fff-4e75-adbe-b6efee3f8443",
                    "sdo_caption": "F",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "b1bbcb2d-9478-4d3b-a660-38e735de6d07",
                    "qt_name": "CHECKBOX",
                    "segments_det_opt_tbl": []
                  }
                ],
                "value": "F",
                "invalid": false
              },
              {
                "sd_id": "c26c3704-156f-46f7-969f-6ff7b5d74abf",
                "sd_colsize": "4",
                "sd_question": "Nacionalidad",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "abf8e545-d4f4-4774-a589-67fe924f0cd3",
                "qt_name": "TEXTO_LARGO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "781c6dcd-f974-40cf-bee5-f94d5de4045e",
                "sd_colsize": "4",
                "sd_question": "Vínculo con el Tomador",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "abf8e545-d4f4-4774-a589-67fe924f0cd3",
                "qt_name": "TEXTO_LARGO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "d96eed2f-b9d6-4b3d-84d2-44b2f73dd9e7",
                "sd_colsize": "12",
                "sd_question": "Condición ante IVA :",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "2693e982-1242-443f-9b97-adf59bc07b23",
                "qt_name": "OPC_UNICA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [
                  {
                    "sdo_id": "96469377-fc63-444d-8cb9-dc8f315f79b1",
                    "sdo_caption": "Resp. Inscripto",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "b1bbcb2d-9478-4d3b-a660-38e735de6d07",
                    "qt_name": "CHECKBOX",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "43157e55-e2a2-46cf-a1f1-e4f261f451f1",
                    "sdo_caption": "Grandes Contribuyentes",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "b1bbcb2d-9478-4d3b-a660-38e735de6d07",
                    "qt_name": "CHECKBOX",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "db072c34-305a-4ccb-9a77-bf9e303c4686",
                    "sdo_caption": "Resp. No Inscripto",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "b1bbcb2d-9478-4d3b-a660-38e735de6d07",
                    "qt_name": "CHECKBOX",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "e11a2014-104e-4108-9cf8-a38171b9e4db",
                    "sdo_caption": "Exento",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "b1bbcb2d-9478-4d3b-a660-38e735de6d07",
                    "qt_name": "CHECKBOX",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "9184c6cf-8e15-44d6-a4a7-1c2eabb96fcb",
                    "sdo_caption": "Cons. Final",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "b1bbcb2d-9478-4d3b-a660-38e735de6d07",
                    "qt_name": "CHECKBOX",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "40150dbb-f884-4def-bf90-52c322a55e7b",
                    "sdo_caption": "Tierra del Fuego",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "b1bbcb2d-9478-4d3b-a660-38e735de6d07",
                    "qt_name": "CHECKBOX",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "52220d52-3de3-43ab-8498-1064880858ad",
                    "sdo_caption": "Monotributo",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "b1bbcb2d-9478-4d3b-a660-38e735de6d07",
                    "qt_name": "CHECKBOX",
                    "segments_det_opt_tbl": []
                  }
                ],
                "value": "Resp. No Inscripto",
                "invalid": false
              },
              {
                "sd_id": "45504724-7db2-4a6b-ba1e-e74d9ab7985d",
                "sd_colsize": "12",
                "sd_question": "Estado Civil:",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "2693e982-1242-443f-9b97-adf59bc07b23",
                "qt_name": "OPC_UNICA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [
                  {
                    "sdo_id": "2bfa21e9-35be-42f3-910e-5afe6168b049",
                    "sdo_caption": "Casado/a",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "b1bbcb2d-9478-4d3b-a660-38e735de6d07",
                    "qt_name": "CHECKBOX",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "59b05137-f0c1-4cff-90b7-690adb7e6adf",
                    "sdo_caption": "Concubino/a",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "b1bbcb2d-9478-4d3b-a660-38e735de6d07",
                    "qt_name": "CHECKBOX",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "44af7059-5bfb-4c1a-a573-f7c977c24a77",
                    "sdo_caption": "Soltero/a",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "b1bbcb2d-9478-4d3b-a660-38e735de6d07",
                    "qt_name": "CHECKBOX",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "3e120250-7ece-48cc-ad80-58acaf7b3007",
                    "sdo_caption": "Viudo/a",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "b1bbcb2d-9478-4d3b-a660-38e735de6d07",
                    "qt_name": "CHECKBOX",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "8e314ed9-d8df-448e-b5d0-720d0d8fee68",
                    "sdo_caption": "Divorciado/a",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "b1bbcb2d-9478-4d3b-a660-38e735de6d07",
                    "qt_name": "CHECKBOX",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "3a41d294-0581-4a0e-bf69-2306d88bd2a8",
                    "sdo_caption": "Separado/a",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "b1bbcb2d-9478-4d3b-a660-38e735de6d07",
                    "qt_name": "CHECKBOX",
                    "segments_det_opt_tbl": []
                  }
                ],
                "value": "Viudo/a",
                "invalid": false
              }
            ]
          },
          {
            "type": "segment",
            "s_id": "2d862f14-4817-40c1-9fec-80c3e6e34c6a",
            "s_name": "BENEFICIARIOS",
            "s_title": "BENEFICIARIOS",
            "s_subtitle": "",
            "s_finalnote": "",
            "segments_det": [
              {
                "sd_id": "ed491097-648a-4bf1-bd7a-723f6ec8ad7f",
                "sd_colsize": "12",
                "sd_question": "Elegir solo una de las opciones:",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "2693e982-1242-443f-9b97-adf59bc07b23",
                "qt_name": "OPC_UNICA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [
                  {
                    "sdo_id": "48d89581-ca42-4637-9235-14469b90b5ad",
                    "sdo_caption": "Cónyuge del Asegurado, en su defecto hijos del Asegurado, en su defecto padres del Asegurado, en su defecto herederos legales del Asegurado, si viven.",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "b1bbcb2d-9478-4d3b-a660-38e735de6d07",
                    "qt_name": "CHECKBOX",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "b39d392e-c819-446b-9c01-d0a5222d99e8",
                    "sdo_caption": "Herederos legales.",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "b1bbcb2d-9478-4d3b-a660-38e735de6d07",
                    "qt_name": "CHECKBOX",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "4abb287a-7d9a-4630-a48b-339381748335",
                    "sdo_caption": "Ninguna de las anteriores, cumplimentar el siguiente detalle.",
                    "sdo_body": null,
                    "sdo_tabnumcol": "4",
                    "sdo_tabnumrow": "5",
                    "qt_id": "2d4f0bbc-23ac-458a-8e82-b7d913982461",
                    "qt_name": "TABLA",
                    "segments_det_opt_tbl": [
                      {
                        "sdot_id": "84a1dd58-6114-4922-9e22-7da424ffe78f",
                        "sdot_colname": "Nombre y Apellido",
                        "sdot_colsize": "6",
                        "ct_id": "a7653955-7410-461d-b6d2-d7a5e14a02e2",
                        "ct_name": "TEXTO_CORTO"
                      },
                      {
                        "sdot_id": "545b14dc-7249-4c6e-8bce-ec468cf8878f",
                        "sdot_colname": "Parentesco",
                        "sdot_colsize": "2",
                        "ct_id": "a7653955-7410-461d-b6d2-d7a5e14a02e2",
                        "ct_name": "TEXTO_CORTO"
                      },
                      {
                        "sdot_id": "cf63e9c5-517a-49fd-94cd-6b27c4f94ed5",
                        "sdot_colname": "%",
                        "sdot_colsize": "2",
                        "ct_id": "f6a4fe8a-033a-466f-be26-46bc36198904",
                        "ct_name": "NUM_ENTERO"
                      },
                      {
                        "sdot_id": "6f887118-1d28-416e-81f0-0a87ca1ad420",
                        "sdot_colname": "D.N.I.",
                        "sdot_colsize": "2",
                        "ct_id": "a7653955-7410-461d-b6d2-d7a5e14a02e2",
                        "ct_name": "TEXTO_CORTO"
                      }
                    ]
                  }
                ],
                "value": "Cónyuge del Asegurado, en su defecto hijos del Asegurado, en su defecto padres del Asegurado, en su defecto herederos legales del Asegurado, si viven.",
                "invalid": false
              }
            ]
          },
          {
            "type": "segment",
            "s_id": "c0b420a1-ca10-453c-8e42-112fa5c2b71a",
            "s_name": "ACTIVIDAD_LABORAL",
            "s_title": "ACTIVIDAD LABORAL",
            "s_subtitle": "",
            "s_finalnote": "",
            "segments_det": [
              {
                "sd_id": "4da895a8-b397-4108-b6e7-540f3b9ea1ac",
                "sd_colsize": "12",
                "sd_question": "Actividades, tareas diarias y naturaleza del negocio, indique detalladamente las que desarrolla en su lugar de trabajo el PROPUESTO ASEGURADO. (1)",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "abf8e545-d4f4-4774-a589-67fe924f0cd3",
                "qt_name": "TEXTO_LARGO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "0d1fb1c0-429b-450d-a51d-986e3588e1c9",
                "sd_colsize": "12",
                "sd_question": "Indicar ingresos anuales (2)",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "abf8e545-d4f4-4774-a589-67fe924f0cd3",
                "qt_name": "TEXTO_LARGO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              }
            ]
          },
          {
            "type": "key",
            "k_id": "2bb27052-83af-445d-9ac9-34158f9241e8",
            "k_name": "COBERTURA_VIDA_PLUS_RENOVABLE",
            "k_question": "Capital Principal en caso de Fallecimiento $",
            "kt_id": "984eec5c-ef3c-4be0-8cc5-f385403ca50f",
            "kt_name": "NUM_ENTERO",
            "keys_opt": [
              {
                "ko_id": "aa1d2e0d-8f08-4897-8dc6-cf5f336c5ba7",
                "ko_value": "1000000",
                "ct_id": "d9c0a16d-99d6-48d3-ab18-d47ccff51992",
                "ct_name": "MENOR IGUAL",
                "ct_condition": "<="
              },
              {
                "ko_id": "39cb4351-8d00-42f7-bfb9-74443f1597db",
                "ko_value": "1000000",
                "ct_id": "0fd79c75-98a0-47dd-b3a4-248a7ffd0a15",
                "ct_name": "MAYOR",
                "ct_condition": ">"
              }
            ],
            "value": 800000,
            "invalid": false
          },
          {
            "type": "segment",
            "s_id": "daec9e24-b798-4f2a-b437-2338ad1d4e23",
            "s_name": "COBERTURAS_ADICIONALES",
            "s_title": "COBERTURAS ADICIONALES",
            "s_subtitle": "",
            "s_finalnote": "",
            "segments_det": [
              {
                "sd_id": "c33d5459-8288-4d9a-9a37-6533cc2b7291",
                "sd_colsize": "12",
                "sd_question": "Solicita cobertura adicional en caso de Invalidez Absoluta y Permanente (IAP)?",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "8d3d1a37-91f5-4a95-9212-d344dd904a13",
                "qt_name": "SINO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "0",
                "invalid": false
              },
              {
                "sd_id": "382e264e-eaff-43e0-95aa-48ceed4312c4",
                "sd_colsize": "12",
                "sd_question": "Solicita cobertura adicional en caso de Fallecimiento Accidental (FA)?",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "8d3d1a37-91f5-4a95-9212-d344dd904a13",
                "qt_name": "SINO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "0",
                "invalid": false
              },
              {
                "sd_id": "4e9fe59e-1902-4196-a141-dd43488a204d",
                "sd_colsize": "12",
                "sd_question": "Las sumas a asegurar para las coberturas de IAP y FA equivalen al capital en caso de fallecimiento.",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "84924fb8-6d9c-4fd2-ab9d-8adcc6693863",
                "qt_name": "INFORMATIVA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "invalid": false
              }
            ]
          },
          {
            "type": "segment",
            "s_id": "f2907d8e-f3d5-40de-a6bb-1954411150f9",
            "s_name": "INFORMACION_GENERAL_1_2",
            "s_title": "INFORMACIÓN GENERAL",
            "s_subtitle": "Favor responder las siguientes preguntas:",
            "s_finalnote": "",
            "segments_det": [
              {
                "sd_id": "23c71b17-a812-4c8d-bc51-a24f52187be4",
                "sd_colsize": "12",
                "sd_question": "1) Indique que deportes practica y describa sus hobbies y si alguno lo hace en competición.",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "3e9f3654-3fed-4889-9fe9-277529c9ac24",
                "qt_name": "SINO_JUST_SI",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [
                  {
                    "sdo_id": "d88042a7-12e5-4a3b-afb4-d488327fb7cb",
                    "sdo_caption": "",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "abf8e545-d4f4-4774-a589-67fe924f0cd3",
                    "qt_name": "TEXTO_LARGO",
                    "segments_det_opt_tbl": []
                  }
                ],
                "value": "NO",
                "invalid": false
              },
              {
                "sd_id": "78954571-9cb4-45f7-aabe-828de28baf49",
                "sd_colsize": "12",
                "sd_question": "2) Utiliza motocicletas de más de 125 cc? Si responde afirmativamente indique cual es la finalidad del uso.",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "3e9f3654-3fed-4889-9fe9-277529c9ac24",
                "qt_name": "SINO_JUST_SI",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [
                  {
                    "sdo_id": "a1f08d38-6aeb-4f0d-b20e-1ed45697681a",
                    "sdo_caption": "",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "abf8e545-d4f4-4774-a589-67fe924f0cd3",
                    "qt_name": "TEXTO_LARGO",
                    "segments_det_opt_tbl": []
                  }
                ],
                "value": "NO",
                "invalid": false
              }
            ]
          },
          {
            "type": "segment",
            "s_id": "a1e60af4-f654-4a10-84e5-e4bb68ef4941",
            "s_name": "DECLARACION_JURADA_ANTECEDENTES_MEDICOS_TIPO1_P1",
            "s_title": "DECLARACIÓN JURADA DE ANTECEDENTES MÉDICOS",
            "s_subtitle": "",
            "s_finalnote": "",
            "segments_det": [
              {
                "sd_id": "e1b11b0f-22f4-4ee6-a870-987e54000832",
                "sd_colsize": "12",
                "sd_question": "1) Indicar fecha y motivo de la última consulta médica realizada",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "abf8e545-d4f4-4774-a589-67fe924f0cd3",
                "qt_name": "TEXTO_LARGO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "0299ce8b-3d9e-4b96-896f-06993ca87db2",
                "sd_colsize": "12",
                "sd_question": "2) Nombre de su médico personal, Obra Social y/o Medicina Prepaga",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "abf8e545-d4f4-4774-a589-67fe924f0cd3",
                "qt_name": "TEXTO_LARGO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "cde4b273-4d1f-4583-84bc-e8e157477258",
                "sd_colsize": "12",
                "sd_question": "3) Fuma actualmente o ha fumado en los últimos 12 meses?",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "3e9f3654-3fed-4889-9fe9-277529c9ac24",
                "qt_name": "SINO_JUST_SI",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [
                  {
                    "sdo_id": "deb215d4-d14f-4640-ad01-d645b918e67c",
                    "sdo_caption": "Si su respuesta es SI indicar cantidad diaria",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "55e4063e-879b-4fca-a934-e4480353d7a4",
                    "qt_name": "TEXTO_CORTO",
                    "segments_det_opt_tbl": []
                  }
                ],
                "value": "NO",
                "invalid": false
              },
              {
                "sd_id": "6b409cce-a4d2-4417-810e-8cafcbd04508",
                "sd_colsize": "12",
                "sd_question": "Si ha dejado de fumar, indique desde cuándo y si ha sido por prescripción medica.",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "abf8e545-d4f4-4774-a589-67fe924f0cd3",
                "qt_name": "TEXTO_LARGO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "96f4c1d9-b1b5-4260-ab13-629162a8feee",
                "sd_colsize": "12",
                "sd_question": "4) Es zurdo, diestro o ambidiestro?",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "2693e982-1242-443f-9b97-adf59bc07b23",
                "qt_name": "OPC_UNICA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [
                  {
                    "sdo_id": "049b8eec-4362-42e9-a9c6-66f3aa707151",
                    "sdo_caption": "Zurdo",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "b1bbcb2d-9478-4d3b-a660-38e735de6d07",
                    "qt_name": "CHECKBOX",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "64c47fdd-be2e-495e-b789-f3578467198a",
                    "sdo_caption": "Diestro",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "b1bbcb2d-9478-4d3b-a660-38e735de6d07",
                    "qt_name": "CHECKBOX",
                    "segments_det_opt_tbl": []
                  },
                  {
                    "sdo_id": "c47e321d-3fc0-474b-a21d-3128828911cc",
                    "sdo_caption": "Ambidiestro",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "b1bbcb2d-9478-4d3b-a660-38e735de6d07",
                    "qt_name": "CHECKBOX",
                    "segments_det_opt_tbl": []
                  }
                ],
                "value": "Ambidiestro",
                "invalid": false
              },
              {
                "sd_id": "32123f19-0899-4046-b5da-809aeed4935f",
                "sd_colsize": "4",
                "sd_question": "5.a) Peso",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "9de375e1-8fd8-4d44-9870-aff06002e257",
                "qt_name": "NUM_DECIMAL",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": 123,
                "invalid": false
              },
              {
                "sd_id": "390eb14d-2e4f-4a52-9559-37e8c29689b8",
                "sd_colsize": "4",
                "sd_question": "5.b) Estatura",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "9de375e1-8fd8-4d44-9870-aff06002e257",
                "qt_name": "NUM_DECIMAL",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": 4123,
                "invalid": false
              },
              {
                "sd_id": "bc41afd2-3e8e-4711-ae47-8fd93536d4f0",
                "sd_colsize": "4",
                "sd_question": "5.c) Presión arterial",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "55e4063e-879b-4fca-a934-e4480353d7a4",
                "qt_name": "TEXTO_CORTO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "12421",
                "invalid": false
              },
              {
                "sd_id": "c53ed392-f9df-45f7-aeee-54c3e4fe057f",
                "sd_colsize": "12",
                "sd_question": "6) Varió su peso significativamente en los últimos 12 meses?",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "3e9f3654-3fed-4889-9fe9-277529c9ac24",
                "qt_name": "SINO_JUST_SI",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [
                  {
                    "sdo_id": "a874a37c-ca21-4c5d-9b16-f3efbfaae656",
                    "sdo_caption": "Si la respuesta es SI indicar cantidad y motivo.",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "abf8e545-d4f4-4774-a589-67fe924f0cd3",
                    "qt_name": "TEXTO_LARGO",
                    "segments_det_opt_tbl": []
                  }
                ],
                "value": "NO",
                "invalid": false
              }
            ]
          },
          {
            "type": "segment",
            "s_id": "6186d3ed-2f07-4030-8653-fad2af4d7e75",
            "s_name": "DECLARACION_JURADA_ANTECEDENTES_MEDICOS_TIPO1_P2",
            "s_title": "DECLARACIÓN JURADA DE ANTECEDENTES MÉDICOS",
            "s_subtitle": "SI LA RESPUESTA A UNA DE LAS SIGUIENTES PREGUNTAS ES 'SI' PROPORCIONE DETALLES EN NOTAS Y ACLARACIONES.",
            "s_finalnote": "",
            "segments_det": [
              {
                "sd_id": "ea38674e-13ad-4fb9-8ef6-33cbc4030de7",
                "sd_colsize": "12",
                "sd_question": "Durante los últimos 5 años, posee el solicitante conocimiento de padecer o de haber padecido o consultado al médico por:",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "84924fb8-6d9c-4fd2-ab9d-8adcc6693863",
                "qt_name": "INFORMATIVA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "invalid": false
              },
              {
                "sd_id": "f4ad4a5e-fc0f-424a-af12-f8717155c0cf",
                "sd_colsize": "12",
                "sd_question": "1) Enfermedades de hipertensión, cardiovasculares, respiratorias, endocrinológicas, diabetes, gastrointestinales, hepáticas, renales y vías urinarias?",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "8d3d1a37-91f5-4a95-9212-d344dd904a13",
                "qt_name": "SINO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "0",
                "invalid": false
              },
              {
                "sd_id": "d27f455e-3b6b-4cbb-9485-c7a4b0602768",
                "sd_colsize": "12",
                "sd_question": "2) Enfermedades ginecológicas o de las mamas, de la próstata, osteoarticulares, HIV/SIDA, neurológicas, cerebrovasculares, tumores benignos o malignos, discapacidad o malformación, adicciones a drogas o alcohol?",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "8d3d1a37-91f5-4a95-9212-d344dd904a13",
                "qt_name": "SINO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "0",
                "invalid": false
              },
              {
                "sd_id": "2751ce67-b392-4697-bce2-e1bf5da8bd4b",
                "sd_colsize": "12",
                "sd_question": "3) Durante los últimos 5 años, fue internado en algún hospital, clínica o establecimiento médico o fue tratado por alguna enfermedad crónica que lo obligo a guardar reposo por más de 21 días?",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "8d3d1a37-91f5-4a95-9212-d344dd904a13",
                "qt_name": "SINO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "0",
                "invalid": false
              },
              {
                "sd_id": "cfdf84c2-ca87-408b-8a98-4fb23b4ea629",
                "sd_colsize": "12",
                "sd_question": "4) En la actualidad, está tomando algún medicamento? En notas detallar medicamento y cantidades.",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "8d3d1a37-91f5-4a95-9212-d344dd904a13",
                "qt_name": "SINO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "0",
                "invalid": false
              },
              {
                "sd_id": "2ba91af8-8d36-40d8-851e-33c14374d2df",
                "sd_colsize": "12",
                "sd_question": "SOLO PARA MUJERES",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "e63cf9e7-47ab-4179-8438-301a231498ba",
                "qt_name": "INFORMATIVA_N",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "invalid": false
              },
              {
                "sd_id": "1b6e6234-2283-4cd9-9c4e-9d595475d452",
                "sd_colsize": "12",
                "sd_question": "Posee el solicitante conocimiento de: Esta actualmente embarazada?",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "3e9f3654-3fed-4889-9fe9-277529c9ac24",
                "qt_name": "SINO_JUST_SI",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [
                  {
                    "sdo_id": "be7e9091-603d-4fd3-a346-c4c445af6e6e",
                    "sdo_caption": "Fecha prevista de parto:",
                    "sdo_body": null,
                    "sdo_tabnumcol": null,
                    "sdo_tabnumrow": null,
                    "qt_id": "bf785bcc-731d-4797-819e-dde9bfb6e117",
                    "qt_name": "FECHA",
                    "segments_det_opt_tbl": []
                  }
                ],
                "value": "NO",
                "invalid": false
              },
              {
                "sd_id": "79ac60ea-fcba-4353-9fe1-2df2198f614f",
                "sd_colsize": "12",
                "sd_question": "NOTAS Y ACLARACIONES",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "e63cf9e7-47ab-4179-8438-301a231498ba",
                "qt_name": "INFORMATIVA_N",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "invalid": false
              },
              {
                "sd_id": "4d89dfa5-0f11-4b70-9792-57a0ce772428",
                "sd_colsize": "12",
                "sd_question": "Incluya: a) el número de pregunta, b) el diagnóstico y tratamiento, c) los resultados, d) las fechas y duración, e) los nombres, direcciones y teléfonos de todos los médicos personales y establecimientos médicos.",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "abf8e545-d4f4-4774-a589-67fe924f0cd3",
                "qt_name": "TEXTO_LARGO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              }
            ]
          },
          {
            "type": "segment",
            "s_id": "4f59e697-ee89-48ed-8a32-320a0063350e",
            "s_name": "PROTECCION_DE_DATOS_PERSONALES_CONSENTIMIENTO",
            "s_title": "PROTECCIÓN DE DATOS PERSONALES - CONSENTIMIENTO",
            "s_subtitle": "",
            "s_finalnote": "",
            "segments_det": [
              {
                "sd_id": "1b38f129-87c6-4a97-8cef-6e46fb4508bc",
                "sd_colsize": "12",
                "sd_question": "1- Por medio de la presente autorizo el tratamiento de los datos personales suministrados voluntariamente a MAPFRE ARGENTINA HOLDING S.A y/o cualquiera de las sociedades donde ésta tenga participación directa o indirecta como accionista (MAPFRE). También se autoriza el tratamiento de los datos que se obtengan mediante grabación de las conversaciones telefónicas que tengan lugar con motivo de la suscripción del riesgo. La finalidad de esta autorización es la prestación de servicios derivados de la propia suscripción del riesgo, estudios estadísticos, la lucha contra el fraude y la prevención de lavado de activos.",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "e63cf9e7-47ab-4179-8438-301a231498ba",
                "qt_name": "INFORMATIVA_N",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "invalid": false
              },
              {
                "sd_id": "2f5e4f08-f85b-4383-8a2e-48a2fef0a8d3",
                "sd_colsize": "12",
                "sd_question": "2- Se autoriza, además, que los datos puedan ser cedidos, exclusivamente, para las finalidades indicadas anteriormente a otras entidades del Grupo MAPFRE (*). Tal cesión podrá consistir en una transferencia de datos a otras personas físicas o jurídicas con las que las distintas entidades del Grupo MAPFRE concluyan acuerdos de colaboración y/o prestación de servicios, tanto a nivel local o internacional. Se exigirá en tales acuerdos el cumplimiento de los estándares de seguridad requeridos por la legislación argentina. Esta autorización tendrá vigencia incluso una vez extinguida la relación contractual existente, respetando en todos los casos la legislación argentina sobre protección de datos personales y sin necesidad de que le sea comunicada cada primera cesión que se efectúe a los referidos cesionarios.",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "84924fb8-6d9c-4fd2-ab9d-8adcc6693863",
                "qt_name": "INFORMATIVA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "invalid": false
              },
              {
                "sd_id": "c1f693c3-e5cd-42f1-abbf-16369a9fa122",
                "sd_colsize": "12",
                "sd_question": "3- Los referidos datos se recogen confidencialmente en las distintas bases de las empresas MAPFRE, todas con domicilio en Alférez Hipólito Bouchard 4191, Munro, Provincia de Buenos Aires, quienes asumen la adopción de las medidas de índole técnica y organizativa para proteger la confidencialidad e integridad de la información.",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "84924fb8-6d9c-4fd2-ab9d-8adcc6693863",
                "qt_name": "INFORMATIVA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "invalid": false
              },
              {
                "sd_id": "493cef60-c5d5-4ead-8616-9f6ceeafb885",
                "sd_colsize": "12",
                "sd_question": "4- El titular del dato podrá ejercer sobre sus datos personales los siguientes derechos",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "84924fb8-6d9c-4fd2-ab9d-8adcc6693863",
                "qt_name": "INFORMATIVA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "invalid": false
              },
              {
                "sd_id": "a65d8777-74d2-42a2-8dd0-9fb73473e3ef",
                "sd_colsize": "12",
                "sd_question": "i.- rectificación, actualización, supresión -plazo máximo de respuesta: 5 días hábiles de la comunicación fehaciente-,",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "84924fb8-6d9c-4fd2-ab9d-8adcc6693863",
                "qt_name": "INFORMATIVA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "invalid": false
              },
              {
                "sd_id": "d16a36c7-d329-412f-a423-1aaa79122690",
                "sd_colsize": "12",
                "sd_question": "ii.- acceso a los datos en forma gratuita a intervalos no inferiores a 6 meses, salvo que se acredite un interés legítimo al ef ecto -plazo máximo de respuesta: 10 días corridos de la comunicación fehaciente-,",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "84924fb8-6d9c-4fd2-ab9d-8adcc6693863",
                "qt_name": "INFORMATIVA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "invalid": false
              },
              {
                "sd_id": "b38ac039-d011-4e2f-9486-9fc8e0e8b06f",
                "sd_colsize": "12",
                "sd_question": "Estos derechos podrán efectivizarse a través de comunicación fehaciente dirigida a: Sres. MAPFRE ARGENTINA – Datos personales – Alférez Hipólito Bouchard 4191, (B1605BNA) Munro, Provincia de Buenos Aires.",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "84924fb8-6d9c-4fd2-ab9d-8adcc6693863",
                "qt_name": "INFORMATIVA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "invalid": false
              },
              {
                "sd_id": "49213ce1-927e-4410-b8f7-5a4f76c0efaf",
                "sd_colsize": "12",
                "sd_question": "La DIRECCIÓN NACIONAL DE PROTECCIÓN DE DATOS PERSONALES, Órgano de Control de la Ley de Protección de Datos Personales (Ley 25.326), tiene la atribución de atender las denuncias y reclamos que se interpongan con relación al incumplimiento de las normas sobre protección de datos personales.",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "84924fb8-6d9c-4fd2-ab9d-8adcc6693863",
                "qt_name": "INFORMATIVA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "invalid": false
              },
              {
                "sd_id": "1c0fabb3-955d-425c-98db-5642bbb542bb",
                "sd_colsize": "12",
                "sd_question": "5- La negativa de autorización para ceder los datos no alcanza aquellos supuestos en los que las normas legales exijan su transmisión en forma obligatoria. En caso de que los datos facilitados se refieran a personas físicas distintas del tomador, éste garantiza que está facultado legítimamente para facilitar los referidos datos y que ha procedido previamente a informar a los interesados de dicha cesión de datos, cumpliendo en todo momento la legalidad vigente, respondiendo ante MAPFRE ARGENTINA en caso de que no sea así.",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "84924fb8-6d9c-4fd2-ab9d-8adcc6693863",
                "qt_name": "INFORMATIVA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "invalid": false
              },
              {
                "sd_id": "842b475f-eb60-4b8b-ab67-668236911236",
                "sd_colsize": "12",
                "sd_question": "Si desea recibir información sobre productos y servicios de las distintas entidades del Sistema MAPFRE, marque aquí por favor.",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "b1bbcb2d-9478-4d3b-a660-38e735de6d07",
                "qt_name": "CHECKBOX",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": true,
                "invalid": false
              },
              {
                "sd_id": "070376ef-eed5-4504-833d-6849d9253862",
                "sd_colsize": "12",
                "sd_question": "(*) Grupo MAPFRE: Conjunto de entidades aseguradoras, reaseguradoras, financieras, inmobiliarias y de prestación de servicios en las cuales MAPFRE S.A. (España) tiene participación directa e indirecta como accionista.",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "e63cf9e7-47ab-4179-8438-301a231498ba",
                "qt_name": "INFORMATIVA_N",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "invalid": false
              },
              {
                "sd_id": "1492955e-2d42-46e3-9f42-1c2d6c5f72e4",
                "sd_colsize": "12",
                "sd_question": "De conformidad con la LEY 25.326 DE PROTECCIÓN DE DATOS PERSONALES, el que suscribe DECLARA haber leído la presente cláusula y ACEPTA su contenido, otorgando su CONSENTIMIENTO EXPRESO a la misma.",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "e63cf9e7-47ab-4179-8438-301a231498ba",
                "qt_name": "INFORMATIVA_N",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "invalid": false
              },
              {
                "sd_id": "e1f89b43-3934-4ee4-b4b0-ab84cf4cffa8",
                "sd_colsize": "8",
                "sd_question": "Lugar",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "abf8e545-d4f4-4774-a589-67fe924f0cd3",
                "qt_name": "TEXTO_LARGO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "f7591c51-acac-44f9-8c0c-63365a6c4c01",
                "sd_colsize": "4",
                "sd_question": "Fecha",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "bf785bcc-731d-4797-819e-dde9bfb6e117",
                "qt_name": "FECHA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "2023-04-08",
                "invalid": false
              },
              {
                "sd_id": "71e4b3ab-3d31-4da8-bd62-e944cf80d041",
                "sd_colsize": "6",
                "sd_question": "Apellido y Nombre / Razón Social",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "55e4063e-879b-4fca-a934-e4480353d7a4",
                "qt_name": "TEXTO_CORTO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "4bc87d02-cbf7-45c4-9aab-2abf63350180",
                "sd_colsize": "6",
                "sd_question": "Tipo y N° de Documento",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "55e4063e-879b-4fca-a934-e4480353d7a4",
                "qt_name": "TEXTO_CORTO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              }
            ]
          },
          {
            "type": "segment",
            "s_id": "556125c5-7f32-4ba4-a34f-dbf726004209",
            "s_name": "REGISTRO_NO_LLAME",
            "s_title": "REGISTRO NO LLAME",
            "s_subtitle": "",
            "s_finalnote": "",
            "segments_det": [
              {
                "sd_id": "b0485487-ca4e-4395-87f1-84449a0ba8b1",
                "sd_colsize": "12",
                "sd_question": "Aún cuando figure inscripto en el Registro Nacional No Llame y/o cualquier otro Registro No Llame provincial o municipal, autorizo a MAPFRE ARGENTINA HOLDING S.A. y/o cualquiera de las sociedades donde tenga participación directa o indirecta como accionista a contactarme a través de los servicios de telefonía en cualquiera de sus modalidades a fin de ofrecerme publicidad, oferta, venta y/o regalo, de bienes o servicios.",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "84924fb8-6d9c-4fd2-ab9d-8adcc6693863",
                "qt_name": "INFORMATIVA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "invalid": false
              },
              {
                "sd_id": "1c08d137-0b30-44fb-b436-5119c80808a0",
                "sd_colsize": "8",
                "sd_question": "Lugar",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "abf8e545-d4f4-4774-a589-67fe924f0cd3",
                "qt_name": "TEXTO_LARGO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "7f519be3-fa15-4187-8d8f-803a0aebc526",
                "sd_colsize": "4",
                "sd_question": "Fecha",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "bf785bcc-731d-4797-819e-dde9bfb6e117",
                "qt_name": "FECHA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "2023-03-07",
                "invalid": false
              },
              {
                "sd_id": "b3e893a0-9743-4836-80ef-fc5b9dae1a62",
                "sd_colsize": "6",
                "sd_question": "Apellido y Nombre / Razón Social",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "55e4063e-879b-4fca-a934-e4480353d7a4",
                "qt_name": "TEXTO_CORTO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "98621136-8f82-488b-9dcd-c1418fb50fec",
                "sd_colsize": "6",
                "sd_question": "Tipo y N° de Documento",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "55e4063e-879b-4fca-a934-e4480353d7a4",
                "qt_name": "TEXTO_CORTO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              }
            ]
          },
          {
            "type": "segment",
            "s_id": "6d4002c2-a12c-462b-993a-bf4e9e8638c5",
            "s_name": "UIF",
            "s_title": "UIF",
            "s_subtitle": "PREVENCIÓN LAVADO DE ACTIVOS",
            "s_finalnote": "",
            "segments_det": [
              {
                "sd_id": "056c3836-70dc-4d70-a7cf-99352476128e",
                "sd_colsize": "12",
                "sd_question": "En los supuestos de realizarse un pago en virtud de la póliza; o al momento de realizarse una cesión de derechos, un cambio de beneficiarios, o una anulación de póliza, independientemente del cumplimiento de las exigencias establecidas en el contrato y ley de seguros, el asegurado, beneficiario o cesionario deberá cumplimentar los requisitos de información y documentación correspondientes para su adecuada identificación, pudiendo alcanzar la presentación de documentación económica, patrimonial, tributaria y financiera que justifique el origen de los fondos involucrados en su operatoria.",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "84924fb8-6d9c-4fd2-ab9d-8adcc6693863",
                "qt_name": "INFORMATIVA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "invalid": false
              }
            ]
          },
          {
            "type": "segment",
            "s_id": "e737ae79-0896-4a3d-9c88-c318de61ebdf",
            "s_name": "CONFORMIDAD",
            "s_title": "CONFORMIDAD",
            "s_subtitle": "",
            "s_finalnote": "",
            "segments_det": [
              {
                "sd_id": "ce9767f1-3edc-49b6-a3c8-abce5c065240",
                "sd_colsize": "12",
                "sd_question": "El Tomador declara: 1) que el presente cuestionario se ha cumplimentado en su presencia y que reproduce fielmente las respuestas que el mismo ha dado a las preguntas en él formuladas, 2) que ha leído con atención el contenido del cuestionario y las respuestas antes de firmarlo, 3) que todos los datos arriba citados, como asimismo los que figuran en la nómina adjunta son exactos y está de acuerdo en que esta solicitud sirva de base para la emisión de la póliza cuyas condiciones son de su conocimiento y conformidad, 4) que conoce lo establecido en el artículo 5, primer párrafo, de la ley de seguros que dice: “Toda declaración falsa o toda reticencia de circunstancias conocidas por el asegurado, aun hechas de buena fe, que a juicio de peritos hubiese impedido el contrato o modificado sus condiciones, si el asegurador hubiese sido cerciorado del verdadero estado del riesgo, hace nulo el contrato”, 5) que autoriza a los médicos y a los establecimientos asistenciales (públicos o privados) que o asisten o que lo hayan asistido, dentro de los límites legales, a suministrar la información que les sea requerida por el Asegurador con motivo del seguro que se solicita.",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "e63cf9e7-47ab-4179-8438-301a231498ba",
                "qt_name": "INFORMATIVA_N",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "invalid": false
              },
              {
                "sd_id": "7d2fdbc2-882d-4a22-8aa2-860ca59544a4",
                "sd_colsize": "12",
                "sd_question": "Queda establecido: 1) que habrá contrato de seguro cuando el Asegurador acepte esta Solicitud de Seguro, 2) que la cobertura estrará en vigencia en las condiciones que se establecen en la póliza, en la cláusula de Cobranza de Premios, 3) que todas las declaraciones y respuestas consignadas en esta Solicitud, como así también aquellas que se hagan en su consecuencia, son completas, precisas y verídicas para todas las partes interesadas en la póliza solicitada y, 4) que ningún productor asesor de seguros se encuentre autorizado a exceptuar o modificar las condiciones de contratación dispuesta por el Asegurador.",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "e63cf9e7-47ab-4179-8438-301a231498ba",
                "qt_name": "INFORMATIVA_N",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "invalid": false
              },
              {
                "sd_id": "477a0fd6-8f3a-484c-9378-be0af77d805f",
                "sd_colsize": "12",
                "sd_question": "Autorizo el débito que corresponda, por tarjeta de crédito o débito directo en cuenta, de acuerdo a la forma de pago seleccionada por mi persona como tomador de la póliza.",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "e63cf9e7-47ab-4179-8438-301a231498ba",
                "qt_name": "INFORMATIVA_N",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "invalid": false
              },
              {
                "sd_id": "12d2dcce-da62-4ec1-aa46-1963007f02a0",
                "sd_colsize": "8",
                "sd_question": "Lugar",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "abf8e545-d4f4-4774-a589-67fe924f0cd3",
                "qt_name": "TEXTO_LARGO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "02b635dc-e9b3-4d9a-b1ba-10de24c9d791",
                "sd_colsize": "4",
                "sd_question": "Fecha",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "bf785bcc-731d-4797-819e-dde9bfb6e117",
                "qt_name": "FECHA",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "2023-03-07",
                "invalid": false
              },
              {
                "sd_id": "06041ebd-d20d-49c3-adcb-8f645fc56578",
                "sd_colsize": "4",
                "sd_question": "Aclaración",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "55e4063e-879b-4fca-a934-e4480353d7a4",
                "qt_name": "TEXTO_CORTO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              },
              {
                "sd_id": "00f576d7-00ce-4a67-98e3-3ec254051185",
                "sd_colsize": "4",
                "sd_question": "CUIL / CUIT",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 1,
                "qt_id": "55e4063e-879b-4fca-a934-e4480353d7a4",
                "qt_name": "TEXTO_CORTO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": [],
                "value": "TEXTO PRUEBA",
                "invalid": false
              }
            ]
          },
          {
            "type": "segment",
            "s_id": "d3e2e6a2-974d-4c5c-8705-c52f59db02d5",
            "s_name": "PRODUCTOR",
            "s_title": "PRODUCTOR",
            "s_subtitle": "",
            "s_finalnote": "",
            "segments_det": [
              {
                "sd_id": "f2528d49-2498-475a-b026-4cde73d3c12e",
                "sd_colsize": "12",
                "sd_question": "Nombre y Apellido del Productor",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 0,
                "qt_id": "abf8e545-d4f4-4774-a589-67fe924f0cd3",
                "qt_name": "TEXTO_LARGO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": []
              },
              {
                "sd_id": "860c2fb5-cd94-494d-bb4f-f7d066240b74",
                "sd_colsize": "12",
                "sd_question": "Código",
                "sd_tabnumcol": null,
                "sd_tabnumrow": null,
                "sd_required": 0,
                "qt_id": "abf8e545-d4f4-4774-a589-67fe924f0cd3",
                "qt_name": "TEXTO_LARGO",
                "sd_tablesId": null,
                "segments_det_tbl": [],
                "segments_det_opt": []
              }
            ]
          }
        ]
        // this.showPreviewPdf = true;
        // this.pdfService.generateDoc(this.formQuestions, false, "VIDA PLUS RENOVABLE", 'datauristring').then(data => {
        //   this.pdfBase64 = this.sanitazer.bypassSecurityTrustResourceUrl(data);
        // })*/
        this.LoadFormByToken();
      }
    })

    this.loading.progressRef = this.progress.ref('progressBar');
  }

  LoadFormByToken(): void {
    this.api.getFormByToken().subscribe(response => {
      let { status, data } = response;
      if (status == ECodeStatus.Ok) {
        this.formName = data.form.title;
        this.formImage = data.form.pathimg;
        this.formDet = data.formDet;
        // this.formDet.sort();
        let one = this.formDet.filter(e => e.ordernum == this.indexParents.toString());
        this.LoadFormDet(one[0].id);
      } else {
        this.router.navigate(['/']);
      }
    }, error => {
      if (error.status == 401) {
        this.router.navigate(['/']);
      }
    })
  }

  LoadFormDet(id: any): void {
    this.formLoadingComplete = true;
    this.api.getFormDet(id).subscribe(response => {
      let { status, data } = response;
      this.formLoadingComplete = false
      if (status == ECodeStatus.Ok) {
        this.indexParents++;
        if (data.type == 'segment') {
          console.log("segmento")
          //Agregar Tablas
          this.SetTables(data)
        } else {
          this.formQuestions.push(data);
          this.VerifyNextTab([data])
        }

      }
    })
  }

  SetTables(data: any): void {

    for (let i = 0; i < data.segments_det.length; i++) {
      const element = data.segments_det[i];
      if (element.qt_name == "TABLA") {
        element.table = []
        
      } else {
        let exits = element.segments_det_opt.filter(d => d.qt_name == "TABLA")
        if (exits.length) {
          let index = element.segments_det_opt.findIndex(d => d.qt_name == "TABLA")
          if (index >= 0) {
            let tableSize = [];
            for (let j = 0; j < element.segments_det_opt[index].sdo_tabnumrow; j++) {
              let row = []
              for (let c = 0; c < element.segments_det_opt[index].sdo_tabnumcol; c++) {
                row.push({value: ''})
              }
              tableSize.push(row)
            }
            element.segments_det_opt[index].table = tableSize;
          }
        }

      }
    }
    setTimeout(() => {
      this.formQuestions.push(data);
      this.VerifyNextTab([data])
    }, 3000);
  }

  VerifyNextTab(data: [any]): void {
    let find = data.filter(e => e.type == 'key')
    if (find.length == 0) {
      console.log("No existen mas keys, cargar el siguiente padre");
      let one = this.formDet.filter(e => e.ordernum == this.indexParents.toString());
      if (one.length) {
        this.LoadFormDet(one[0].id);
      } else {
        this.formLoadingComplete = true;
        console.log("Formulario cargado completamente");
      }
    } else {
      console.log("Existe otro key que puede tener hijos");
    }
  }

  /** Events */

  onClickNextTab(): void {

    if (this.showPreviewPdf) {
      this.showCongratulations = true;
      this.pdfService.generateDoc(this.formQuestions, false, this.formName, 'datauri').then(data => {
        //this.pdfService.sendBase64(data)
      })
    }

    if (this.tab == this.formQuestions.length && this.formLoadingComplete) {
      this.showPreviewPdf = true;
      this.pdfService.generateDoc(this.formQuestions, false, this.formName, 'datauristring').then(data => {
        this.pdfBase64 = this.sanitazer.bypassSecurityTrustResourceUrl(data);
      })
    }

    /** Validate tab */
    let validate = true;
    if (this.tab >= 0 && this.tab != null) {
      let dataToValidate = this.formQuestions[(this.tab - 1)];
      if (dataToValidate.type == 'key') {

        if (!dataToValidate.value) {
          dataToValidate.invalid = true;
          validate = false;
          return
        } else {
          dataToValidate.invalid = false;
          validate = true;
        }

        // Eliminar items despues de el, por si cambio  de opinion
        this.formQuestions.splice(this.tab, this.formQuestions.length);
        this.formLoadingComplete = false;
        this.showCongratulations = false;

        if (dataToValidate.kt_name == "NUM_ENTERO") {
          dataToValidate.keys_opt.forEach(key_opt => {
            if (key_opt.ct_name == 'MENOR IGUAL') {
              if (dataToValidate.value <= key_opt.ko_value) {
                console.log("Menor e igual")
                this.onSelectOption(key_opt.ko_id)
              }
            }

            if (key_opt.ct_name == 'MAYOR') {
              if (dataToValidate.value > key_opt.ko_value) {
                console.log("Mayor")
                this.onSelectOption(key_opt.ko_id)
              }
            }
          });
        }

        if (dataToValidate.kt_name == 'OPC_UNICA') {
          let item = dataToValidate.keys_opt.filter(e => e.ko_id == dataToValidate.value)
          if (item.length) {
            this.onSelectOption(item[0].ko_id)
          }
        }
      }

      if (dataToValidate.type == 'segment') {
        dataToValidate.segments_det.forEach(element => {
          console.log(element);
          if (element.qt_name != 'INFORMATIVA' && element.qt_name != 'INFORMATIVA_N') {
            if (element.qt_name == 'TABLA') {

            } else {
              if (!element.value && element.sd_required) {
                element.invalid = true;
                validate = false;
                console.log("Cambio a falso", validate)
              } else {
                element.invalid = false;
              }
            }
          } else {
            element.invalid = false;
          }
        });
      }
    }

    if (validate) {
      if (this.tab) {
        // if (this.tab == 3) this.pdfService.generateDoc(this.formQuestions, false, this.formName);
        this.tab++;
      } else {
        this.tab = 1;
      }
    }
  }

  onClickPrevTab(): void {
    if (this.showPreviewPdf) {
      this.showPreviewPdf = false;
    }
    if (this.tab) {
      this.tab--;
    } else {
      this.tab = null;
    }
  }

  onSelectOption(id: any): void {
    this.loading.startLoading();
    this.api.getKeyOpt(id).subscribe(response => {
      let { status, data } = response;
      this.loading.completeLoading();
      if (status == ECodeStatus.Ok) {
        data.forEach((element: any) => {
          this.formQuestions.push(element)
        });
        this.VerifyNextTab(data)
      }
    })
  }

  createArray(rows: any, colums: any, indexQuestion: any, indexSegDetail, indexSegDetOpt) {
    let array = [];

    for (let i = 0; i < rows; i++) {
      let arrayCol = [];
      for (let j = 0; j < colums; j++) {
        arrayCol.push({ value: '' });
      }
      array.push(arrayCol);
    }
    // if (this.formQuestions[indexQuestion].segments_det[indexSegDetail].qt_name == 'TABLA') {
    //   this.formQuestions[indexQuestion].segments_det[indexSegDetail].table = array
    // } else if (this.formQuestions[indexQuestion].segments_det[indexSegDetail].qt_name == 'OPC_UNICA') {
    //   if (indexSegDetOpt >= 0) {
    //     if (this.formQuestions[indexQuestion].segments_det[indexSegDetail].segments_det_opt[indexSegDetOpt].qt_name == 'TABLA') {
    //       this.formQuestions[indexQuestion].segments_det[indexSegDetail].segments_det_opt[indexSegDetOpt].table = array
    //     }
    //   }
    // }

    return array;
  }

}
