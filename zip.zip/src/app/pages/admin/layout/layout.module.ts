import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LayoutComponent } from './layout.component';
import { RouterModule, Routes } from '@angular/router';
import { NgProgressModule } from 'ngx-progressbar';

const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('../dashboard/dashboard.module').then(m => m.DashboardModule)
  },
  {
    path: 'usuarios',
    loadChildren: () => import('../users/users.module').then(m => m.UsersModule)
  },
  {
    path: 'secciones',
    loadChildren: () => import('../sections/sections.module').then(m => m.SectionsModule)
  },
  {
    path: 'categorias',
    loadChildren: () => import('../categories/categories.module').then(m => m.CategoriesModule)
  },
  {
    path: 'productos',
    loadChildren: () => import('../products/products.module').then(m => m.ProductsModule)
  },
  {
    path: 'segmentos',
    loadChildren: () => import('../segments/segments.module').then(m => m.SegmentsModule)
  },
  {
    path: 'segmento/:id/detalle',
    loadChildren: () => import('../segments-detail/segments-detail.module').then(m => m.SegmentsDetailModule)
  },
  {
    path: 'segmento/detalle/:id/opciones',
    loadChildren: () => import('../segments-detail-options/segments-detail-options.module').then(m => m.SegmentsDetailOptionsModule)
  },
  {
    path: 'claves',
    loadChildren: () => import('../keys/keys.module').then(m => m.KeysModule)
  },
  {
    path: 'claves/:id/detalle',
    loadChildren: () => import('../key-options/key-options.module').then(m => m.KeyOptionsModule)
  },
  {
    path: 'tablas',
    loadChildren: () => import('../tables/tables.module').then(m => m.TablesModule)
  },
  {
    path: 'tabla/:id/detalle',
    loadChildren: () => import('../tables-detail/tables-detail.module').then(m => m.TablesDetailModule)
  },
  {
    path: 'formularios',
    loadChildren: () => import('../forms/forms.module').then(m => m.FormsModule)
  },
  {
    path: 'formulario/:id/detalle',
    loadChildren: () => import('../form-detail/form-detail.module').then(m => m.FormDetailModule)
  },
  {
    path: 'logs',
    loadChildren: () => import('../logs/logs.module').then(m => m.LogsModule)
  }
]

@NgModule({
  declarations: [
    LayoutComponent
  ],
  imports: [
    CommonModule,
    NgProgressModule,
    RouterModule.forChild(routes)
  ]
})
export class LayoutModule { }
