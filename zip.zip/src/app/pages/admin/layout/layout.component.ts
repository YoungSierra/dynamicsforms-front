import { Component, OnInit } from '@angular/core';
import { NgProgress } from 'ngx-progressbar';
import { ProgressBarService } from '../../../services/progress-bar.service';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss']
})
export class LayoutComponent implements OnInit {

  constructor(
    private loading: ProgressBarService,
    private progress: NgProgress,
  ) { }

  ngOnInit(): void {
    this.loading.progressRef = this.progress.ref('progressBar');
  }

}
