import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SegmentsDetailOptionsComponent } from './segments-detail-options.component';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';

const routes: Routes = [
  {
    path: '',
    component: SegmentsDetailOptionsComponent
  }
]

@NgModule({
  declarations: [
    SegmentsDetailOptionsComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes)
  ]
})
export class SegmentsDetailOptionsModule { }
