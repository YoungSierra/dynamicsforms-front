import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ECodeStatus } from '../../../enums/ecode-status';
import { LogsService } from '../../../services/logs.service';

@Component({
  selector: 'app-logs',
  templateUrl: './logs.component.html',
  styleUrls: ['./logs.component.scss']
})
export class LogsComponent implements OnInit {

  listData: any[] = [];
  formFilter: FormGroup;

  constructor(
    private logsService: LogsService,
    private fb: FormBuilder
  ) { }

  ngOnInit(): void {

    this.formFilter = this.fb.group({
      date: [''],
      page: ['1'],
      size: ['50']
    })
  }

  /** Methods */
  LoadLogs(params): void {
    this.logsService.getLogs(params).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listData = data;
      }

    })
  }

  /** Events */
  onClickSearchLogs(): void {
    let data = this.formFilter.value

    this.LoadLogs(data);
  }

}
