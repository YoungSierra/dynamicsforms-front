import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ECodeStatus } from '../../../enums/ecode-status';
import { AlertsService } from '../../../services/alerts.service';
import { FormsService } from '../../../services/forms.service';
import { KeyService } from '../../../services/key.service';
import { SegmentsService } from '../../../services/segments.service';

@Component({
  selector: 'app-form-detail',
  templateUrl: './form-detail.component.html',
  styleUrls: ['./form-detail.component.scss']
})
export class FormDetailComponent implements OnInit {

  @ViewChild('formDetailModal') formDetailModal: ElementRef;
  idForm: any;
  listFormDetail: any[] = [];
  listKeys: any[] = [];
  listSegments: any[] = [];
  idFormDetailEdit: any;
  typeForm: 'S' | 'K';
  formDetail: FormGroup;

  constructor(
    private formService: FormsService,
    private fb: FormBuilder,
    private router: ActivatedRoute,
    private modalService: NgbModal,
    private alertService: AlertsService,
    private keyService: KeyService,
    private segmentService: SegmentsService,
  ) { }

  ngOnInit(): void {
    this.router.params.subscribe(params => {
      if (params['id']) {
        this.idForm = params['id'];
        this.LoadFormDetail(params['id']);
      }
    })

    this.formDetail = this.fb.group({
      type: [''],
      formsId: [this.idForm],
      keysId: [''],
      segmentsId: [''],
      ordernum: ['']
    })
  }

  /** Methods */

  LoadFormDetail(id): void {
    this.formService.getDetailtById(id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listFormDetail = data
      }
    })

  }

  LoadKeys(): void {
    this.keyService.getKeys().subscribe(response => {
      let { status, data, message } = response;
      if (status == ECodeStatus.Ok) {
        this.listKeys = data;
      }
    })
  }

  LoadSegments(): void {
    this.segmentService.getSegments().subscribe(response => {
      let { status, data, message } = response;
      if (status == ECodeStatus.Ok) {
        this.listSegments = data;
      }
    })
  }

  SaveFormDetail(data): void {
    this.formService.saveFormDetail(data).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadFormDetail(this.idForm);
        this.modalService.dismissAll();
      }
    })
  }

  DeleteFormDetail(id): void {
    this.formService.deleteFormDetail(id).subscribe(response => {
      let { status, data, message } = response;
      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadFormDetail(this.idForm);
        this.modalService.dismissAll();
      }
    })
  }

  /** Events */
  onClickInactivate(item): void {
    this.formService.inactivateFormDetail(item.fd_id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadFormDetail(this.idForm)
      } else {
        this.alertService.error(message)
      }
    })
  }

  onClickActivate(item): void {
    this.formService.activateFormDetail(item.fd_id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadFormDetail(this.idForm)
      } else {
        this.alertService.error(message)
      }
    })
  }

  onClickNewDetail(): void {
    this.idFormDetailEdit = null;
    this.formDetail.reset();
    this.formDetail.patchValue({ formsId: this.idForm })
    this.modalService.open(this.formDetailModal, { centered: true });
  }

  onChangeLoadDependencies(): void {
    let data = this.formDetail.value;
    this.listKeys = []; this.listSegments = [];
    this.formDetail.patchValue({ keysId: '', segmentsId: '' })
    if (data.type == 'key') {
      this.LoadKeys();
    } else {
      this.LoadSegments();
    }
  }

  onClickEditForm(item): void {
    this.idFormDetailEdit = item.id;
    this.formDetail.patchValue(item);
    this.modalService.open(this.formDetailModal, { centered: true });
  }

  onClickSaveDetail(): void {
    let data = this.formDetail.value;

    if (data.type == 'key') {
      delete data.segmentsId;
    } else {
      delete data.keysId;
    }

    this.SaveFormDetail(data);
  }

  onClickDeleteForm(item): void {
    this.alertService.questionDelete("Desea eliminar este segmento/clave del formulario?").then(res => {
      if (res) {
        this.DeleteFormDetail(item.fd_id);
      }
    })
  }

}
