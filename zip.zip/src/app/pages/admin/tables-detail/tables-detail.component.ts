import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ECodeStatus } from '../../../enums/ecode-status';
import { AlertsService } from '../../../services/alerts.service';
import { TablesService } from '../../../services/tables.service';

@Component({
  selector: 'app-tables-detail',
  templateUrl: './tables-detail.component.html',
  styleUrls: ['./tables-detail.component.scss']
})
export class TablesDetailComponent implements OnInit {

  @ViewChild('modalDetail') modalDetail: ElementRef;
  idTable: string = null;
  idTableDetail: string = null;
  listDetail: any[] = [];
  formTableDetail: FormGroup;

  constructor(
    private router: ActivatedRoute,
    private tablesService: TablesService,
    private alertService: AlertsService,
    private fb: FormBuilder,
    private modalService: NgbModal
  ) { }

  ngOnInit(): void {

    this.router.params.subscribe(params => {
      console.log(params);
      if (params['id']) {
        this.idTable = params['id'];

        this.LoadDetail(this.idTable);
      }
    })


    this.formTableDetail = this.fb.group({
      value: ['', Validators.required]
    })

  }

  /** Methods */
  LoadDetail(id: string): void {
    this.tablesService.getDetailByIdTable(id).subscribe(response => {
      let { status, data } = response;

      if (status == ECodeStatus.Ok) {
        this.listDetail = data;
      }
    })
  }

  SaveTableDetail(data): void {
    this.tablesService.saveTableDetail(data).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadDetail(this.idTable);
        this.modalService.dismissAll();
      } else {
        this.alertService.error(message);
      }
    })
  }

  UpdateTableDetail(id, data): void {
    this.tablesService.updateTableDetail(id, data).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadDetail(this.idTable);
        this.modalService.dismissAll();
      } else {
        this.alertService.error(message);
      }
    })
  }

  DeleteTableDetail(id): void {
    this.tablesService.deleteTableDetail(id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadDetail(this.idTable)
      }
    })
  }

  /** Events */

  onClickInactivate(item): void {
    this.tablesService.inactivateTablesDetail(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadDetail(this.idTable)
      }
    })
  }

  onClickActivate(item): void {
    this.tablesService.activateTablesDetail(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadDetail(this.idTable)
      }
    })
  }

  onClickNewTableDetail(): void {
    this.idTableDetail = null;
    this.formTableDetail.reset();
    this.modalService.open(this.modalDetail, { centered: true });
  }

  onClickSaveTableDetail(): void {
    if (this.formTableDetail.valid) {
      let data = this.formTableDetail.value;
      if (this.idTableDetail) {
        this.UpdateTableDetail(this.idTableDetail, data);
      } else {
        data.tablesId = this.idTable;
        this.SaveTableDetail(data)
      }
    }
  }

  onClickEditTable(item): void {
    this.idTableDetail = item.id;
    this.formTableDetail.patchValue(item);
    this.modalService.open(this.modalDetail, { centered: true });
  }

  onClickDeleteTable(item): void {
    this.alertService.questionDelete("").then(res => {
      if (res) {
        this.DeleteTableDetail(item.id)
      }
    })
  }


}
