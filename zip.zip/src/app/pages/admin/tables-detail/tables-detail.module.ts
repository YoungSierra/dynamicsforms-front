import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TablesDetailComponent } from './tables-detail.component';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';

const routes: Routes = [
  {
    path: '',
    component: TablesDetailComponent
  }
]

@NgModule({
  declarations: [
    TablesDetailComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    ReactiveFormsModule,
    CommonModule
  ]
})
export class TablesDetailModule { }
