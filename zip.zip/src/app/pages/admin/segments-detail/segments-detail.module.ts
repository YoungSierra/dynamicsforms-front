import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SegmentsDetailComponent } from './segments-detail.component';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';

const routes: Routes = [
  {
    path: '',
    component: SegmentsDetailComponent
  }
]

@NgModule({
  declarations: [
    SegmentsDetailComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes)
  ]
})
export class SegmentsDetailModule { }
