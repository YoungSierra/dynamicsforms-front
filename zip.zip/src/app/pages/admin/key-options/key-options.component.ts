import { Location } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ECodeStatus } from '../../../enums/ecode-status';
import { AlertsService } from '../../../services/alerts.service';
import { ConditionTypesService } from '../../../services/condition-types.service';
import { KeyService } from '../../../services/key.service';
import { SegmentsService } from '../../../services/segments.service';

@Component({
  selector: 'app-key-options',
  templateUrl: './key-options.component.html',
  styleUrls: ['./key-options.component.scss']
})
export class KeyOptionsComponent implements OnInit {

  @ViewChild('modalConfigKey') modalConfigKey: ElementRef;

  idKey: string = null;
  listKeyOptions: any[] = [];
  listConditionTypes: any[] = [];
  listSegments: any[] = [];
  infoKey: any;
  formConfigKey: FormGroup;

  constructor(
    private route: ActivatedRoute,
    private keyServices: KeyService,
    private alertService: AlertsService,
    private conditionTypeService: ConditionTypesService,
    private modalService: NgbModal,
    private fb: FormBuilder,
    private location: Location,
    private segmentService: SegmentsService
  ) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      if (params['id']) {
        this.idKey = params['id'];
        this.LoadKeyDetail(params['id']);
      }
    })

    setTimeout(() => {
      this.LoadConditionTypes();
    }, 1500);

    setTimeout(() => {
      this.LoadSegments();
    }, 3000);

    this.formConfigKey = this.fb.group({
      keysId: [this.idKey],
      value: [''],
      condtypesId: [''],
      segmentsId: ['']
    })
  }

  /** Methods */
  LoadKeyDetail(id): void {
    this.listKeyOptions = [];
    this.keyServices.getKeyOptionsByKeyId(id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listKeyOptions = data;
      }
    })
  }


  LoadConditionTypes(): void {
    this.conditionTypeService.getConditionTypes().subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listConditionTypes = data;
      }
    })
  }

  DeleteKeyOption(id): void {
    this.keyServices.deleteKeyOption(id).subscribe(response => {
      let { status, data, message } = response;
      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadKeyDetail(this.idKey);
      } else {
        this.alertService.error(message);
      }
    })
  }

  LoadSegments(): void {
    this.segmentService.getSegments().subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.listSegments = data;
      }
    })
  }

  SaveKeyOption(params): void {
    this.keyServices.saveKayOptions(params).subscribe(response => {
      let { status, data, message } = response;
      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadKeyDetail(this.idKey);
        params.keysOptId = data;
        this.SaveKeyOptionSegment(params)
      } else {
        this.alertService.error(message);
      }
    })
  }

  SaveKeyOptionSegment(data): void {
    this.keyServices.saveKeyOptionSegment(data).subscribe(response => {
      let { status, data, message } = response;
      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
      } else {
        this.alertService.error(message);
      }
    })
  }

  LoadKeyById(id): void {
    this.keyServices.getKeyById(id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.infoKey = data
      }
    })
  }

  /** Events */
  onClickInactivate(item): void {
    this.keyServices.inactivateKeyOption(item.id).subscribe(response => {
      let { status, data, message } = response;
      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadKeyDetail(this.idKey);
      } else {
        this.alertService.error(message);
      }
    })
  }

  onClickActivate(item): void {
    this.keyServices.activateKeyOption(item.id).subscribe(response => {
      let { status, data, message } = response;
      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadKeyDetail(this.idKey);
      } else {
        this.alertService.error(message);
      }
    })
  }

  onClickDeleteKeyOption(item): void {
    this.alertService.questionDelete("Desea eliminar esta opción?").then(res => {
      if (res) {
        this.DeleteKeyOption(item.id)
      }
    })
  }

  onClickNewKeyOption(): void {

    this.modalService.open(this.modalConfigKey, { centered: true })
  }
  onClickBack(): void {
    this.location.back();
  }

  onClickSaveKeyOption(): void {
    let data = this.formConfigKey.value;

    this.SaveKeyOption(data)
  }

  onClickEditKeyOption(): void {

  }

}
