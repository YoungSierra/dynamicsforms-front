import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ECodeStatus } from '../../../enums/ecode-status';
import { UserService } from '../../../services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  formLogin: FormGroup

  constructor(
    private fb: FormBuilder,
    private userService: UserService,
    private router: Router
  ) {

    this.formLogin = this.fb.group({
      email: [''],
      password: ['']
    })

  }

  ngOnInit(): void {
  }

  /** Methods */
  Login(params): void {
    this.userService.login(params).subscribe(response => {
      let { status, data } = response;

      if (status == ECodeStatus.Ok) {
        localStorage.setItem('token', data);
        localStorage.setItem('email', params.email);
        this.router.navigate(['admin/usuarios']);
      } else {

      }
    })
  }

  /** Events */
  onClickLogin(): void {
    if (this.formLogin.valid) {
      let data = this.formLogin.value;

      this.Login(data);
    }
  }

}
