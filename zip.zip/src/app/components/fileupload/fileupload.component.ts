import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { File } from '../../interfaces/file';

@Component({
  selector: 'app-fileupload',
  templateUrl: './fileupload.component.html',
  styleUrls: ['./fileupload.component.scss']
})
export class FileuploadComponent implements OnInit {

  @Output() fileEmiter = new EventEmitter<File>();
  fileInfo: File = {
    name: '',
    base64: '',
    base64Sort: ''
  };

  constructor() { }

  ngOnInit(): void {
  }

  upload(event: any) {
    var reader = new FileReader();
    reader.readAsDataURL(event[0]);
    reader.onload = () => {
      this.fileEmiter.emit({ name: event[0].name, base64: reader.result.toString(), base64Sort: reader.result.toString().split(',')[1] })
      this.fileInfo = { name: event[0].name, base64: reader.result.toString(), base64Sort: reader.result.toString().split(',')[1] }
    };
    reader.onerror = (error) => {
      console.log('Error: ', error);
    };
  }

}
