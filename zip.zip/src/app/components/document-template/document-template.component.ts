import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-document-template',
  templateUrl: './document-template.component.html',
  styleUrls: ['./document-template.component.scss']
})
export class DocumentTemplateComponent implements OnInit {

  @Input() formQuestions: any;

  constructor() { }

  ngOnInit(): void {
  }

}
