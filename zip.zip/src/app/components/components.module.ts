import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FileuploadComponent } from './fileupload/fileupload.component';
import { DirectivesModule } from '../directives/directives.module';
import { DocumentTemplateComponent } from './document-template/document-template.component';



@NgModule({
  declarations: [
    FileuploadComponent,
    DocumentTemplateComponent
  ],
  imports: [
    CommonModule,
    DirectivesModule
  ],
  exports: [
    FileuploadComponent,
    DocumentTemplateComponent
  ]
})
export class ComponentsModule { }
