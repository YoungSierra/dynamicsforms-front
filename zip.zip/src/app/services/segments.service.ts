import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Response } from '../interfaces/response';
import { MethodsService } from './methods.service';

@Injectable({
  providedIn: 'root'
})
export class SegmentsService {

  constructor(
    private methods: MethodsService
  ) { }

  getSegmentsAll(): Observable<Response> {
    return this.methods.GET(`segments/getAll`);
  }

  getSegments(): Observable<Response> {
    return this.methods.GET(`segments`)
  }

  getSegmentById(id): Observable<Response> {
    return this.methods.GET(`segments/${id}`);
  }

  saveSegments(params): Observable<Response> {
    return this.methods.POST(`segments`, params);
  }

  updateSegments(id, params): Observable<Response> {
    return this.methods.PUT(`segments/${id}`, params);
  }

  deleteSegment(id): Observable<Response> {
    return this.methods.DELETE(`segments/${id}`);
  }

  activateSegment(id): Observable<Response> {
    return this.methods.POST(`segments/activate/${id}`);
  }

  inactivateSegment(id): Observable<Response> {
    return this.methods.POST(`segments/inactivate/${id}`);
  }

  segmentDraw(id): Observable<Response> {
    return this.methods.GET(`segments/draw/${id}`);
  }

  /** Detalle */
  getDetailBySegmentId(id): Observable<Response> {
    return this.methods.GET(`segmentsdet/GetBySegmentId/${id}`);
  }

  saveSegmentDetail(params): Observable<Response> {
    return this.methods.POST(`segmentsdet`, params);
  }

  updateSegmentDetail(id, params): Observable<Response> {
    return this.methods.PUT(`segmentsdet/${id}`, params);
  }

  activateSegmentDetail(id): Observable<Response> {
    return this.methods.POST(`segmentsdet/activate/${id}`)
  }

  inactivateSegmentDetail(id): Observable<Response> {
    return this.methods.POST(`segmentsdet/inactivate/${id}`)
  }

  deleteSegmentDetail(id): Observable<Response> {
    return this.methods.DELETE(`segmentsdet/${id}`);
  }


  /** Detalle Opcionoes */
  getSegmentDetailOptionsAll(): Observable<Response> {
    return this.methods.GET(`segmentsdetopt/getAll`);
  }

  getSegmentDetailOptions(): Observable<Response> {
    return this.methods.GET(`segmentsdetopt`);
  }

  getSegmentDetailOptionById(id): Observable<Response> {
    return this.methods.GET(`segmentsdetopt/${id}`);
  }

  getSegmentDetailOptionsBySegmentDetailId(id): Observable<Response> {
    return this.methods.GET(`segmentsdetopt/getBySegmentsDetId/${id}`);
  }

  saveSegmentDetailOption(params): Observable<Response> {
    return this.methods.POST(`segmentsdetopt`, params);
  }

  // updateSegmentDetailOption(id, params): Observable<Response>{
  //   return this.methods.PUT(``)
  // }

  activateSegmentDetailOption(id): Observable<Response> {
    return this.methods.POST(`segmentsdetopt/activate/${id}`);
  }

  inactivateSegmentDetailOption(id): Observable<Response>{
    return this.methods.POST(`segmentsdetopt/inactivate/${id}`)
  }

  deleteSegmentDetailOption(id): Observable<Response> {
    return this.methods.DELETE(`segmentsdetopt/${id}`);
  }




}
