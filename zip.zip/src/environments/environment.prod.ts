export const environment = {
  production: true,
  apiEndPoint: "http://10.223.241.110:8080"
};
