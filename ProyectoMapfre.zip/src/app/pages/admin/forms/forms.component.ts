import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ECodeStatus } from '../../../enums/ecode-status';
import { File } from '../../../interfaces/file';
import { AlertsService } from '../../../services/alerts.service';
import { FormsService } from '../../../services/forms.service';
import { ProductsService } from '../../../services/products.service';
import { ThemeService } from '../../../services/theme.service';

@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.scss']
})
export class FormsComponent implements OnInit {

  @ViewChild('modalForms') modalForms: ElementRef
  listForms: any[] = [];
  listProducts: any[] = [];
  listThemes: any[] = [];
  formForms: FormGroup;
  idFormEdit: string = null;
  imgForm: any;
  formSubmited: boolean = false;

  constructor(
    private formService: FormsService,
    private fb: FormBuilder,
    private modalService: NgbModal,
    private productsService: ProductsService,
    private themesServices: ThemeService,
    private alertService: AlertsService
  ) { }

  async ngOnInit() {

    await this.LoadForms();

    await this.LoadThemes();

    await this.LoadProducts();

    this.formForms = this.fb.group({
      code: ['', Validators.required],
      name: ['', Validators.required],
      title: ['', Validators.required],
      productsId: ['', Validators.required],
      pathimg: [''],
      themesId: ['']
    })
  }


  get form() { return this.formForms.controls }

  onValidateField(code): boolean {
    return (this.form[code].touched && this.form[code].invalid) || (this.formSubmited && this.form[code].invalid)
  }


  /** Methods */
  LoadForms(): Promise<any> {
    return new Promise((resolve) => {
      this.formService.getFormsAll().subscribe(response => {
        let { status, data, message } = response;

        if (status == ECodeStatus.Ok) {
          this.listForms = data;
        }
        resolve(true);
      }, err => {
        resolve(false);
      })
    })
  }

  LoadProducts(): Promise<any> {
    return new Promise((resolve) => {
      this.productsService.getProducts().subscribe(response => {
        let { status, data, message } = response;

        if (status == ECodeStatus.Ok) {
          this.listProducts = data;
        }
        resolve(true);
      }, err => {
        resolve(false);
      })
    })
  }

  LoadThemes(): Promise<any> {
    return new Promise((resolve) => {
      this.themesServices.getThemes().subscribe(response => {
        let { status, data, message } = response;
        if (status == ECodeStatus.Ok) {
          this.listThemes = data;
        }
        resolve(true);
      })
    })
  }

  SaveForm(data): void {
    this.formService.saveForm(data).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadForms();
        this.modalService.dismissAll();
      } else {
        this.alertService.error(message);
      }
    })
  }

  UpdateForm(id, data): void {
    this.formService.updateForm(id, data).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadForms();
        this.modalService.dismissAll();
      } else {
        this.alertService.error(message);
      }
    })
  }

  DeleteForm(id): void {
    this.formService.deleteForm(id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadForms();
      } else {
        this.alertService.error(message);
      }
    })
  }


  /** Events */

  onClickNewForm(): void {
    this.idFormEdit = null;
    this.formForms.reset();
    this.imgForm = null;
    this.modalService.open(this.modalForms, { centered: true, backdrop: 'static', keyboard: false });
  }

  onClickEditForm(item): void {
    this.idFormEdit = item.id;
    if (item.pathimg) {
      this.imgForm = { base64: item.pathimg }
    } else {
      this.imgForm = null;
    }
    delete item.pathimg
    this.formForms.patchValue(item);

    this.modalService.open(this.modalForms, { centered: true, backdrop: 'static', keyboard: false });
  }

  onClickDeleteForm(item): void {
    this.alertService.questionDelete("Desea eliminar este formulario ?").then(res => {
      if (res) {
        this.DeleteForm(item.id)
      }
    })
  }

  onClickSaveForm(): void {
    this.formSubmited = true;
    if (this.formForms.valid) {
      let data = this.formForms.value;
      data.themesId = '4b1b046b-c4c0-44e3-a8cb-419e95b0bfb4';
      if (this.idFormEdit) {
        this.UpdateForm(this.idFormEdit, data);
      } else {
        this.SaveForm(data);
      }
    }
  }

  uploadFile(file: File): void {
    this.imgForm = file;
    this.formForms.patchValue({ pathimg: file.base64Sort })
  }

  onClickActivate(item): void {
    this.formService.activateForm(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadForms();
      } else {
        this.alertService.error(message);
      }
    })
  }

  onClickInactivate(item): void {
    this.formService.inactivateForm(item.id).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.alertService.success(message);
        this.LoadForms();
      } else {
        this.alertService.error(message);
      }
    })
  }

  onClickDeleteImage(): void {
    this.formForms.patchValue({ pathimg: null });
    this.imgForm = null;
  }

  // async onSearchProduct(productId): Promise<string> {

  //   return new Promise((resolve, reject) => {
  //     let text = '';

  //     text = this.listProducts.filter(e => e.id == productId)[0].name

  //     resolve(text);
  //   })
  // }

}
