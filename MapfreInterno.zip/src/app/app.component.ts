import { Component, ViewChild } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'dynamics-form-front';

  constructor(
    
  ) {
    fetch('http://api.ipify.org/?format=json').then(response => response.json()).then(data => localStorage.setItem('ip', data.ip) );   
  }

  
}
