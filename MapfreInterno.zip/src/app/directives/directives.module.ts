import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DragAndDropFileDirective } from './drag-and-drop-file.directive';


@NgModule({
  declarations: [DragAndDropFileDirective],
  imports: [
    CommonModule
  ],
  exports: [DragAndDropFileDirective]
})
export class DirectivesModule { }
