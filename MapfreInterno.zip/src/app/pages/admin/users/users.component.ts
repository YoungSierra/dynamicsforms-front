import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ECodeStatus } from '../../../enums/ecode-status';
import { AlertsService } from '../../../services/alerts.service';
import { ProgressBarService } from '../../../services/progress-bar.service';
import { UserService } from '../../../services/user.service';
import jwtDecode from 'jwt-decode';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {

  @ViewChild('modalUser') modalUser: ElementRef;
  listUser: any[] = [];
  formUser: FormGroup
  idUserLogued: string = '';
  idUserEdit: string;

  constructor(
    private userService: UserService,
    private modalService: NgbModal,
    private fb: FormBuilder,
    private alertService: AlertsService,
    private progressBar: ProgressBarService
  ) { }

  ngOnInit(): void {

    this.LoadUsers();

    this.formUser = this.fb.group({
      name: [''],
      email: ['']
    })

    let dataUser: any = jwtDecode(localStorage.getItem('token'));
    this.idUserLogued = dataUser.user;
  }


  /** Methods */
  LoadUsers(): void {
    this.progressBar.startLoading();
    this.userService.getUser().subscribe(response => {
      this.progressBar.completeLoading();
      let { status, data } = response;

      if (status == ECodeStatus.Ok) {
        this.listUser = data;
      }
    })
  }

  SaveUser(params): void {
    this.progressBar.startLoading();
    this.userService.saveUser(params).subscribe(response => {
      this.progressBar.completeLoading();
      let { status, data } = response;
      if (status == ECodeStatus.Ok) {
        this.LoadUsers();
        this.modalService.dismissAll();
      }
    })
  }

  UpdateUser(id, params): void {
    this.userService.updateUser(id, params).subscribe(response => {
      let { status, data } = response;

      if (status == ECodeStatus.Ok) {
        this.LoadUsers();
        this.modalService.dismissAll();
      }
    })
  }

  DeleteUser(id): void {
    this.userService.deleteUser(id).subscribe(response => {
      let { status, data } = response;

      if (status == ECodeStatus.Ok) {

        this.LoadUsers();
      }
    })
  }

  /** Events */

  onClickNewUser(): void {
    this.idUserEdit = null;
    this.formUser.reset();
    this.modalService.open(this.modalUser, { centered: true });
  }

  onClickSaveUser(): void {

    if (this.formUser.valid) {
      let data = this.formUser.value;

      if (this.idUserEdit) {
        this.UpdateUser(this.idUserEdit, data);
      } else {
        this.SaveUser(data);
      }
    }
  }

  onClickInactivate(user): void {
    if (this.idUserLogued != user.id) {
      this.userService.inactivateUser(user.id).subscribe(response => {
        let { status, data, message } = response;

        if (status == ECodeStatus.Ok) {

          this.LoadUsers();
        } else {
          this.alertService.error(message)
        }

      })
    } else {
      this.alertService.error("No puedes desactivar tu propio usuario");
    }

  }

  onClickActivate(user): void {
    if (this.idUserLogued != user.id) {
      this.userService.activateUser(user.id).subscribe(response => {
        let { status, data, message } = response;

        if (status == ECodeStatus.Ok) {

          this.LoadUsers();
        } else {
          this.alertService.error(message);
        }
      })
    } else {
      this.alertService.error("No puedes activar tu propio usuario");
    }
  }

  onClickEditUser(user): void {
    this.idUserEdit = user.id;
    this.formUser.patchValue(user);
    this.modalService.open(this.modalUser, { centered: true, keyboard: false, });
  }

  onClickDeleteUser(user): void {

    this.alertService.questionDelete("Desea eliminar este usuario?").then(res => {
      if (res) {
        this.DeleteUser(user.id)
      }
    })
  }

}
