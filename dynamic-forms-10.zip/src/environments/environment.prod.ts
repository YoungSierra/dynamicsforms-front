export const environment = {
  production: true,
  // apiEndPoint: "http://10.223.241.110:8080"
  apiEndPoint: "http://3.81.174.133:8080/"

};
