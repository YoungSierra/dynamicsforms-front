import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { NgProgress } from 'ngx-progressbar';
import { ProgressBarService } from '../../../services/progress-bar.service';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { UserService } from '../../../services/user.service';
import jwtDecode from 'jwt-decode';
import { ECodeStatus } from '../../../enums/ecode-status';
import { AlertsService } from '../../../services/alerts.service';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss']
})
export class LayoutComponent implements OnInit {

  @ViewChild('passwordModal') passwordModal: ElementRef;
  formPassword: any;

  constructor(
    private loading: ProgressBarService,
    private progress: NgProgress,
    private route: Router,
    private modalService: NgbModal,
    private apiService: UserService,
    private alertService: AlertsService
  ) { }

  ngOnInit(): void {
    this.loading.progressRef = this.progress.ref('progressBar');

    this.formPassword = {
      password: '',
      newPassword: '',
      newPasswordConfirm: ''
    }
  }

  SaveNewPassword(id, params): void {
    this.apiService.changePassword(id, params).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        this.formPassword = {
          password: '',
          newPassword: '',
          newPasswordConfirm: ''
        }
        this.alertService.success(message)
      } else {
        this.alertService.error(message);
      }
    })
  }

  onClickLogout(): void {
    console.log("Evento");
    localStorage.removeItem('token');
    localStorage.removeItem('email');
    this.route.navigate['/admin/login']
  }

  onClickChangePassword(): void {
    this.modalService.open(this.passwordModal, { centered: true, size: 'md' })
  }

  onClickUpdate(): void {
    if (this.formPassword.newPassword == this.formPassword.newPasswordConfirm) {
      let params = {
        password: this.formPassword.password,
        newpassword: this.formPassword.newPassword
      }
      let dataToken: any = jwtDecode(localStorage.getItem('token'));

      this.SaveNewPassword(dataToken.user, params);
    }
  }

}
