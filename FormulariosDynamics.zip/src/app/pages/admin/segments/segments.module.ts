import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SegmentsComponent } from './segments.component';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';
import { NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';

const routes: Routes = [
  {
    path: '',
    component: SegmentsComponent
  }
]

@NgModule({
  declarations: [
    SegmentsComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    NgbTooltipModule,
    RouterModule.forChild(routes)
  ]
})
export class SegmentsModule { }
