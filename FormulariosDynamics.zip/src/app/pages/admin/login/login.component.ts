import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ECodeStatus } from '../../../enums/ecode-status';
import { UserService } from '../../../services/user.service';
import { AlertsService } from '../../../services/alerts.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  formLogin: FormGroup

  constructor(
    private fb: FormBuilder,
    private userService: UserService,
    private router: Router,
    private alertService: AlertsService
  ) {

    this.formLogin = this.fb.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    })

  }

  ngOnInit(): void {
  }

  /** Methods */
  Login(params): void {
    this.userService.login(params).subscribe(response => {
      let { status, data, message } = response;

      if (status == ECodeStatus.Ok) {
        localStorage.setItem('token', data);
        localStorage.setItem('email', params.email);
        this.router.navigate(['admin/usuarios']);
      } else {
        this.alertService.error(message)
      }
    }, err => {
      let { error } =  err;
      this.alertService.error(error.message);
    })
  }

  /** Events */
  onClickLogin(): void {
    if (this.formLogin.valid) {
      let data = this.formLogin.value;
      this.Login(data);
    }else{
      this.alertService.error("Completar formulario")
    }
  }

}
